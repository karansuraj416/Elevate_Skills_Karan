# Non-Blocking Protection Relay & Safety System (ESP32)

An overcurrent protection relay that never blocks. It uses `millis()` scheduling and state machines only, with no `delay()` anywhere. It has hysteresis and debounce anti-chatter, sensor anomaly detection, statistical discrimination between spikes and real load steps, a timed recovery sequence with lockout, and a log of every transition.

## Simulator: Wokwi

**Wokwi** (https://wokwi.com) is the recommended simulator.

- It runs in the browser for free and needs no install. A VS Code extension is also available.
- It simulates a real **ESP32**, including its ADC, GPIO and UART, with a potentiometer, relay module, LEDs and buttons.
- Its serial monitor accepts typed input, which is how faults are injected live.

Alternatives: **Tinkercad Circuits** supports only the Arduino Uno and has a clumsy serial input. **Proteus** is paid and Windows-only. Both work with small changes, but Wokwi is the best fit.

### Run it in Wokwi
1. Go to wokwi.com, choose **New Project**, then **ESP32**.
2. Replace `sketch.ino` with this project's `sketch.ino`.
3. Open the `diagram.json` tab and replace its contents with this project's `diagram.json`.
4. Press **Play**. Click into the serial monitor and type single-letter commands.

## Circuit

| Part | ESP32 pin | Role |
|---|---|---|
| Potentiometer SIG | GPIO34 (ADC) | Current sensor, 0–3.3 V maps to 0–20 A |
| Relay module IN | GPIO23 | Load contactor |
| Blue LED via relay NO | 5 V through relay | "Load powered" indicator |
| Green LED + 220 Ω | GPIO25 | NORMAL |
| Red LED + 220 Ω | GPIO26 | TRIPPED (fast blink means LOCKOUT) |
| Yellow LED + 220 Ω | GPIO27 | Blink during cool-down, solid during probe |
| Push button to GND | GPIO15 | Lockout reset |

The potentiometer represents the **prospective load current**. The pot's extreme ends deliberately fall outside the valid ADC range, so turning it fully left or right simulates a broken or shorted sensor wire.

## Architecture

```
loop()  (never blocks; worst case is a few hundred µs)
 ├─ Serial commands / button debounce / chaos injector
 ├─ every 10 ms ──► acquireRaw() ─► SensorValidator ─► OcDetector + ClearMonitor ─► FSM ─► Relay
 ├─ status (1 s) and stats (10 s) ─► log queue
 └─ LEDs, drainLog() (writes only if the UART has room)
```

### Protection state machine

```
INIT ──self-test ok──► NORMAL ──trip──► TRIPPED ──fault cleared (500 ms)──► RECOVERY_WAIT
                         ▲                 ▲  ▲                               │      │
                         │                 │  └──── fault returns (abort) ────┘      │ cool-down 3/6/12 s
                         │                 │                                         ▼
                         └── probe ok (2 s) ── RECOVERY_PROBE ◄──────────────────────┘
                                               │ fault during probe
                                               ▼
                        4th trip without 30 s stable run ──► LOCKOUT ──manual reset──► RECOVERY_WAIT
```

The relay is closed **only** in NORMAL and RECOVERY_PROBE. `enterState()` is the single place the state can change. It logs the transition and drives the relay, so no transition can go unlogged.

## How each requirement is met

| Requirement | Implementation |
|---|---|
| Non-blocking | Timestamp scheduling only. Sampling uses the real elapsed `dt`, so a late tick is compensated rather than lost. Overruns are counted. Serial input is bounded per loop. Logging goes through a ring buffer. A loop watchdog is enabled. |
| Hysteresis | Trip at 10 A and reset at 9 A. The fault-clear condition is met below 9.0 A and lost only above 9.5 A. Spike-rate NOISY sets above 6/s and clears at or below 2/s. |
| Debounce | A leaky integrator needs 200 ms above 10 A. Time below 9 A counts down at 2x, and time in the band holds. Clear needs 500 ms; losing clear needs 100 ms. OOR needs 30 ms. The button needs 30 ms. |
| Contact protection | The relay must stay open at least 1 s before re-closing. Opening is never delayed. |
| Out-of-range | ADC below 20 counts (open circuit) or above 4075 (short) for 30 ms or more. |
| Frozen reading | Identical ADC counts for 1.5 s. A live ADC always shows LSB noise. |
| Unrealistic jumps vs real load change | A 21-sample (210 ms) median window plus MAD. A sample beyond max(2.5 A, 6σ) becomes a *suspect* while protection keeps using the median. If 5 suspects in a row (50 ms) sit on the same side and the last 3 agree within 1.5 A, it is a **genuine load change** and the window is re-seeded. A shorter run is a **spike** and is discarded. An erratic long run is a **burst** and is discarded. |
| Noise | Rejected spikes are counted in a sliding 1 s window (10 × 100 ms buckets). Too many sets the NOISY anomaly. |
| Fail-safe | Any sensor anomaly trips immediately. The sensor is trusted again only after 1 s anomaly-free. |
| Timed recovery | Cool-down with exponential back-off, then a supervised 2 s probe with the relay closed, then NORMAL. Retries reset after 30 s stable. The 4th failure locks out. |
| Logging | Every state, relay and anomaly edge is logged as an event line (`*`) with a ms timestamp and a sequence number. Gaps in the sequence would reveal drops; drop counters appear in STATS. |
| Stable under fault injection | CHAOS mode below, plus the host test that runs 10 simulated minutes of it. |

Timing note: a genuine step reaches the overcurrent stage after the 50 ms confirmation, so the typical trip time is about 240 ms. A single 12 A spike never trips, even though it exceeds the 15 A instantaneous level when added to the base load.

## Serial commands (115200 baud)

| Key | Injects |
|---|---|
| `l` | **Genuine** +6 A load step (toggle). Should trip if the base is above about 4 A. |
| `j` | One single-sample +12 A spike. Must **not** trip. |
| `s` | Spike storm, 10 % of samples (toggle). Expect NOISY. |
| `f` | Frozen sensor (toggle). Expect FROZEN after 1.5 s. |
| `o` / `k` | Open-circuit / shorted sensor (toggle). Expect OUT-OF-RANGE. |
| `x` | CHAOS: random fault combinations every 50–600 ms in storm/calm phases (toggle) |
| `0` | Clear all injection and chaos |
| `r` | Reset LOCKOUT (same as the button) |
| `d` | Print statistics |
| `h` | Help |

In CHAOS mode only, the lockout is auto-acknowledged after 5 s so the stress run keeps cycling. This is clearly logged as `chaos auto-ack`.

## Demo script (Wokwi)
1. Set the pot to about 25 % (≈5 A). After 1 s you should see `STATE INIT -> NORMAL` and the green and blue LEDs on.
2. Type `j`. You get `spike rejected` and no trip.
3. Type `l`. You get `LOAD CHANGE accepted 5 -> 11 A`, then `NORMAL -> TRIPPED` about 200 ms later. Type `l` again and watch TRIPPED → RECOVERY_WAIT (3 s) → RECOVERY_PROBE (2 s) → NORMAL.
4. Slowly move the pot back and forth around the middle (10 A). Note the single trip and no chatter.
5. Try `f`, `s`, `o`. Each should be detected, trip, and then recover once cleared.
6. Type `x` and leave it running for a few minutes, then `d`. Check that `logDrop event=0`.

Sample log:
```
[     1000 ms] #00007 * STATE INIT -> NORMAL : self-test passed (I=5.01A, retry 0/3)
[     1000 ms] #00008 * RELAY CLOSED (operation #1)
[     2050 ms] #00015 * LOAD CHANGE accepted: 5.01 A -> 11.01 A (persisted 5 samples, spread 0.06 A)
[     2240 ms] #00017 * STATE NORMAL -> TRIPPED : overcurrent >10.0 A for 200 ms (I=11.01A, retry 1/3)
[     2780 ms] #00022 * STATE TRIPPED -> RECOVERY_WAIT : fault cleared; cool-down 3000 ms (I=4.99A, retry 1/3)
[     5780 ms] #00026 * STATE RECOVERY_WAIT -> RECOVERY_PROBE : cool-down done; probing 2000 ms (I=5.01A, retry 1/3)
[     7780 ms] #00030 * STATE RECOVERY_PROBE -> NORMAL : probe passed (2000 ms supervised) (I=5.00A, retry 1/3)
```

## Automated host test (optional, needs g++)
`test/` compiles the **unmodified** sketch against a small Arduino shim and drives it with a simulated 1 ms clock:

```
g++ -std=c++17 -O2 -I test test/host_test.cpp -o host_test
./host_test          # writes host_test_log.txt
```

The 28 checks cover boot, spike rejection, genuine-step trip timing, anti-chatter around both thresholds, frozen, noisy and open-circuit detection, recovery, lockout and manual reset, and 10 minutes of chaos. They also check that every transition was logged, that no event lines were dropped, and that the relay was never closed outside NORMAL/PROBE.

## Moving to real hardware
- Set `cfg::SIM_NOISE = false`. The Wokwi pot is noise-free, so noise is added in simulation to keep the frozen detector meaningful.
- Use a real current sensor such as an ACS712 or SCT-013 with a burden circuit, scaled to 0–3.3 V. Adjust `FULL_SCALE_A` and add an offset if the sensor is mid-rail.
- Most relay boards are active-LOW, so set `RELAY_ACTIVE_HIGH = false`. Use a proper contactor for mains loads.
- Every threshold and timing is in the `cfg` namespace at the top of the sketch.
