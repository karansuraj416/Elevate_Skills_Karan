// Minimal Arduino shim so sketch.ino can be compiled and tested on a PC.
#pragma once
#include <cstdint>
#include <cstdio>
#include <cstring>
#include <cstdlib>
#include <cmath>
#include <cstdarg>
#include <string>
#include <deque>

#define HIGH 1
#define LOW 0
#define INPUT 0
#define OUTPUT 1
#define INPUT_PULLUP 2

extern uint32_t g_ms;
extern int g_adc;
extern int g_pins[64];

inline uint32_t millis() { return g_ms; }
inline uint32_t micros() { return g_ms * 1000u; }
inline int analogRead(uint8_t) { return g_adc; }
inline void analogReadResolution(int) {}
inline void pinMode(uint8_t p, uint8_t m) { if (m == INPUT_PULLUP) g_pins[p] = 1; }
inline void digitalWrite(uint8_t p, uint8_t v) { g_pins[p] = v; }
inline int digitalRead(uint8_t p) { return g_pins[p]; }
inline long random(long n) { return n <= 0 ? 0 : rand() % n; }
inline long random(long a, long b) { return b <= a ? a : a + rand() % (b - a); }

struct SerialShim {
  std::deque<char> in;
  std::string out;
  void begin(unsigned long) {}
  void setTxBufferSize(size_t) {}
  int available() { return (int)in.size(); }
  int read() { if (in.empty()) return -1; char c = in.front(); in.pop_front(); return c; }
  int availableForWrite() { return 4096; }
  size_t write(const uint8_t *b, size_t n) { out.append((const char *)b, n); return n; }
};
extern SerialShim Serial;
