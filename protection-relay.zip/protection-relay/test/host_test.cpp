// Host-side regression test: compiles the real sketch against an Arduino shim,
// drives it with a simulated 1 ms clock, injects faults and checks invariants.
//   g++ -std=c++17 -O2 -I test test/host_test.cpp -o host_test && ./host_test
#include "Arduino.h"
uint32_t g_ms = 0;
int g_adc = 0;
int g_pins[64] = {0};
SerialShim Serial;
#include "../sketch.ino"

static int failures = 0, checks = 0;
#define CHECK(cond, msg) do { checks++; if (!(cond)) { failures++; \
  printf("  FAIL @%u ms: %s  [state=%s]\n", g_ms, msg, stName(fsm.st)); } \
  else printf("  ok   %s\n", msg); } while (0)

static uint32_t invariantViolations = 0;
static void checkInvariants() {
  bool pinClosed = (g_pins[PIN_RELAY] == (RELAY_ACTIVE_HIGH ? HIGH : LOW));
  bool mayBeClosed = fsm.st == St::NORMAL || fsm.st == St::RECOVERY_PROBE;
  if (pinClosed != relay.closed || (relay.closed && !mayBeClosed)) invariantViolations++;
}
static void runFor(uint32_t ms) { for (uint32_t i = 0; i < ms; i++) { g_ms++; loop(); checkInvariants(); } }
static bool runUntil(St s, uint32_t maxMs) {
  for (uint32_t i = 0; i < maxMs; i++) { if (fsm.st == s) return true; g_ms++; loop(); checkInvariants(); }
  return fsm.st == s;
}
static void cmd(char c) { Serial.in.push_back(c); }
static int adcFor(float a) { return (int)lroundf(a * 4095 / 20.0f); }
static void settle() { g_adc = adcFor(5); cmd('0'); runUntil(St::NORMAL, 60000); runFor(31000); }

int main() {
  srand(1234);
  g_adc = adcFor(5.0f);
  setup();

  puts("T1 boot + self-test");
  runFor(1500);
  CHECK(fsm.st == St::NORMAL && relay.closed, "NORMAL with relay closed after self-test");

  puts("T2 single 12 A spike must NOT trip");
  uint32_t ops = relay.ops, sp = val.spikesRejected;
  cmd('j'); runFor(500);
  CHECK(fsm.st == St::NORMAL && relay.ops == ops, "no trip on single spike");
  CHECK(val.spikesRejected > sp, "spike counted as rejected");

  puts("T3 genuine load step 5 A -> 11 A must trip, then recover");
  cmd('l'); uint32_t t0 = g_ms;
  runUntil(St::TRIPPED, 2000);
  uint32_t tt = g_ms - t0;
  printf("       trip time %u ms\n", tt);
  CHECK(fsm.st == St::TRIPPED && !relay.closed, "tripped on sustained overcurrent");
  CHECK(tt >= 200 && tt <= 350, "trip time within 200-350 ms (50 ms step confirm + 200 ms debounce)");
  CHECK(val.stepsAccepted >= 1, "load change recognised as genuine");
  cmd('l');
  CHECK(runUntil(St::RECOVERY_WAIT, 3000), "fault-clear qualified -> RECOVERY_WAIT");
  CHECK(runUntil(St::RECOVERY_PROBE, 4000), "cool-down -> RECOVERY_PROBE");
  CHECK(runUntil(St::NORMAL, 3000), "probe passed -> NORMAL");

  settle();
  puts("T4 anti-chatter: signal oscillating around trip and reset thresholds");
  ops = relay.ops; uint32_t tr = fsm.transitions;
  for (int k = 0; k < 75; k++) { g_adc = adcFor((k & 1) ? 10.3f : 9.8f); runFor(40); }  // 3 s around 10 A
  printf("       relay ops %u, transitions %u\n", relay.ops - ops, fsm.transitions - tr);
  CHECK(relay.ops - ops == 1, "exactly one relay operation (single trip, no chatter)");
  g_adc = adcFor(8.6f); runFor(700);                       // clearly below reset: clear qualifies
  for (int k = 0; k < 300; k++) { g_adc = adcFor((k & 1) ? 9.4f : 8.6f); runFor(40); }  // then wobble to 9.4 A
  printf("       relay ops %u, transitions %u\n", relay.ops - ops, fsm.transitions - tr);
  CHECK(fsm.st == St::NORMAL, "recovered once despite oscillation across reset level");
  CHECK(relay.ops - ops == 2, "total 2 relay operations (open + reclose)");
  CHECK(fsm.aborts == 0, "no recovery aborts from threshold noise");

  settle();
  puts("T5 frozen sensor");
  cmd('f'); runFor(2000);
  CHECK((val.flags & AN_FROZEN) && fsm.st == St::TRIPPED, "FROZEN detected and relay tripped");
  cmd('f');
  CHECK(runUntil(St::NORMAL, 15000), "recovered after sensor unfroze");

  settle();
  puts("T6 noisy sensor (spike storm)");
  cmd('s'); runFor(2000);
  CHECK((val.flags & AN_NOISY) && fsm.st == St::TRIPPED, "NOISY detected and relay tripped");
  cmd('s');
  CHECK(runUntil(St::NORMAL, 15000), "recovered after noise stopped");

  settle();
  puts("T7 open-circuit sensor");
  cmd('o'); t0 = g_ms; runUntil(St::TRIPPED, 1000);
  printf("       trip time %u ms\n", g_ms - t0);
  CHECK((val.flags & AN_OOR) && g_ms - t0 <= 60, "OUT-OF-RANGE trip within 60 ms");
  cmd('o');
  CHECK(runUntil(St::NORMAL, 15000), "recovered after wiring restored");

  settle();
  puts("T8 intermittent fault on every probe -> LOCKOUT, manual reset");
  for (int i = 0; i < 8 && fsm.st != St::LOCKOUT; i++) {
    if (!runUntil(St::RECOVERY_PROBE, 40000) && fsm.st != St::NORMAL) break;
    g_adc = adcFor(12); runFor(400); g_adc = adcFor(5);
  }
  CHECK(fsm.st == St::LOCKOUT && !relay.closed, "LOCKOUT after repeated failures");
  runFor(5000);
  CHECK(fsm.st == St::LOCKOUT, "LOCKOUT is latched (no auto restart)");
  cmd('r'); runFor(10);
  CHECK(fsm.st == St::RECOVERY_WAIT, "manual reset starts timed recovery");
  CHECK(runUntil(St::NORMAL, 10000), "back to NORMAL after reset");

  puts("T9 10 minutes of continuous chaos fault injection");
  uint32_t tr0 = fsm.transitions;
  cmd('x'); runFor(600000); cmd('x'); cmd('0');
  printf("       transitions=%u trips=%u probesOk=%u probesFail=%u aborts=%u lockouts=%u spikes=%u\n",
         fsm.transitions - tr0, fsm.trips, fsm.probesOk, fsm.probesFail, fsm.aborts, fsm.lockouts,
         val.spikesRejected);
  CHECK(fsm.transitions - tr0 > 100, "many state transitions exercised");
  CHECK(runUntil(St::NORMAL, 120000), "returns to NORMAL after chaos stops");

  puts("Global checks");
  runFor(2000);
  size_t logged = 0, pos = 0;
  while ((pos = Serial.out.find("STATE ", pos)) != std::string::npos) { logged++; pos++; }
  printf("       transitions counted=%u logged=%zu, event drops=%u, info drops=%u\n",
         fsm.transitions, logged, logq.droppedEvent, logq.droppedInfo);
  CHECK(logged == fsm.transitions, "every state transition appears in the log");
  CHECK(logq.droppedEvent == 0, "no event log lines dropped");
  CHECK(invariantViolations == 0, "relay never closed outside NORMAL/PROBE, pin always matched state");

  FILE *f = fopen("host_test_log.txt", "w");
  if (f) { fwrite(Serial.out.data(), 1, Serial.out.size(), f); fclose(f); }
  printf("\n%d/%d checks passed. Full log: host_test_log.txt\n", checks - failures, checks);
  return failures ? 1 : 0;
}
