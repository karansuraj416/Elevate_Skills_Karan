/*
 * =====================================================================
 *  NON-BLOCKING PROTECTION RELAY & SAFETY SYSTEM
 *  Target : ESP32 DevKit-C  (Wokwi simulator or real hardware)
 *
 *  Features
 *   - Zero delay() calls: everything is millis()-scheduled, one cooperative
 *     super-loop, every subsystem is a small state machine
 *   - Overcurrent protection with HYSTERESIS (trip 10 A / reset 9 A) and an
 *     INTEGRATING DEBOUNCE (leaky timer) so readings hovering near the
 *     threshold cannot make the relay chatter
 *   - Instantaneous trip stage for severe overcurrent
 *   - Sensor anomaly detection:
 *        OUT-OF-RANGE  (open / shorted sensor wiring)
 *        FROZEN        (identical ADC counts for too long = stuck sensor)
 *        NOISY         (spike rate above limit, with hysteresis)
 *   - Window/median + MAD based discrimination between a GENUINE load step
 *     (persists and is self-consistent) and SENSOR SPIKES (transient)
 *   - Timed recovery: TRIPPED -> RECOVERY_WAIT (cool-down with exponential
 *     back-off) -> RECOVERY_PROBE (relay closed, supervised) -> NORMAL;
 *     LOCKOUT after repeated failures, manual reset required
 *   - Relay minimum-off time (contact protection); opening is never delayed
 *   - Non-blocking log queue: every state, relay and anomaly transition is
 *     logged with timestamp + sequence number (gaps would reveal drops)
 *   - Built-in fault injector over Serial, including a CHAOS stress mode
 *   - Loop watchdog, loop-time and tick-overrun statistics
 *
 *  Serial commands (115200 baud): type h for help
 * =====================================================================
 */
#include <Arduino.h>
#include <stdarg.h>
#include <string.h>
#include <math.h>

// ------------------------------------------------------------------ pins
constexpr uint8_t PIN_SENSOR    = 34;   // ADC1 input (current sensor / pot)
constexpr uint8_t PIN_RELAY     = 23;   // relay driver
constexpr uint8_t PIN_LED_OK    = 25;   // green : NORMAL
constexpr uint8_t PIN_LED_TRIP  = 26;   // red   : TRIPPED (fast blink = LOCKOUT)
constexpr uint8_t PIN_LED_REC   = 27;   // yellow: blink = cool-down, solid = probe
constexpr uint8_t PIN_BTN_RESET = 15;   // push button to GND (lockout reset)
constexpr bool    RELAY_ACTIVE_HIGH = true;  // many real modules are active LOW

// ---------------------------------------------------------------- config
namespace cfg {
// scheduling
constexpr uint32_t SAMPLE_MS          = 10;     // 100 Hz acquisition + protection
constexpr uint32_t STATUS_MS          = 1000;
constexpr uint32_t STATS_MS           = 10000;
constexpr uint32_t STARTUP_MS         = 1000;
constexpr uint32_t STARTUP_GRACE_MS   = 2000;
// sensor scaling: 0..4095 counts == 0..20 A
constexpr int      ADC_MAX            = 4095;
constexpr float    FULL_SCALE_A       = 20.0f;
// anomaly detection
constexpr int      ADC_VALID_MIN      = 20;     // below = open circuit
constexpr int      ADC_VALID_MAX      = 4075;   // above = shorted / saturated
constexpr uint32_t OOR_CONFIRM_MS     = 30;
constexpr uint32_t FROZEN_MS          = 1500;   // identical counts this long = stuck
constexpr uint8_t  WIN                = 21;     // median window (odd), 210 ms
constexpr float    JUMP_ABS_A         = 2.5f;   // min deviation to be "suspect"
constexpr float    JUMP_MAD_K         = 6.0f;   // or k * robust sigma, whichever larger
constexpr uint8_t  STEP_CONFIRM       = 5;      // samples a jump must persist (50 ms)
constexpr float    STEP_SPREAD_A      = 1.5f;   // settled suspects must agree within this
constexpr uint8_t  SPIKE_RATE_HI      = 6;      // spikes/s -> NOISY
constexpr uint8_t  SPIKE_RATE_LO      = 2;      // spikes/s -> NOISY cleared (hysteresis)
constexpr uint32_t SENSOR_OK_MS       = 1000;   // anomaly-free time before trusted again
// protection
constexpr float    TRIP_A             = 10.0f;
constexpr float    RESET_A            = 9.0f;   // hysteresis band 9..10 A
constexpr uint32_t TRIP_DELAY_MS      = 200;    // integrated time above TRIP_A
constexpr float    INST_A             = 15.0f;
constexpr uint32_t INST_DELAY_MS      = 20;
// fault-clear qualification (second layer of anti-chatter)
constexpr float    CLEAR_HYST_A       = 0.5f;   // clear when <9.0 A, lost when >9.5 A
constexpr uint32_t CLEAR_CONFIRM_MS   = 500;
constexpr uint32_t CLEAR_DROP_MS      = 100;
// recovery
constexpr uint32_t REC_BASE_MS        = 3000;   // 3 s, 6 s, 12 s ... back-off
constexpr uint32_t REC_MAX_MS         = 24000;
constexpr uint32_t PROBE_MS           = 2000;
constexpr uint8_t  MAX_RETRIES        = 3;      // 4th trip without stable run -> LOCKOUT
constexpr uint32_t RETRY_FORGET_MS    = 30000;  // stable NORMAL time that resets retries
constexpr uint32_t RELAY_MIN_OFF_MS   = 1000;   // contact protection (closing only)
// simulation helpers (set SIM_NOISE=false on real hardware)
constexpr bool     SIM_NOISE          = true;   // Wokwi pots are noise-free; real ADCs are not
constexpr int      SIM_NOISE_CNT      = 6;
constexpr float    SIM_LOAD_STEP_A    = 6.0f;
constexpr float    SIM_SPIKE_A        = 12.0f;
constexpr uint32_t CHAOS_RESET_AFTER_MS = 5000;
}

// --------------------------------------------------------------- helpers
static inline uint32_t u32min(uint32_t a, uint32_t b) { return a < b ? a : b; }
static void isort(float *a, uint8_t n) {
  for (uint8_t i = 1; i < n; i++) {
    float k = a[i]; int j = i - 1;
    while (j >= 0 && a[j] > k) { a[j + 1] = a[j]; j--; }
    a[j + 1] = k;
  }
}

// ===================================================== non-blocking log
// Lines are formatted into a ring buffer and drained to Serial only when
// the UART TX buffer has room, so logging never blocks the control loop.
// EVENT lines (transitions) are only dropped if the queue is completely
// full; INFO lines (status, spike notes) are shed first at 75 % fill.
constexpr uint8_t LOG_CAP = 64;
constexpr uint8_t LOG_LEN = 150;
struct LogQueue {
  char     buf[LOG_CAP][LOG_LEN];
  uint8_t  len[LOG_CAP];
  uint8_t  head = 0, tail = 0, count = 0;
  uint32_t seq = 0, droppedInfo = 0, droppedEvent = 0;
} logq;

void logMsg(bool event, const char *fmt, ...) {
  uint32_t seq = ++logq.seq;                       // drops still consume a number
  if (!event && logq.count >= (LOG_CAP * 3) / 4) { logq.droppedInfo++; return; }
  if (logq.count >= LOG_CAP) { logq.droppedEvent++; return; }
  char *dst = logq.buf[logq.head];
  int n = snprintf(dst, LOG_LEN, "[%9lu ms] #%05lu %c ",
                   (unsigned long)millis(), (unsigned long)seq, event ? '*' : ' ');
  if (n < 0) n = 0;
  va_list ap; va_start(ap, fmt);
  int m = vsnprintf(dst + n, LOG_LEN - n - 1, fmt, ap);
  va_end(ap);
  int room = LOG_LEN - n - 2;
  int total = n + (m < 0 ? 0 : (m > room ? room : m));
  dst[total++] = '\n';
  dst[total] = 0;
  logq.len[logq.head] = (uint8_t)total;
  logq.head = (logq.head + 1) % LOG_CAP;
  logq.count++;
}

void drainLog() {
  uint8_t budget = 6;                              // bounded work per loop pass
  while (logq.count && budget--) {
    uint8_t l = logq.len[logq.tail];
    if (Serial.availableForWrite() < (int)l) break; // never block on the UART
    Serial.write((const uint8_t *)logq.buf[logq.tail], l);
    logq.tail = (logq.tail + 1) % LOG_CAP;
    logq.count--;
  }
}

// ======================================================== fault injector
enum : uint8_t { INJ_FREEZE = 1, INJ_SPIKES = 2, INJ_OPEN = 4, INJ_SHORT = 8, INJ_LOAD = 16 };
struct Injector {
  uint8_t  flags = 0;
  bool     singleSpike = false;
  bool     chaos = false, storm = false;
  int      frozenRaw = -1;
  uint32_t nextChange = 0, phaseEnd = 0, lastAutoReset = 0;
} inj;

static const char *injStr(uint8_t f, char *out, size_t n) {
  if (!f) { snprintf(out, n, "none"); return out; }
  snprintf(out, n, "%s%s%s%s%s", (f & INJ_FREEZE) ? "FREEZE " : "", (f & INJ_SPIKES) ? "SPIKES " : "",
           (f & INJ_OPEN) ? "OPEN " : "", (f & INJ_SHORT) ? "SHORT " : "", (f & INJ_LOAD) ? "LOAD+6A " : "");
  size_t l = strlen(out); if (l && out[l - 1] == ' ') out[l - 1] = 0;
  return out;
}

static int countsFromAmps(float a) { return (int)lroundf(a * cfg::ADC_MAX / cfg::FULL_SCALE_A); }
static int clampAdc(int v) { return v < 0 ? 0 : (v > cfg::ADC_MAX ? cfg::ADC_MAX : v); }

// Physical read + simulated sensor imperfections + injected faults.
int acquireRaw() {
  int raw = analogRead(PIN_SENSOR);
  if (cfg::SIM_NOISE) raw += (int)random(-cfg::SIM_NOISE_CNT, cfg::SIM_NOISE_CNT + 1);
  if (inj.flags & INJ_LOAD) raw += countsFromAmps(cfg::SIM_LOAD_STEP_A);   // genuine load change
  raw = clampAdc(raw);
  if (inj.flags & INJ_FREEZE) {                                              // stuck sensor
    if (inj.frozenRaw < 0) inj.frozenRaw = raw;
    raw = inj.frozenRaw;
  } else {
    inj.frozenRaw = -1;
  }
  if (inj.singleSpike) {                                                     // one-sample glitch
    raw += countsFromAmps(cfg::SIM_SPIKE_A);
    inj.singleSpike = false;
  } else if ((inj.flags & INJ_SPIKES) && random(100) < 10) {                // EMI / noisy wiring
    float mag = 5.0f + random(0, 80) / 10.0f;
    raw += (random(2) ? 1 : -1) * countsFromAmps(mag);
  }
  if (inj.flags & INJ_OPEN)  raw = (int)random(0, 6);                        // broken wire
  if (inj.flags & INJ_SHORT) raw = cfg::ADC_MAX;                             // shorted to rail
  return clampAdc(raw);
}

// ===================================================== sensor validator
enum : uint8_t { AN_OOR = 1, AN_FROZEN = 2, AN_NOISY = 4 };
static const char *AN_NAMES[3] = {"OUT-OF-RANGE", "FROZEN", "NOISY"};

static const char *anomalyStr(uint8_t f, char *out, size_t n) {
  if (!f) { snprintf(out, n, "none"); return out; }
  snprintf(out, n, "%s%s%s", (f & AN_OOR) ? "OOR " : "", (f & AN_FROZEN) ? "FROZEN " : "",
           (f & AN_NOISY) ? "NOISY " : "");
  size_t l = strlen(out); if (l && out[l - 1] == ' ') out[l - 1] = 0;
  return out;
}

struct SensorValidator {
  float    win[cfg::WIN];
  uint8_t  wIdx = 0, wFill = 0;
  float    susp[cfg::STEP_CONFIRM];
  uint8_t  nSusp = 0;
  float    suspPeakDev = 0;
  int      lastRaw = -1;
  uint32_t sameSince = 0;
  bool     oorPending = false;
  uint32_t oorSince = 0;
  uint8_t  spikeBkt[10] = {0};       // 10 x 100 ms buckets = sliding 1 s
  uint8_t  bkt = 0;
  uint32_t bktStart = 0;
  uint16_t spikeRate = 0;
  uint8_t  flags = 0;
  bool     fault = true;              // untrusted until proven healthy
  uint32_t okSince = 0;
  float    value = 0;                 // validated current (A) used by protection
  float    rawAmps = 0;
  int      rawCounts = 0;
  uint32_t spikesRejected = 0, stepsAccepted = 0, burstsRejected = 0;

  void push(float a) {
    win[wIdx] = a;
    wIdx = (wIdx + 1) % cfg::WIN;
    if (wFill < cfg::WIN) wFill++;
  }
  float median(float *madOut) const {
    uint8_t n = wFill;
    if (!n) { if (madOut) *madOut = 0; return 0; }
    float t[cfg::WIN];
    for (uint8_t i = 0; i < n; i++) t[i] = win[i];
    isort(t, n);
    float med = (n & 1) ? t[n / 2] : 0.5f * (t[n / 2 - 1] + t[n / 2]);
    if (madOut) {
      for (uint8_t i = 0; i < n; i++) t[i] = fabsf(win[i] - med);
      isort(t, n);
      *madOut = (n & 1) ? t[n / 2] : 0.5f * (t[n / 2 - 1] + t[n / 2]);
    }
    return med;
  }
  void addSpikes(uint8_t n) {
    spikesRejected += n;
    uint16_t v = spikeBkt[bkt] + n;
    spikeBkt[bkt] = v > 255 ? 255 : (uint8_t)v;
  }
  void advanceBuckets(uint32_t now) {
    if (now - bktStart >= 1000) {                 // long gap: start fresh
      memset(spikeBkt, 0, sizeof spikeBkt); bkt = 0; bktStart = now; return;
    }
    while (now - bktStart >= 100) { bktStart += 100; bkt = (bkt + 1) % 10; spikeBkt[bkt] = 0; }
  }

  // Window-based spike / step discrimination.
  //  - A sample far from the window median (> max(2.5 A, 6 sigma_MAD)) is
  //    only a SUSPECT. Protection keeps using the median meanwhile.
  //  - If suspects persist for STEP_CONFIRM samples, all on the same side,
  //    and the settled ones agree within STEP_SPREAD_A, it is a GENUINE load
  //    change: the window is re-seeded at the new level.
  //  - If the run ends earlier, the samples were SPIKES and are discarded.
  //  - Long but erratic runs are rejected as bursts.
  void filterSample(float a) {
    if (wFill < cfg::WIN) { push(a); value = median(nullptr); return; }
    float mad;
    float med = median(&mad);
    float thr = fmaxf(cfg::JUMP_ABS_A, cfg::JUMP_MAD_K * 1.4826f * mad);
    float dev = a - med;
    if (fabsf(dev) > thr) {
      susp[nSusp++] = a;
      if (fabsf(dev) > suspPeakDev) suspPeakDev = fabsf(dev);
      if (nSusp >= cfg::STEP_CONFIRM) {
        bool above = true, below = true;
        for (uint8_t i = 0; i < nSusp; i++) {
          if (susp[i] <= med) above = false;
          if (susp[i] >= med) below = false;
        }
        float lo = susp[nSusp - 3], hi = lo, sum = 0;
        for (uint8_t i = nSusp - 3; i < nSusp; i++) {
          lo = fminf(lo, susp[i]); hi = fmaxf(hi, susp[i]); sum += susp[i];
        }
        if ((above || below) && (hi - lo) <= cfg::STEP_SPREAD_A) {
          float lvl = sum / 3.0f;
          for (uint8_t i = 0; i < cfg::WIN; i++) win[i] = lvl;
          wIdx = 0;
          stepsAccepted++;
          value = lvl;
          logMsg(true, "LOAD CHANGE accepted: %.2f A -> %.2f A (persisted %u samples, spread %.2f A)",
                 med, lvl, nSusp, hi - lo);
        } else {
          burstsRejected++;
          addSpikes(nSusp);
          logMsg(false, "erratic burst rejected: %u samples, peak dev %.2f A", nSusp, suspPeakDev);
        }
        nSusp = 0; suspPeakDev = 0;
      }
      return;                                       // hold last trusted value
    }
    if (nSusp) {
      addSpikes(nSusp);
      if (!(flags & AN_NOISY))
        logMsg(false, "spike rejected: %u sample(s), peak dev %.2f A", nSusp, suspPeakDev);
      nSusp = 0; suspPeakDev = 0;
    }
    push(a);
    value = median(nullptr);
  }

  void process(int raw, uint32_t now) {
    rawCounts = raw;
    rawAmps = raw * cfg::FULL_SCALE_A / cfg::ADC_MAX;
    advanceBuckets(now);
    uint8_t nf = flags;

    // 1) range check (needs persistence; single glitches count as spikes)
    bool oor = raw < cfg::ADC_VALID_MIN || raw > cfg::ADC_VALID_MAX;
    if (oor) {
      if (!oorPending) { oorPending = true; oorSince = now; }
      if (now - oorSince >= cfg::OOR_CONFIRM_MS) nf |= AN_OOR;
      else addSpikes(1);
    } else {
      oorPending = false;
      if (nf & AN_OOR) { nf &= ~AN_OOR; wFill = 0; wIdx = 0; nSusp = 0; }  // stale window
    }

    // 2) frozen check: a live ADC always shows LSB noise
    if (raw != lastRaw) { lastRaw = raw; sameSince = now; nf &= ~AN_FROZEN; }
    else if (now - sameSince >= cfg::FROZEN_MS) nf |= AN_FROZEN;

    // 3) spike / step discrimination
    if (!oor) filterSample(rawAmps);

    // 4) spike-rate check with hysteresis
    spikeRate = 0;
    for (uint8_t i = 0; i < 10; i++) spikeRate += spikeBkt[i];
    if (spikeRate > cfg::SPIKE_RATE_HI) nf |= AN_NOISY;
    else if (spikeRate <= cfg::SPIKE_RATE_LO) nf &= ~AN_NOISY;

    // 5) log every anomaly flag edge
    if (nf != flags) {
      for (uint8_t b = 0; b < 3; b++) {
        uint8_t m = 1 << b;
        if ((nf ^ flags) & m)
          logMsg(true, "ANOMALY %s %s (raw=%d, spikes/s=%u)", (nf & m) ? "DETECTED:" : "cleared: ",
                 AN_NAMES[b], raw, spikeRate);
      }
      flags = nf;
    }

    // 6) sensor health: fault immediately, trust again only after clean time
    if (flags) {
      okSince = now;
      if (!fault) {
        fault = true;
        char b[32];
        logMsg(true, "SENSOR FAULT asserted [%s] -> measurement untrusted", anomalyStr(flags, b, sizeof b));
      }
    } else if (fault && wFill >= cfg::WIN && now - okSince >= cfg::SENSOR_OK_MS) {
      fault = false;
      logMsg(true, "SENSOR HEALTHY: anomaly-free for %lu ms", (unsigned long)(now - okSince));
    }
  }
} val;

// ================================================= overcurrent detector
// Leaky integrator: time above TRIP_A counts up, time below RESET_A counts
// down twice as fast, time inside the hysteresis band holds. Brief dips do
// not reset the timer and brief excursions cannot trip.
struct OcDetector {
  uint32_t integ = 0, instAcc = 0;
  bool timed = false, inst = false;
  void reset() { integ = instAcc = 0; timed = inst = false; }
  void update(float i, uint32_t dt) {
    if (i > cfg::TRIP_A)        integ = u32min(integ + dt, 2 * cfg::TRIP_DELAY_MS);
    else if (i < cfg::RESET_A)  integ = integ > 2 * dt ? integ - 2 * dt : 0;
    instAcc = (i > cfg::INST_A) ? u32min(instAcc + dt, 1000) : 0;
    timed = integ >= cfg::TRIP_DELAY_MS;
    inst  = instAcc >= cfg::INST_DELAY_MS;
  }
  bool tripping() const { return timed || inst; }
} oc;

// "Fault is cleared" = sensor healthy AND current below reset level.
// Hysteresis on the level + asymmetric debounce on time.
struct ClearMonitor {
  bool state = false;
  uint32_t acc = 0;
  void update(bool sensorOk, float i, uint32_t dt) {
    if (!sensorOk && state) {                       // untrusted sensor: drop at once
      state = false; acc = 0;
      logMsg(false, "fault-clear condition LOST (sensor)");
      return;
    }
    bool in = state ? (sensorOk && i <= cfg::RESET_A + cfg::CLEAR_HYST_A)
                    : (sensorOk && i < cfg::RESET_A);
    if (in == state) { acc = 0; return; }
    acc += dt;
    if (acc >= (in ? cfg::CLEAR_CONFIRM_MS : cfg::CLEAR_DROP_MS)) {
      state = in; acc = 0;
      logMsg(false, "fault-clear condition %s (I=%.2f A)", in ? "MET" : "LOST", i);
    }
  }
} clearMon;

// ================================================================ relay
struct Relay {
  bool closed = false;
  uint32_t lastOpen = 0, ops = 0;
} relay;

void relayWrite(bool closed) { digitalWrite(PIN_RELAY, (closed == RELAY_ACTIVE_HIGH) ? HIGH : LOW); }
bool relayCanClose(uint32_t now) { return relay.closed || now - relay.lastOpen >= cfg::RELAY_MIN_OFF_MS; }
void relaySet(bool closed, uint32_t now) {
  if (closed == relay.closed) return;
  relay.closed = closed;
  relay.ops++;
  if (!closed) relay.lastOpen = now;
  relayWrite(closed);
  logMsg(true, "RELAY %s (operation #%lu)", closed ? "CLOSED" : "OPENED", (unsigned long)relay.ops);
}

// ======================================================= state machine
enum class St : uint8_t { INIT, NORMAL, TRIPPED, RECOVERY_WAIT, RECOVERY_PROBE, LOCKOUT };
static const char *stName(St s) {
  switch (s) {
    case St::INIT: return "INIT";
    case St::NORMAL: return "NORMAL";
    case St::TRIPPED: return "TRIPPED";
    case St::RECOVERY_WAIT: return "RECOVERY_WAIT";
    case St::RECOVERY_PROBE: return "RECOVERY_PROBE";
    case St::LOCKOUT: return "LOCKOUT";
  }
  return "?";
}

struct Fsm {
  St st = St::INIT;
  uint32_t enteredAt = 0, recDelay = cfg::REC_BASE_MS;
  uint8_t retries = 0;
  uint32_t transitions = 0, trips = 0, probesOk = 0, probesFail = 0, lockouts = 0, aborts = 0;
} fsm;

// The ONLY place the state changes. Logs, then applies entry actions.
void enterState(St to, uint32_t now, const char *fmt, ...) {
  if (to == fsm.st) return;
  char why[80];
  va_list ap; va_start(ap, fmt); vsnprintf(why, sizeof why, fmt, ap); va_end(ap);
  St from = fsm.st;
  fsm.st = to;
  fsm.enteredAt = now;
  fsm.transitions++;
  logMsg(true, "STATE %s -> %s : %s (I=%.2fA, retry %u/%u)", stName(from), stName(to), why,
         val.value, fsm.retries, cfg::MAX_RETRIES);
  relaySet(to == St::NORMAL || to == St::RECOVERY_PROBE, now);  // relay follows state
}

void trip(uint32_t now, const char *why) {
  fsm.trips++;
  fsm.retries++;
  if (fsm.retries > cfg::MAX_RETRIES) {
    fsm.lockouts++;
    enterState(St::LOCKOUT, now, "%s; %u trips w/o stable run", why, fsm.retries);
  } else {
    enterState(St::TRIPPED, now, "%s", why);
  }
}

void fsmStep(uint32_t now, uint32_t dt) {
  const bool ok = !val.fault;
  const float I = val.value;
  if (ok) oc.update(I, dt); else oc.reset();
  clearMon.update(ok, I, dt);
  char why[64], b[32];

  switch (fsm.st) {
    case St::INIT:
      if (now - fsm.enteredAt < cfg::STARTUP_MS) break;
      if (ok && I < cfg::RESET_A) enterState(St::NORMAL, now, "self-test passed");
      else if (now - fsm.enteredAt >= cfg::STARTUP_MS + cfg::STARTUP_GRACE_MS)
        trip(now, ok ? "startup: load above reset level" : "startup: sensor not validated");
      break;

    case St::NORMAL:
    case St::RECOVERY_PROBE: {
      const bool probing = (fsm.st == St::RECOVERY_PROBE);
      const char *pfx = probing ? "probe failed: " : "";
      bool tripped = true;
      if (!ok) {
        snprintf(why, sizeof why, "%ssensor fault [%s]", pfx, anomalyStr(val.flags, b, sizeof b));
      } else if (oc.inst) {
        snprintf(why, sizeof why, "%sINSTANTANEOUS overcurrent (>%.0f A)", pfx, cfg::INST_A);
      } else if (oc.timed) {
        snprintf(why, sizeof why, "%sovercurrent >%.1f A for %lu ms", pfx, cfg::TRIP_A,
                 (unsigned long)cfg::TRIP_DELAY_MS);
      } else {
        tripped = false;
      }
      if (tripped) {
        if (probing) fsm.probesFail++;
        trip(now, why);
      } else if (probing && now - fsm.enteredAt >= cfg::PROBE_MS) {
        fsm.probesOk++;
        enterState(St::NORMAL, now, "probe passed (%lu ms supervised)", (unsigned long)cfg::PROBE_MS);
      } else if (!probing && fsm.retries && now - fsm.enteredAt >= cfg::RETRY_FORGET_MS) {
        logMsg(true, "retry counter reset (%u -> 0) after %lu s stable", fsm.retries,
               (unsigned long)(cfg::RETRY_FORGET_MS / 1000));
        fsm.retries = 0;
      }
      break;
    }

    case St::TRIPPED:
      if (clearMon.state) {
        uint8_t sh = fsm.retries ? fsm.retries - 1 : 0;
        fsm.recDelay = u32min(cfg::REC_BASE_MS << sh, cfg::REC_MAX_MS);
        enterState(St::RECOVERY_WAIT, now, "fault cleared; cool-down %lu ms", (unsigned long)fsm.recDelay);
      }
      break;

    case St::RECOVERY_WAIT:
      if (!clearMon.state) {
        fsm.aborts++;
        enterState(St::TRIPPED, now, "recovery aborted: fault returned after %lu ms",
                   (unsigned long)(now - fsm.enteredAt));
      } else if (now - fsm.enteredAt >= fsm.recDelay && relayCanClose(now)) {
        enterState(St::RECOVERY_PROBE, now, "cool-down done; probing %lu ms", (unsigned long)cfg::PROBE_MS);
      }
      break;

    case St::LOCKOUT:
      break;   // leaves only through requestReset()
  }
}

void requestReset(uint32_t now, const char *src) {
  if (fsm.st != St::LOCKOUT) {
    logMsg(true, "RESET (%s) ignored: state is %s, not LOCKOUT", src, stName(fsm.st));
    return;
  }
  if (!clearMon.state) {
    logMsg(true, "RESET (%s) refused: fault still present", src);
    return;
  }
  fsm.retries = 0;
  fsm.recDelay = cfg::REC_BASE_MS;
  enterState(St::RECOVERY_WAIT, now, "manual reset (%s); cool-down %lu ms", src, (unsigned long)fsm.recDelay);
}

// ====================================================== chaos stress mode
// Alternates "storm" phases (random fault combinations every 50-600 ms)
// with "calm" phases so the recovery path is exercised over and over.
void chaosStep(uint32_t now) {
  if (!inj.chaos) return;
  char b[48];
  if ((int32_t)(now - inj.phaseEnd) >= 0) {
    inj.storm = !inj.storm;
    inj.phaseEnd = now + (inj.storm ? random(2000, 6000) : random(2000, 15000));
    if (!inj.storm) inj.flags = 0;
    logMsg(false, "CHAOS phase -> %s", inj.storm ? "STORM" : "CALM");
  }
  if (inj.storm && (int32_t)(now - inj.nextChange) >= 0) {
    uint8_t f = (uint8_t)random(0, 32);
    if ((f & INJ_OPEN) && (f & INJ_SHORT)) f &= ~INJ_SHORT;
    if (random(100) < 15) inj.singleSpike = true;
    if (f != inj.flags) { inj.flags = f; logMsg(false, "CHAOS inject=%s", injStr(f, b, sizeof b)); }
    inj.nextChange = now + random(50, 600);
  }
  // test-harness only: auto-acknowledge lockout so the stress run keeps cycling
  if (fsm.st == St::LOCKOUT && clearMon.state && now - fsm.enteredAt >= cfg::CHAOS_RESET_AFTER_MS &&
      now - inj.lastAutoReset >= 1000) {
    inj.lastAutoReset = now;
    requestReset(now, "chaos auto-ack");
  }
}

// ======================================================== user interface
struct Button {
  bool stable = true, lastRead = true;   // pull-up: released == HIGH
  uint32_t changedAt = 0;
  bool pressed(uint32_t now) {
    bool r = digitalRead(PIN_BTN_RESET) == HIGH;
    if (r != lastRead) { lastRead = r; changedAt = now; }
    if (r != stable && now - changedAt >= 30) { stable = r; return !stable; }
    return false;
  }
} btn;

void printHelp() {
  logMsg(true, "Commands:  f=freeze sensor  s=noise spikes  j=single spike  o=open wire  k=shorted wire");
  logMsg(true, "           l=genuine +6A load step  x=CHAOS stress  0=clear all injection");
  logMsg(true, "           r=reset lockout  d=stats  h=help   (button on GPIO15 = reset)");
}

struct Stats {
  uint32_t maxLoopUs = 0, overruns = 0, loops = 0;
} stats;

void printStats(uint32_t now) {
  logMsg(true, "STATS up=%lus trans=%lu trips=%lu probes ok/fail=%lu/%lu aborts=%lu lockouts=%lu relayOps=%lu",
         (unsigned long)(now / 1000), (unsigned long)fsm.transitions, (unsigned long)fsm.trips,
         (unsigned long)fsm.probesOk, (unsigned long)fsm.probesFail, (unsigned long)fsm.aborts,
         (unsigned long)fsm.lockouts, (unsigned long)relay.ops);
  unsigned long heap = 0;
#if defined(ARDUINO_ARCH_ESP32)
  heap = ESP.getFreeHeap();
#endif
  logMsg(true, "STATS spikesRej=%lu bursts=%lu steps=%lu logDrop info/event=%lu/%lu overruns=%lu maxLoop=%luus heap=%lu",
         (unsigned long)val.spikesRejected, (unsigned long)val.burstsRejected, (unsigned long)val.stepsAccepted,
         (unsigned long)logq.droppedInfo, (unsigned long)logq.droppedEvent, (unsigned long)stats.overruns,
         (unsigned long)stats.maxLoopUs, heap);
}

void handleCommand(char c, uint32_t now) {
  char b[48];
  switch (c) {
    case 'f': inj.flags ^= INJ_FREEZE; break;
    case 's': inj.flags ^= INJ_SPIKES; break;
    case 'o': inj.flags ^= INJ_OPEN;  inj.flags &= ~INJ_SHORT; break;
    case 'k': inj.flags ^= INJ_SHORT; inj.flags &= ~INJ_OPEN;  break;
    case 'l': inj.flags ^= INJ_LOAD; break;
    case 'j': inj.singleSpike = true; break;
    case '0': case 'c': inj.flags = 0; inj.chaos = false; break;
    case 'x':
      inj.chaos = !inj.chaos;
      if (inj.chaos) { inj.storm = false; inj.phaseEnd = now; }
      else inj.flags = 0;
      break;
    case 'r': requestReset(now, "serial"); return;
    case 'd': printStats(now); return;
    case 'h': case '?': printHelp(); return;
    default: return;
  }
  logMsg(true, "CMD '%c' -> injection=[%s] chaos=%s", c, injStr(inj.flags, b, sizeof b), inj.chaos ? "ON" : "off");
}

void updateLeds(uint32_t now) {
  bool slow = (now / 250) & 1, fast = (now / 100) & 1;
  St s = fsm.st;
  digitalWrite(PIN_LED_OK,   s == St::NORMAL ? HIGH : LOW);
  digitalWrite(PIN_LED_TRIP, (s == St::TRIPPED || (s == St::LOCKOUT && fast)) ? HIGH : LOW);
  digitalWrite(PIN_LED_REC,  (s == St::RECOVERY_PROBE || (s == St::RECOVERY_WAIT && slow) ||
                              (s == St::INIT && fast)) ? HIGH : LOW);
}

// ========================================================== main loop
struct Sched { uint32_t lastSample = 0, lastStatus = 0, lastStats = 0; } sched;

void setup() {
  Serial.setTxBufferSize(2048);           // must precede begin() on ESP32
  Serial.begin(115200);
  pinMode(PIN_RELAY, OUTPUT);
  relayWrite(false);                       // fail-safe: load disconnected at boot
  pinMode(PIN_LED_OK, OUTPUT);
  pinMode(PIN_LED_TRIP, OUTPUT);
  pinMode(PIN_LED_REC, OUTPUT);
  pinMode(PIN_BTN_RESET, INPUT_PULLUP);
  analogReadResolution(12);
#if defined(ARDUINO_ARCH_ESP32)
  enableLoopWDT();                         // loop must return within ~5 s or the chip resets
#endif
  uint32_t now = millis();
  fsm.enteredAt = now;
  sched.lastSample = sched.lastStatus = sched.lastStats = now;
  logMsg(true, "BOOT Non-blocking protection relay | trip %.1f A / reset %.1f A / inst %.1f A",
         cfg::TRIP_A, cfg::RESET_A, cfg::INST_A);
  logMsg(true, "BOOT state INIT, relay OPEN, validating sensor for %lu ms", (unsigned long)cfg::STARTUP_MS);
  printHelp();
}

void loop() {
  const uint32_t t0 = micros();
  const uint32_t now = millis();

  // 1) inputs (bounded, non-blocking)
  for (uint8_t n = 0; n < 16 && Serial.available(); n++) {
    char c = (char)Serial.read();
    if (c > ' ') handleCommand(c, now);
  }
  if (btn.pressed(now)) requestReset(now, "button");
  chaosStep(now);

  // 2) 100 Hz acquisition -> validation -> protection state machine
  if (now - sched.lastSample >= cfg::SAMPLE_MS) {
    uint32_t dt = now - sched.lastSample;          // real elapsed time, so late
    if (dt >= 2 * cfg::SAMPLE_MS) stats.overruns++; // ticks are compensated, not lost
    sched.lastSample = now;
    val.process(acquireRaw(), now);
    fsmStep(now, dt);
  }

  // 3) periodic reporting
  if (now - sched.lastStatus >= cfg::STATUS_MS) {
    sched.lastStatus = now;
    char a[32], b[48];
    logMsg(false, "STATUS %-14s relay=%-6s I=%5.2fA raw=%5.2fA anomalies=%s inj=%s%s oc=%lums",
           stName(fsm.st), relay.closed ? "CLOSED" : "OPEN", val.value, val.rawAmps,
           anomalyStr(val.flags, a, sizeof a), injStr(inj.flags, b, sizeof b), inj.chaos ? "+CHAOS" : "",
           (unsigned long)oc.integ);
  }
  if (now - sched.lastStats >= cfg::STATS_MS) {
    sched.lastStats = now;
    printStats(now);
  }

  // 4) outputs
  updateLeds(now);
  drainLog();

  stats.loops++;
  uint32_t el = micros() - t0;
  if (el > stats.maxLoopUs) stats.maxLoopUs = el;
}
