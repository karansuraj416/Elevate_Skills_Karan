# Modular Battery Management Engine — Design Report

**Author:** Raghav Kadambi · B.Tech CSE (AI & Robotics)
**Deliverable:** portable C99 BMS analysis engine, pack simulator, ESP32/Wokwi front-end, tests, benchmarks

---

## 1. Objective

Build a Battery Management System (BMS) analysis engine that:

1. operates on an array of series cells whose count is set by **one compile-time constant** (`BMS_NUM_CELLS`);
2. continuously finds the **weakest and strongest** cells and the **voltage imbalance** between them;
3. tracks whether that imbalance is **increasing or decreasing** over time;
4. judges imbalance against **adaptive thresholds** that depend on State of Charge (SoC) and discharge rate (C-rate), instead of a fixed limit;
5. exposes everything through **one clean interface** so later tasks (balancing, logging, alarms, displays, telemetry) reuse the analysis rather than re-implementing it;
6. scales cleanly from **4 to 16 cells**, with the memory, time and data-structure impact quantified.

---

## 2. Architecture

```
            ┌────────────────── one write path ──────────────────┐
 ADC / AFE  │                                                     │
 or sim  ──►│ bms_sample_t ─► bms_update()                        │
            │                 ├─ 1 scan_cells()     O(N)          │
            │                 ├─ 2 update_soc()     O(1)          │
            │                 ├─ 3 update_trend()   O(W), W fixed │
            │                 ├─ 4 classify()       O(1)          │
            │                 └─ 5 balance_advice() O(N)          │
            │                         │                           │
            │                 bms_status_t (single snapshot)      │
            └─────────────────────────┼───────────────────────────┘
                     many read paths  │  (const pointer / observers)
        ┌───────────────┬─────────────┼──────────────┬──────────────┐
        ▼               ▼             ▼              ▼              ▼
   Balancer task   CSV logger   Alarm monitor   Charger CV loop   ESP32 LEDs
```

| Layer | Files | Responsibility |
|---|---|---|
| Configuration | `src/bms_config.h` | `BMS_NUM_CELLS`, chemistry limits, trend window, threshold tuning |
| Engine | `src/bms_engine.h/.c` | All analysis. No I/O, no `malloc`, no hardware access |
| Plant model | `sim/pack_model.h/.c` | Simulated cells with capacity, resistance, SoC and leakage spread |
| Consumers | `app/consumers.c` | Balancer, logger, alarm — read-only users of the engine |
| Front-ends | `app/main.c`, `wokwi_esp32/sketch.ino` | PC scenario runner; ESP32 hardware/simulator demo |

The engine never knows whether its numbers come from a simulator, potentiometers in Wokwi, or a real analog front-end chip. The exact same `bms_engine.c` compiles on the PC and on the ESP32.

---

## 3. Algorithms

### 3.1 Weakest / strongest cell and imbalance — `scan_cells()`

A single pass over the cell array computes min (and its index), max (and its index), the sum (pack voltage and average), and under/over-voltage faults at the same time. One loop, one read of each cell, no sorting.

`imbalance_mv = max_mv − min_mv`

The *weakest* cell is the one with the lowest voltage — the cell that will hit the cut-off first on discharge and therefore limits usable pack capacity. The *strongest* is the highest — the cell that will hit 4.20 V first on charge.

### 3.2 State of Charge — `update_soc()`

- **Seed:** on the first sample, SoC is read off the open-circuit-voltage (OCV) curve of the average cell (inverse lookup on an 11-point NMC table).
- **Track:** every subsequent sample uses coulomb counting:
  `SoC -= 100 · I·Δt / capacity`
- `bms_set_soc()` lets an external fuel gauge or a "full charge reached" event re-anchor the estimate.
- C-rate is `|I| / capacity`.

### 3.3 Imbalance trend — `update_trend()`

Every update pushes `(time, imbalance)` into a **fixed ring buffer of W = 16 samples** (power of two, so the index wraps with a bit-mask instead of a division). A **least-squares slope** in mV/s is fitted over the window:

```
slope = (n·Σxy − Σx·Σy) / (n·Σx² − (Σx)²)
```

| Slope | Trend |
|---|---|
| > +0.05 mV/s | `INCREASING` — cells diverging |
| < −0.05 mV/s | `DECREASING` — cells converging (e.g. balancing working) |
| otherwise | `STABLE` |
| fewer than 4 samples | `UNKNOWN` |

A regression is used instead of "compare with the previous sample" because single-sample differences are dominated by ADC noise (±1.5 mV in the model); the fit averages that out. Time is taken relative to the newest sample so `float` keeps full precision even after days of uptime.

### 3.4 Adaptive imbalance thresholds — `bms_adaptive_thresholds()`

A fixed limit (say 30 mV) is wrong at both ends of the operating range:

**SoC dependence.** The Li-ion OCV curve is flat between ~30 % and ~70 % SoC (about 5–7 mV per 1 % SoC) and steep near empty and full (15–45 mV per 1 %). The same 20 mV spread therefore means *several percent* of real charge mismatch mid-range, but well under 1 % near the ends. So the threshold is tight in the flat region and relaxed at the extremes:

| SoC (%) | 0 | 10 | 20 | 30 | 40–60 | 70 | 80 | 90 | 100 |
|---|---|---|---|---|---|---|---|---|---|
| Base WARN (mV) | 60 | 50 | 35 | 25 | **20** | 25 | 30 | 40 | 50 |

Linear interpolation is used between table points.

**Discharge-rate dependence.** Under load each cell's terminal voltage sags by `I·Rᵢ`. Cells with slightly different internal resistance show a voltage spread that is *not* a charge imbalance and disappears at rest. The window is widened in proportion to the C-rate:

```
warn = base(SoC) + min(10 mV × C-rate, 30 mV)
crit = 2 × warn
```

**Hysteresis.** A level only steps *down* once the imbalance falls 10 % below the boundary it crossed, so alarms don't chatter when the spread hovers on a limit.

Unit test `test_adaptive` shows the effect directly: an identical 30 mV spread at 50 % SoC is a **WARNING at rest** but **OK at 2C**, because 20 mV of extra allowance covers the expected I·R spread.

### 3.5 Balancing advice — `balance_advice()`

When the level is WARNING or above, every cell more than half a warning window above the weakest cell is flagged in `balance_mask` (one bit per cell). Advice is suppressed when SoC < 20 %, when C-rate > 0.5 (spread is mostly I·R, so bleeding by voltage would drain the wrong cells), and on any under-voltage fault. The engine only *advises*; the separate balancer task decides whether to switch the bleed resistors.

### 3.6 Input validation

A sample is rejected (status left intact, `BMS_FAULT_BAD_SAMPLE` set) if its timestamp does not increase or any channel reads 0 mV (open wire).

---

## 4. Interface for reuse

All analysis lands in one struct, `bms_status_t`. Consumers get it in one of two ways:

```c
/* pull */
const bms_status_t *st = bms_get_status(&bms);
if (st->level == BMS_IMB_CRITICAL) open_contactor();

/* push — register once, called after every update */
bms_register_observer(&bms, my_task, &my_ctx);
```

Thin accessors cover the most common questions: `bms_weakest_cell()`, `bms_strongest_cell()`, `bms_imbalance_mv()`, `bms_trend()`, `bms_cell_should_balance()`. The threshold policy is itself exposed as a pure function so a UI or test can ask "what would the limit be at 30 % SoC and 1.5C?" without touching engine state.

Five independent consumers in this project reuse the analysis with zero duplicated maths: the balancer, the CSV logger, the alarm monitor, the charger's CV-taper loop (it reads `max_mv`), and the ESP32 LED driver.

---

## 5. Scaling from 4 to 16 cells

Change one line (`#define BMS_NUM_CELLS 16u`) or build with `make CELLS=16`. Everything else — arrays, loop bounds, bitmask size, CSV columns, the dashboard — follows.

### 5.1 Memory

Measured with `sizeof` (x86-64 GCC; ESP32 is also 32-bit little-endian with the same alignment for these types):

| Cells | Engine total | Status snapshot | One sample | Trend buffer |
|---|---|---|---|---|
| 4 | 288 B | 76 B | 16 B | 128 B |
| 8 | 296 B | 84 B | 24 B | 128 B |
| 12 | 304 B | 92 B | 32 B | 128 B |
| **16** | **312 B** | **100 B** | **40 B** | 128 B |
| 32 | 344 B | 132 B | 72 B | 128 B |

The growth is **2 bytes per cell** (one `uint16_t` voltage in the status copy) plus one byte of balance mask per 8 cells, rounded by alignment. Going from 4S to 16S costs **24 bytes**. The trend buffer — the largest single structure — is **independent of cell count**, because the trend is computed on the pack-level imbalance, not per cell. Flash use is constant: there is no per-cell code.

Formula: `engine ≈ 280 + 2·N + ⌈N/8⌉` bytes (± alignment padding).

### 5.2 Execution time

`bms_update()` measured over 2 million calls (PC, `-O2`, input generation subtracted):

| Cells | ns / update |
|---|---|
| 4 | 94 |
| 8 | 114 |
| 12 | 164 |
| 16 | 216 |
| 32 | 332 |

The cost has two parts:

- **Fixed:** SoC update, the 16-point trend regression, threshold lookup, observers — about 50–60 ns here, the same for any N.
- **Per-cell:** two O(N) loops (scan and balance) — roughly 8–10 ns per cell.

So the engine is **O(N + W)** with W constant: linear in cells, and 4→16 cells is ~2.3× the time, not 4×, because the fixed part is shared. On an ESP32 at 240 MHz expect a few microseconds per update (the sketch prints the measured value each second). At a typical 10–100 Hz BMS sample rate that is well under 0.1 % CPU even at 16S. In practice the bottleneck at 16S is **acquisition**, not analysis: reading 16 cells through multiplexed ADCs or a daisy-chained analog front-end takes milliseconds, three orders of magnitude more than the computation.

### 5.3 Data-structure decisions that make scaling safe

| Decision | Why it scales |
|---|---|
| Static arrays sized by `BMS_NUM_CELLS` | No heap, no fragmentation; RAM known at link time |
| Cell index is `uint8_t` | Up to 255 cells; a `#error` guard enforces the range |
| `uint32_t` pack sum | 65 535 cells × 4.2 V before overflow — no risk |
| Balance mask `uint8_t[(N+7)/8]` | 1 bit per cell; 16S needs 2 bytes, not a 16-element array |
| Single-pass min/max/sum | One memory sweep regardless of N |
| Trend on pack imbalance, not per cell | Window memory and regression time do not grow with N |
| Power-of-two ring buffer | Index wrap is a bit-mask, no division |
| Observers on a fixed table (4 slots) | Adding consumers never touches engine code |

### 5.4 What would change beyond 16 cells

For 50–200S packs (EVs, grid storage), the engine still works up to 255 cells, but a production design would add a per-module layer: each 12–16-cell module computes its own min/max/sum and the pack engine merges module results (still O(N) total, but parallel across module MCUs), and per-cell trend tracking would move to a lower sample rate to keep memory bounded.

---

## 6. Simulation results

Scenario (1 Hz, 160 min): rest → 1C discharge → rest → 2C/0.2C pulses → rest → 0.5C CC/CV charge → top rest. The simulated pack contains one aged cell (−8 % capacity, +60 % internal resistance, starting 3 % low) and one leaky cell (1.5 mA self-discharge).

| Run | Peak imbalance | Final imbalance | Final true SoC spread |
|---|---|---|---|
| 4S, balancing off | 205 mV | 40 mV | 2.98 % |
| 4S, balancing on | 199 mV | 14 mV | **1.02 %** |
| 16S, balancing off | 210 mV | 39 mV | 3.00 % |
| 16S, balancing on | 204 mV | 22 mV | **1.62 %** |

Observations from the logs (`logs/*.png`):

- The aged cell is correctly identified as **weakest** throughout the discharge.
- During the 2C pulses the imbalance jumps to ~200 mV, but the adaptive thresholds rise with C-rate, so the alarm reflects the genuinely weak cell rather than every load step.
- In the rest after the pulses the trend reads **DECREASING** as cells relax and balancing works; the level steps CRITICAL → WARNING → OK with hysteresis.
- Balancing cuts the true SoC spread by roughly two-thirds in both pack sizes, with identical engine code.

Figures: `logs/log_balance_on_4s.png`, `logs/log_balance_on_16s.png`, `logs/log_balance_off_*.png`, `docs/scaling.png`.

---

## 7. Verification

`make test` builds and runs the unit tests for 4, 8 and 16 cells:

- weakest/strongest indices, imbalance and pack voltage on a known vector;
- trend detection for a rising (exactly 2.00 mV/s), falling and constant spread;
- threshold policy shape (tighter mid-SoC, wider under load, rate cap, crit = 2 × warn);
- same spread → WARNING at rest, OK at 2C;
- balance mask selection and bounds;
- rejection of non-monotonic timestamps; under-voltage fault;
- observer invocation.

All pass at every tested cell count.

---

## 8. Limitations and future work

- SoC uses coulomb counting with an OCV seed; an extended Kalman filter would correct drift.
- Threshold tables are for NMC; LFP has an even flatter OCV curve and needs its own table (it would only change the two lookup tables).
- Temperature is not modelled; a temperature input would add a third axis to the threshold policy.
- Active (charge-shuttling) balancing could reuse the same `balance_mask` plus `weakest_idx` as source/target.
