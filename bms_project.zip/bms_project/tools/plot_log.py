#!/usr/bin/env python3
"""Plot BMS engine CSV logs and the scaling benchmark.

    python3 tools/plot_log.py logs            # every log_*.csv in logs/
    python3 tools/plot_log.py logs/x.csv      # one file
Writes PNGs next to the CSVs (and docs/scaling.png if bench_results.csv exists).
"""
import csv, glob, os, sys
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

LEVEL_Y = {"OK": 0, "WARNING": 1, "CRITICAL": 2}


def load(path):
    with open(path) as f:
        rows = list(csv.DictReader(f))
    cols = {k: [r[k] for r in rows] for k in rows[0]}
    num = lambda k: [float(x) for x in cols[k]]
    return cols, num


def plot_log(path):
    cols, num = load(path)
    t = [x / 60 for x in num("t_s")]
    cells = sorted([k for k in cols if k.startswith("cell")], key=lambda k: int(k[4:-3]))
    fig, ax = plt.subplots(4, 1, figsize=(11, 11), sharex=True,
                           gridspec_kw={"height_ratios": [3, 2, 1.4, 1.2]})

    for k in cells:
        ax[0].plot(t, num(k), lw=0.8, label=k.replace("_mv", "").replace("cell", "C"))
    ax[0].set_ylabel("cell voltage (mV)")
    ax[0].legend(ncol=8 if len(cells) > 8 else len(cells), fontsize=7, loc="lower left")
    ax[0].set_title(os.path.basename(path))

    ax[1].plot(t, num("imbalance_mv"), color="#222", lw=1, label="imbalance")
    ax[1].plot(t, num("warn_mv"), color="#d9a400", lw=1.2, ls="--", label="adaptive WARN")
    ax[1].plot(t, num("crit_mv"), color="#c0392b", lw=1.2, ls="--", label="adaptive CRIT")
    ax[1].set_ylabel("mV"); ax[1].legend(fontsize=8, loc="upper right")
    ax[1].set_ylim(0, max(max(num("imbalance_mv")), max(num("crit_mv"))) * 1.1)

    ax[2].plot(t, num("soc_pct"), color="#2e86de", lw=1.2, label="SoC %")
    ax2 = ax[2].twinx()
    ax2.plot(t, [float(x) / 1000 for x in cols["current_ma"]], color="#888", lw=0.8)
    ax2.set_ylabel("current (A)", color="#888")
    ax[2].set_ylabel("SoC (%)", color="#2e86de")

    ax[3].step(t, [LEVEL_Y[x] for x in cols["level"]], where="post", color="#c0392b", label="level")
    ax3b = ax[3].twinx()
    ax3b.fill_between(t, [float(x) for x in cols["balance_count"]], step="post",
                      color="#27ae60", alpha=0.35)
    ax3b.set_ylim(0, len(cells)); ax3b.set_ylabel("cells bleeding", color="#27ae60")
    ax[3].set_yticks([0, 1, 2]); ax[3].set_yticklabels(["OK", "WARN", "CRIT"])
    ax[3].set_xlabel("time (min)"); ax[3].legend(fontsize=8, loc="upper left")
    for a in ax: a.grid(alpha=0.25)
    fig.tight_layout()
    out = path.replace(".csv", ".png")
    fig.savefig(out, dpi=110); plt.close(fig)
    print("wrote", out)


def plot_bench(path, out):
    _, num = load(path)
    n = num("cells")
    fig, ax = plt.subplots(1, 2, figsize=(10, 3.6))
    ax[0].plot(n, num("update_ns"), "o-"); ax[0].set_title("bms_update() time (PC, -O2)")
    ax[0].set_xlabel("cells"); ax[0].set_ylabel("ns per update")
    ax[1].plot(n, num("engine_bytes"), "o-", label="whole engine")
    ax[1].plot(n, num("trend_buffer_bytes"), "s--", label="trend buffer (fixed)")
    ax[1].set_title("RAM footprint"); ax[1].set_xlabel("cells"); ax[1].set_ylabel("bytes")
    ax[1].legend(fontsize=8)
    for a in ax: a.grid(alpha=0.3); a.set_xticks(n)
    fig.tight_layout(); fig.savefig(out, dpi=110); plt.close(fig)
    print("wrote", out)


if __name__ == "__main__":
    target = sys.argv[1] if len(sys.argv) > 1 else "logs"
    files = sorted(glob.glob(os.path.join(target, "log_*.csv"))) if os.path.isdir(target) else [target]
    for f in files:
        plot_log(f)
    if os.path.exists("bench_results.csv"):
        os.makedirs("docs", exist_ok=True)
        plot_bench("bench_results.csv", "docs/scaling.png")
