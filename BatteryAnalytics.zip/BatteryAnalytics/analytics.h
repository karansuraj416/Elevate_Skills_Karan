#pragma once
// ============================================================================
//  Battery analytics core
//  - composite risk score (imbalance level + trend, fault frequency, SoC, temp)
//  - 4-level state machine with hysteresis and latched CRITICAL (operator ACK)
//  - structured fault / transition history (lossless event queue)
//  - human-readable maintenance recommendations + executive summary
//
//  Pure C++ (no Arduino dependencies) so the logic can be unit-tested on a PC.
// ============================================================================
#include <stdint.h>
#include <stdio.h>
#include <stdarg.h>
#include <string.h>
#include <math.h>

namespace bat {

enum State : uint8_t { NORMAL = 0, WARNING = 1, FAULT = 2, CRITICAL = 3 };

struct StateStyle { const char* name; const char* icon; const char* color; };

// ---- Keep names / order / colours identical to the Task 4 state machine ----
static const StateStyle STYLE[4] = {
  { "NORMAL",   "✅", "#23C48E" },   // green
  { "WARNING",  "⚠️", "#ED9D00" },   // amber
  { "FAULT",    "❌", "#D3435C" },   // red
  { "CRITICAL", "⛔", "#7A0019" },   // dark red, latched until ACK
};

enum FaultBit : uint16_t {
  F_OVERTEMP    = 1 << 0,
  F_UNDERVOLT   = 1 << 1,
  F_OVERVOLT    = 1 << 2,
  F_OVERCURRENT = 1 << 3,
  F_IMBALANCE   = 1 << 4,
  F_LOW_SOC     = 1 << 5,
  F_HIGH_RISK   = 1 << 6,
  F_RECURRING   = 1 << 7,
  F_FAULT_STORM = 1 << 8,
};
static const char* const FAULT_NAMES[9] = {
  "OVERTEMP", "UNDERVOLT", "OVERVOLT", "OVERCURRENT", "IMBALANCE",
  "LOW_SOC", "HIGH_RISK", "RECURRING", "FAULT_STORM"
};

inline void faultsToString(uint16_t mask, char* out, size_t n) {
  out[0] = 0;
  if (!mask) { snprintf(out, n, "none"); return; }
  size_t len = 0;
  for (int i = 0; i < 9; i++) {
    if (!(mask & (1u << i))) continue;
    int w = snprintf(out + len, n - len, "%s%s", len ? "|" : "", FAULT_NAMES[i]);
    if (w < 0 || (size_t)w >= n - len) break;
    len += w;
  }
}

inline float clampf(float v, float lo, float hi) { return v < lo ? lo : (v > hi ? hi : v); }

struct Thresholds {
  float tWarn = 45, tFault = 50, tCrit = 60;                    // temperature, C
  float vLowWarn = 3.20f, vLowFault = 3.00f, vLowCrit = 2.80f;  // min cell, V
  float vHighWarn = 4.15f, vHighFault = 4.20f, vHighCrit = 4.25f; // max cell, V
  float iWarn = 25, iFault = 30, iCrit = 40;                    // |current|, A
  float imbWarn = 80, imbFault = 150, imbCrit = 300;            // cell delta, mV
  float socWarn = 20, socFault = 10;                            // %
  float riskWarn = 50, riskCrit = 85;                           // composite 0-100
  uint32_t faultWindowSec = 600;  // fault-frequency window
  uint8_t  recurringCount = 2;    // faults in window -> WARNING (recurring)
  uint8_t  stormCount     = 3;    // faults in window -> CRITICAL (fault storm)
  uint8_t  clearSamples   = 3;    // consecutive clear samples before stepping down
};

struct Telemetry {
  float packV = 0, currentA = 0, soc = 0, tempC = 0, cellMinV = 0, cellMaxV = 0;
  bool     hasBackendState = false;  // backend (Task 4) reports its own state -> mirror it
  uint8_t  backendState = 0;
  uint16_t backendFaults = 0;
};

struct Event {
  uint32_t id;
  uint32_t tSec;        // uptime seconds when it happened
  State    from, to;
  bool     stateChange; // false = operator / info event
  uint16_t faults;
  float    risk;
  char     reason[80];
};

class Analytics {
public:
  Thresholds th;

  // live outputs
  float    imbalanceMv = 0, imbSlopeMvMin = 0, risk = 0, riskEma = 0, health = 100;
  float    riskParts[5] = {0, 0, 0, 0, 0};  // imbalance, trend, fault freq, SoC, temp
  uint8_t  faultsInWindow = 0;
  uint32_t faultTotal = 0, transitionCount = 0, droppedEvents = 0;
  uint16_t activeFaults = 0;
  bool     acked = false;

  void reset() { Thresholds keep = th; *this = Analytics(); th = keep; }

  State state() const { return cur_; }
  const Telemetry& lastTelemetry() const { return last_; }

  // Feed one sample (or one backend message). Every resulting transition is queued.
  void update(const Telemetry& t, uint32_t nowSec) {
    last_ = t; now_ = nowSec;
    mirror_ = t.hasBackendState && t.backendState <= CRITICAL;

    imbalanceMv = (t.cellMaxV - t.cellMinV) * 1000.0f;
    if (imbalanceMv < 0) imbalanceMv = 0;
    pushImbalance(nowSec, imbalanceMv);
    imbSlopeMvMin = imbalanceSlope();
    pruneFaults(nowSec);
    risk = computeRisk(t);
    riskEma = (samples_ == 0) ? risk : riskEma + 0.05f * (risk - riskEma);

    if (samples_ > 0 && nowSec > lastSec_) timeIn_[cur_] += nowSec - lastSec_;
    lastSec_ = nowSec; samples_++;

    char reason[80]; uint16_t mask = 0;
    State target = evaluate(t, mask, reason, sizeof reason);
    if (mirror_) {
      target = (State)t.backendState;
      mask |= t.backendFaults;
      if (!reason[0]) snprintf(reason, sizeof reason, "Reported by backend");
    }
    activeFaults = mask;
    step(target, mask, reason);
    health = clampf(100.0f - 0.6f * riskEma - fminf(3.0f * faultTotal, 30.0f), 0, 100);
  }

  // Operator acknowledgement of a latched CRITICAL alarm.
  bool acknowledge(uint32_t nowSec) {
    if (cur_ != CRITICAL || acked) return false;
    acked = true; now_ = nowSec;
    push(cur_, cur_, false, activeFaults, "Operator acknowledged CRITICAL alarm");
    return true;
  }

  // Lossless event queue (drained by the Blynk layer when connected).
  bool popEvent(Event& e) {
    if (!qCount_) return false;
    e = q_[qTail_]; qTail_ = (qTail_ + 1) % Q_N; qCount_--;
    return true;
  }
  uint8_t pendingEvents() const { return qCount_; }

  // % of time operational (NORMAL or WARNING)
  float availabilityPct() const {
    uint32_t total = timeIn_[0] + timeIn_[1] + timeIn_[2] + timeIn_[3];
    return total ? 100.0f * (timeIn_[0] + timeIn_[1]) / total : 100.0f;
  }
  uint32_t secondsIn(State s) const { return timeIn_[s]; }

  const char* healthGrade() const { return health >= 80 ? "Good" : health >= 60 ? "Fair" : "Poor"; }

  // Up to 4 numbered, prioritised maintenance suggestions, one per line.
  void recommendations(char* out, size_t n) const {
    out[0] = 0; int k = 0; const Telemetry& t = last_;
    const int MAXK = 4;
    if (cur_ == CRITICAL && !acked)
      add(out, n, k, MAXK, "Isolate the pack (open main contactor), inspect it, then press ACK.");
    else if (cur_ == CRITICAL)
      add(out, n, k, MAXK, "Alarm acknowledged - keep the pack isolated until the state drops below CRITICAL.");

    if (t.tempC >= th.tFault)
      add(out, n, k, MAXK, "Shed load and increase cooling: temperature %.1f C (fault limit %.0f C).", t.tempC, th.tFault);
    else if (t.tempC >= th.tWarn)
      add(out, n, k, MAXK, "Temperature %.1f C is approaching the %.0f C limit - check airflow and heatsinking.", t.tempC, th.tFault);

    if (t.cellMinV > 0 && t.cellMinV < th.vLowFault)
      add(out, n, k, MAXK, "Stop discharge: weakest cell at %.2f V. Recharge at C/10 and inspect that cell.", t.cellMinV);
    if (t.cellMaxV > th.vHighFault)
      add(out, n, k, MAXK, "Stop charging: highest cell at %.2f V - check charger and BMS cut-off.", t.cellMaxV);

    if (fabsf(t.currentA) >= th.iFault)
      add(out, n, k, MAXK, "Current %.1f A exceeds the %.0f A rating - check the load and wiring for shorts.", fabsf(t.currentA), th.iFault);

    if (imbalanceMv >= th.imbFault)
      add(out, n, k, MAXK, "Cell imbalance %.0f mV - run a full balancing charge and inspect the weakest cell.", imbalanceMv);
    else if (imbSlopeMvMin > 10)
      add(out, n, k, MAXK, "Imbalance rising %.1f mV/min - schedule balancing before the next cycle.", imbSlopeMvMin);
    else if (imbalanceMv >= th.imbWarn)
      add(out, n, k, MAXK, "Imbalance %.0f mV is above %.0f mV - enable balancing at the next charge.", imbalanceMv, th.imbWarn);

    if (faultsInWindow >= th.recurringCount)
      add(out, n, k, MAXK, "%u faults in the last %lu min - schedule an inspection of connectors and BMS wiring.",
          (unsigned)faultsInWindow, (unsigned long)(th.faultWindowSec / 60));

    if (t.soc < th.socWarn)
      add(out, n, k, MAXK, "Recharge soon: SoC %.0f%%.", t.soc);

    if (health < 60)
      add(out, n, k, MAXK, "Health index %.0f/100 - plan a capacity test and possible cell replacement.", health);

    if (k == 0)
      add(out, n, k, MAXK, "All parameters nominal - no action needed. Routine: verify cell balance at full charge.");
  }

  // One-line executive summary. uptimeSec = device uptime.
  void summary(char* out, size_t n, uint32_t uptimeSec) const {
    snprintf(out, n,
      "%s %s | Health %.0f/100 (%s) | Uptime %luh%02lum, availability %.1f%% | Faults %lu total, %u in last %lu min | Risk %.0f/100",
      STYLE[cur_].icon, STYLE[cur_].name, health, healthGrade(),
      (unsigned long)(uptimeSec / 3600), (unsigned long)((uptimeSec / 60) % 60), availabilityPct(),
      (unsigned long)faultTotal, (unsigned)faultsInWindow, (unsigned long)(th.faultWindowSec / 60), risk);
  }

  void riskBreakdown(char* out, size_t n) const {
    snprintf(out, n, "Imbalance %.0f + Trend %.0f + Fault freq %.0f + SoC %.0f + Temp %.0f = %.0f",
             riskParts[0], riskParts[1], riskParts[2], riskParts[3], riskParts[4], risk);
  }

private:
  static const int IMB_N = 30;   // imbalance history used for trend (30 samples)
  static const int F_N = 16;     // fault timestamp history
  static const int Q_N = 32;     // event queue depth

  State cur_ = NORMAL;
  Telemetry last_;
  uint32_t now_ = 0, lastSec_ = 0, samples_ = 0, timeIn_[4] = {0, 0, 0, 0};
  uint8_t clear_ = 0;
  bool mirror_ = false;

  float imbV_[IMB_N]; uint32_t imbT_[IMB_N]; int imbHead_ = 0, imbCount_ = 0;
  uint32_t fT_[F_N]; int fHead_ = 0, fCount_ = 0;
  Event q_[Q_N]; int qHead_ = 0, qTail_ = 0, qCount_ = 0; uint32_t eventId_ = 0;

  static void add(char* out, size_t n, int& k, int maxK, const char* fmt, ...) {
    if (k >= maxK) return;
    size_t len = strlen(out);
    if (len >= n - 1) return;
    int w = snprintf(out + len, n - len, "%s%d. ", len ? "\n" : "", k + 1);
    if (w < 0 || (size_t)w >= n - len) return;
    len += w;
    va_list ap; va_start(ap, fmt);
    vsnprintf(out + len, n - len, fmt, ap);
    va_end(ap);
    k++;
  }

  void pushImbalance(uint32_t t, float v) {
    imbV_[imbHead_] = v; imbT_[imbHead_] = t;
    imbHead_ = (imbHead_ + 1) % IMB_N;
    if (imbCount_ < IMB_N) imbCount_++;
  }

  // Least-squares slope of imbalance over the history window, mV per minute.
  float imbalanceSlope() const {
    int n = imbCount_;
    if (n < 5) return 0;
    uint32_t t0 = imbT_[(imbHead_ + IMB_N - n) % IMB_N];
    double sx = 0, sy = 0, sxx = 0, sxy = 0;
    for (int i = 0; i < n; i++) {
      int k = (imbHead_ + IMB_N - n + i) % IMB_N;
      double x = (double)(imbT_[k] - t0) / 60.0, y = imbV_[k];
      sx += x; sy += y; sxx += x * x; sxy += x * y;
    }
    double d = n * sxx - sx * sx;
    return fabs(d) < 1e-9 ? 0.0f : (float)((n * sxy - sx * sy) / d);
  }

  void recordFault(uint32_t t) {
    fT_[fHead_] = t; fHead_ = (fHead_ + 1) % F_N;
    if (fCount_ < F_N) fCount_++;
    faultTotal++;
    pruneFaults(t);
  }

  void pruneFaults(uint32_t now) {
    uint8_t c = 0;
    for (int i = 0; i < fCount_; i++) {
      int k = (fHead_ + F_N - 1 - i) % F_N;
      if (now - fT_[k] < th.faultWindowSec) c++;
    }
    faultsInWindow = c;
  }

  float computeRisk(const Telemetry& t) {
    riskParts[0] = 30.0f * clampf(imbalanceMv / th.imbFault, 0, 1);
    riskParts[1] = 20.0f * clampf(imbSlopeMvMin / 20.0f, 0, 1);
    riskParts[2] = 25.0f * clampf((float)faultsInWindow / th.stormCount, 0, 1);
    riskParts[3] = 15.0f * clampf((60.0f - t.soc) / 50.0f, 0, 1);
    riskParts[4] = 10.0f * clampf((t.tempC - 35.0f) / (th.tFault - 35.0f), 0, 1);
    return riskParts[0] + riskParts[1] + riskParts[2] + riskParts[3] + riskParts[4];
  }

  // Severity demanded by the current data (worst condition wins).
  State evaluate(const Telemetry& t, uint16_t& mask, char* reason, size_t n) {
    State s = NORMAL; mask = 0; reason[0] = 0;
    auto hit = [&](State lvl, uint16_t bit, const char* fmt, float v) {
      mask |= bit;
      if (lvl > s) { s = lvl; snprintf(reason, n, fmt, v); }
    };
    float ia = fabsf(t.currentA);

    if      (t.tempC >= th.tCrit)  hit(CRITICAL, F_OVERTEMP, "Over-temperature %.1f C", t.tempC);
    else if (t.tempC >= th.tFault) hit(FAULT,    F_OVERTEMP, "Over-temperature %.1f C", t.tempC);
    else if (t.tempC >= th.tWarn)  hit(WARNING,  F_OVERTEMP, "High temperature %.1f C", t.tempC);

    if      (t.cellMinV < th.vLowCrit)  hit(CRITICAL, F_UNDERVOLT, "Cell under-voltage %.2f V", t.cellMinV);
    else if (t.cellMinV < th.vLowFault) hit(FAULT,    F_UNDERVOLT, "Cell under-voltage %.2f V", t.cellMinV);
    else if (t.cellMinV < th.vLowWarn)  hit(WARNING,  F_UNDERVOLT, "Low cell voltage %.2f V", t.cellMinV);

    if      (t.cellMaxV > th.vHighCrit)  hit(CRITICAL, F_OVERVOLT, "Cell over-voltage %.2f V", t.cellMaxV);
    else if (t.cellMaxV > th.vHighFault) hit(FAULT,    F_OVERVOLT, "Cell over-voltage %.2f V", t.cellMaxV);
    else if (t.cellMaxV > th.vHighWarn)  hit(WARNING,  F_OVERVOLT, "High cell voltage %.2f V", t.cellMaxV);

    if      (ia >= th.iCrit)  hit(CRITICAL, F_OVERCURRENT, "Over-current %.1f A", ia);
    else if (ia >= th.iFault) hit(FAULT,    F_OVERCURRENT, "Over-current %.1f A", ia);
    else if (ia >= th.iWarn)  hit(WARNING,  F_OVERCURRENT, "High current %.1f A", ia);

    if      (imbalanceMv >= th.imbCrit)  hit(CRITICAL, F_IMBALANCE, "Cell imbalance %.0f mV", imbalanceMv);
    else if (imbalanceMv >= th.imbFault) hit(FAULT,    F_IMBALANCE, "Cell imbalance %.0f mV", imbalanceMv);
    else if (imbalanceMv >= th.imbWarn)  hit(WARNING,  F_IMBALANCE, "Cell imbalance %.0f mV", imbalanceMv);

    if      (t.soc < th.socFault) hit(FAULT,   F_LOW_SOC, "SoC critically low %.0f%%", t.soc);
    else if (t.soc < th.socWarn)  hit(WARNING, F_LOW_SOC, "Low SoC %.0f%%", t.soc);

    if      (risk >= th.riskCrit) hit(CRITICAL, F_HIGH_RISK, "Composite risk %.0f/100", risk);
    else if (risk >= th.riskWarn) hit(WARNING,  F_HIGH_RISK, "Composite risk %.0f/100", risk);

    if (faultsInWindow >= th.recurringCount)
      hit(WARNING, F_RECURRING, "Recurring faults: %.0f in window", (float)faultsInWindow);
    return s;
  }

  void step(State target, uint16_t mask, const char* reason) {
    if (mirror_) {                       // backend is the source of truth: mirror every change
      clear_ = 0;
      if (target != cur_) transition(target, mask, reason);
      return;
    }
    if (target > cur_) { transition(target, mask, reason); return; }   // escalate immediately
    if (target == cur_) { clear_ = 0; return; }
    if (cur_ == CRITICAL && !acked) { clear_ = 0; return; }             // latched
    if (++clear_ < th.clearSamples) return;                             // hysteresis
    char why[80];
    if (target == NORMAL) snprintf(why, sizeof why, "Recovered: all parameters nominal");
    else                  snprintf(why, sizeof why, "Stepped down: %s", reason);
    transition(target, mask, why);
  }

  void transition(State to, uint16_t mask, const char* reason) {
    State from = cur_;
    cur_ = to; clear_ = 0; transitionCount++;
    if (to == CRITICAL || from == CRITICAL) acked = false;
    bool faultEvent = (to >= FAULT && from < FAULT);
    if (faultEvent) recordFault(now_);
    push(from, to, true, mask, reason);
    if (faultEvent && !mirror_ && to == FAULT && faultsInWindow >= th.stormCount) {
      char why[80];
      snprintf(why, sizeof why, "Fault storm: %u faults in %lu s",
               (unsigned)faultsInWindow, (unsigned long)th.faultWindowSec);
      transition(CRITICAL, mask | F_FAULT_STORM, why);
    }
  }

  void push(State from, State to, bool change, uint16_t mask, const char* reason) {
    if (qCount_ == Q_N) { qTail_ = (qTail_ + 1) % Q_N; qCount_--; droppedEvents++; }
    Event& e = q_[qHead_];
    e.id = ++eventId_; e.tSec = now_; e.from = from; e.to = to;
    e.stateChange = change; e.faults = mask; e.risk = risk;
    snprintf(e.reason, sizeof e.reason, "%s", reason);
    qHead_ = (qHead_ + 1) % Q_N; qCount_++;
  }
};

} // namespace bat
