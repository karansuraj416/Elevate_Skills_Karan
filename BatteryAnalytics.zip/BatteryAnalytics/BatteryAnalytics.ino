/*
  Enterprise Blynk Analytics & Decision Dashboard — Battery Pack
  ----------------------------------------------------------------
  Board   : ESP32 (Arduino core 2.x / 3.x)
  Library : Blynk >= 1.3  (Blynk IoT / blynk.cloud)

  Data sources (switch on the dashboard, V15):
    DEMO    : scripted ~5.5 min scenario that visits every state (demo.h)
    BACKEND : CSV lines from the Task 4 backend on Serial2, one per sample:
                packV,currentA,soc,tempC,cellMinV,cellMaxV[,state,faultMask]
              If state (0=NORMAL 1=WARNING 2=FAULT 3=CRITICAL) is sent, the dashboard
              MIRRORS the backend state machine exactly; otherwise it computes it.
              Each backend line is processed the moment it arrives, so no
              transition is missed between dashboard refreshes.

  Every state transition is placed in a lossless queue and pushed to Blynk in
  order (fault-history terminal, state chart, colour/icon, timeline event).
  If Wi-Fi/Blynk drops, transitions are held and flushed on reconnect.
*/

#define BLYNK_TEMPLATE_ID   "TMPL_REPLACE_ME"
#define BLYNK_TEMPLATE_NAME "Battery Analytics"
#define BLYNK_AUTH_TOKEN    "REPLACE_ME"
#define BLYNK_PRINT Serial

#include <WiFi.h>
#include <WiFiClient.h>
#include <BlynkSimpleEsp32.h>
#include <time.h>
#include "analytics.h"
#include "demo.h"

const char WIFI_SSID[] = "REPLACE_ME";
const char WIFI_PASS[] = "REPLACE_ME";

// ---------------- configuration ----------------
#define BACKEND_RX    16
#define BACKEND_TX    17
#define BACKEND_BAUD  115200
const long     TZ_OFFSET_SEC       = 19800;  // IST (UTC+5:30)
const uint32_t PUBLISH_MS          = 2000;   // dashboard refresh / demo sample period
const uint32_t BACKEND_TIMEOUT_MS  = 10000;
const uint32_t DEMO_FAULT_WINDOW   = 180;    // shorter window so the demo recovers in one run
const uint32_t LIVE_FAULT_WINDOW   = 600;
const uint32_t DEMO_AUTO_ACK_SEC   = 240;    // demo auto-ACK at this point if nobody pressed ACK; 0 = never
const bool     NOTIFY_RECOVERIES   = true;   // also log de-escalations as Blynk events

// ---------------- virtual pins ----------------
#define VP_PACK_V       V0
#define VP_CURRENT      V1
#define VP_SOC          V2
#define VP_TEMP         V3
#define VP_IMBALANCE    V4
#define VP_RISK         V5
#define VP_STATE_CODE   V6
#define VP_STATE_LABEL  V7
#define VP_RECO         V8
#define VP_FAULTLOG     V9
#define VP_HEALTH       V10
#define VP_UPTIME       V11
#define VP_FAULT_TOTAL  V12
#define VP_SUMMARY      V13
#define VP_ACK          V14
#define VP_DEMO         V15
#define VP_FAULT_FREQ   V16
#define VP_IMB_TREND    V17
#define VP_STATE_LED    V18
#define VP_TRANSITIONS  V19
#define VP_TOP_RECO     V20
#define VP_AVAIL        V21
#define VP_ACTIVE       V22
#define VP_RISK_PARTS   V23
#define VP_RESET        V24

BlynkTimer timer;
bat::Analytics A;
WidgetTerminal recoTerm(VP_RECO);
WidgetTerminal faultTerm(VP_FAULTLOG);

bool     demoMode = true;
uint32_t demoStartSec = 0;
uint32_t backendLastMs = 0;
bool     backendSeen = false;
char     lineBuf[128];
uint8_t  lineLen = 0;
char     lastReco[600] = "";
int      lastPubState = -1, lastPubAck = -1, lastRiskBand = -1, lastHealthBand = -1;

static uint32_t nowSec() { return millis() / 1000; }
static float r2(float v) { return roundf(v * 100.0f) / 100.0f; }

static void fmtDuration(uint32_t s, char* out, size_t n) {
  snprintf(out, n, "%lud %02lu:%02lu:%02lu", (unsigned long)(s / 86400), (unsigned long)((s / 3600) % 24),
           (unsigned long)((s / 60) % 60), (unsigned long)(s % 60));
}

// Event time -> wall clock (after NTP sync) or T+uptime.
static void fmtClock(uint32_t tSec, char* out, size_t n) {
  time_t wall = time(nullptr);
  if (wall > 1700000000) {
    time_t at = wall - (time_t)(nowSec() - tSec);
    struct tm tmv; localtime_r(&at, &tmv);
    strftime(out, n, "%d-%b %H:%M:%S", &tmv);
  } else {
    snprintf(out, n, "T+%lus", (unsigned long)tSec);
  }
}

// ---------------- state widgets ----------------
static void writeStateWidgets(bat::State s) {
  const bat::StateStyle& st = bat::STYLE[s];
  char label[64];
  if (s == bat::CRITICAL)
    snprintf(label, sizeof label, "%s %s %s", st.icon, st.name, A.acked ? "(ACKNOWLEDGED)" : "- ACK REQUIRED");
  else
    snprintf(label, sizeof label, "%s %s", st.icon, st.name);
  Blynk.virtualWrite(VP_STATE_CODE, (int)s);
  Blynk.virtualWrite(VP_STATE_LABEL, label);
  Blynk.setProperty(VP_STATE_LABEL, "color", st.color);
  Blynk.virtualWrite(VP_STATE_LED, 255);
  Blynk.setProperty(VP_STATE_LED, "color", st.color);
}

static void publishState(bool force) {
  int s = A.state(), ack = A.acked;
  if (!force && s == lastPubState && ack == lastPubAck) return;
  writeStateWidgets(A.state());
  Blynk.virtualWrite(VP_TRANSITIONS, (unsigned long)A.transitionCount);
  lastPubState = s; lastPubAck = ack;
}

// ---------------- fault history ----------------
static void pushEvent(const bat::Event& e) {
  char when[24], faults[120], line[300];
  fmtClock(e.tSec, when, sizeof when);
  bat::faultsToString(e.faults, faults, sizeof faults);
  if (e.stateChange)
    snprintf(line, sizeof line, "#%03lu %s  %s %s -> %s %s | %s | risk %.0f | %s",
             (unsigned long)e.id, when, bat::STYLE[e.from].icon, bat::STYLE[e.from].name,
             bat::STYLE[e.to].icon, bat::STYLE[e.to].name, e.reason, e.risk, faults);
  else
    snprintf(line, sizeof line, "#%03lu %s  [OPERATOR] %s", (unsigned long)e.id, when, e.reason);

  Serial.println(line);
  faultTerm.println(line);
  faultTerm.flush();

  if (e.stateChange) {
    // Write each intermediate state so the state chart records every step.
    writeStateWidgets(e.to);
    static const char* const EVT[4] = { "state_normal", "state_warning", "state_fault", "state_critical" };
    if (e.to > e.from || NOTIFY_RECOVERIES) Blynk.logEvent(EVT[e.to], line);
  } else {
    Blynk.logEvent("operator_ack", e.reason);
  }
}

static void drainEvents() {
  if (!Blynk.connected()) return;          // keep queued until the link is back
  bat::Event e;
  bool any = false;
  while (A.popEvent(e)) { pushEvent(e); any = true; }
  if (A.droppedEvents) {
    char m[64]; snprintf(m, sizeof m, "!! %lu events lost while offline (queue full)", (unsigned long)A.droppedEvents);
    faultTerm.println(m); faultTerm.flush();
    A.droppedEvents = 0;
  }
  if (any) publishState(true);
}

// ---------------- analytics widgets ----------------
static int band(float v, float a, float b) { return v < a ? 0 : (v < b ? 1 : 2); }

static void publishMetrics() {
  const bat::Telemetry& t = A.lastTelemetry();
  Blynk.virtualWrite(VP_PACK_V,    r2(t.packV));
  Blynk.virtualWrite(VP_CURRENT,   r2(t.currentA));
  Blynk.virtualWrite(VP_SOC,       r2(t.soc));
  Blynk.virtualWrite(VP_TEMP,      r2(t.tempC));
  Blynk.virtualWrite(VP_IMBALANCE, r2(A.imbalanceMv));
  Blynk.virtualWrite(VP_RISK,      r2(A.risk));
  Blynk.virtualWrite(VP_HEALTH,    r2(A.health));
  Blynk.virtualWrite(VP_FAULT_TOTAL, (unsigned long)A.faultTotal);
  Blynk.virtualWrite(VP_FAULT_FREQ,  (int)A.faultsInWindow);
  Blynk.virtualWrite(VP_IMB_TREND,   r2(A.imbSlopeMvMin));
  Blynk.virtualWrite(VP_AVAIL,       r2(A.availabilityPct()));

  char buf[300];
  fmtDuration(nowSec(), buf, sizeof buf);
  Blynk.virtualWrite(VP_UPTIME, buf);
  A.summary(buf, sizeof buf, nowSec());
  Blynk.virtualWrite(VP_SUMMARY, buf);
  bat::faultsToString(A.activeFaults, buf, sizeof buf);
  Blynk.virtualWrite(VP_ACTIVE, buf);
  A.riskBreakdown(buf, sizeof buf);
  Blynk.virtualWrite(VP_RISK_PARTS, buf);

  // Colour gauges by severity band (uses the same palette as the state machine).
  int rb = band(A.risk, 40, 70);
  if (rb != lastRiskBand) {
    Blynk.setProperty(VP_RISK, "color", bat::STYLE[rb == 0 ? 0 : rb == 1 ? 1 : 2].color);
    lastRiskBand = rb;
  }
  int hb = 2 - band(A.health, 60, 80);   // high health = good
  if (hb != lastHealthBand) {
    Blynk.setProperty(VP_HEALTH, "color", bat::STYLE[hb].color);
    lastHealthBand = hb;
  }

  // Recommendations: rewrite only when the advice changes.
  char reco[600];
  A.recommendations(reco, sizeof reco);
  if (strcmp(reco, lastReco) != 0) {
    strncpy(lastReco, reco, sizeof lastReco - 1);
    recoTerm.clear();
    recoTerm.println(reco);
    recoTerm.flush();
    char first[160]; size_t i = 0;
    const char* p = reco + 3;                         // skip "1. "
    while (p[i] && p[i] != '\n' && i < sizeof first - 1) { first[i] = p[i]; i++; }
    first[i] = 0;
    Blynk.virtualWrite(VP_TOP_RECO, first);
  }
}

// ---------------- data sources ----------------
static void handleBackendLine(const char* s) {
  float v[6]; int st = -1; unsigned fm = 0;
  int n = sscanf(s, "%f,%f,%f,%f,%f,%f,%d,%u", &v[0], &v[1], &v[2], &v[3], &v[4], &v[5], &st, &fm);
  if (n < 6) return;
  bat::Telemetry t;
  t.packV = v[0]; t.currentA = v[1]; t.soc = v[2]; t.tempC = v[3]; t.cellMinV = v[4]; t.cellMaxV = v[5];
  if (n >= 7 && st >= 0 && st <= 3) {
    t.hasBackendState = true;
    t.backendState = (uint8_t)st;
    t.backendFaults = (n >= 8) ? (uint16_t)fm : 0;
  }
  backendLastMs = millis(); backendSeen = true;
  if (!demoMode) {
    A.update(t, nowSec());   // process immediately: no transition is skipped
    drainEvents();
  }
}

static void readBackend() {
  while (Serial2.available()) {
    char c = (char)Serial2.read();
    if (c == '\n' || c == '\r') {
      if (lineLen) { lineBuf[lineLen] = 0; handleBackendLine(lineBuf); lineLen = 0; }
    } else if (lineLen < sizeof(lineBuf) - 1) {
      lineBuf[lineLen++] = c;
    } else {
      lineLen = 0;  // overlong line: discard
    }
  }
}

static void tick() {
  if (demoMode) {
    uint32_t dt = nowSec() - demoStartSec;
    A.update(bat::demoTelemetry(dt), nowSec());
    if (DEMO_AUTO_ACK_SEC && A.state() == bat::CRITICAL && !A.acked &&
        (dt % bat::DEMO_PERIOD_SEC) >= DEMO_AUTO_ACK_SEC)
      A.acknowledge(nowSec());
  } else if (!backendSeen || millis() - backendLastMs > BACKEND_TIMEOUT_MS) {
    if (Blynk.connected())
      Blynk.virtualWrite(VP_SUMMARY, "NO DATA - Task 4 backend not reporting on Serial2");
    return;
  }
  if (!Blynk.connected()) return;
  drainEvents();
  publishState(false);
  publishMetrics();
}

static void setMode(bool demo) {
  demoMode = demo;
  demoStartSec = nowSec();
  A.th.faultWindowSec = demo ? DEMO_FAULT_WINDOW : LIVE_FAULT_WINDOW;
  faultTerm.println(demo ? "---- DEMO scenario started ----" : "---- LIVE backend data ----");
  faultTerm.flush();
}

// ---------------- Blynk handlers ----------------
BLYNK_CONNECTED() {
  Blynk.syncVirtual(VP_DEMO);
  faultTerm.println("---- dashboard link (re)connected ----");
  faultTerm.flush();
  lastReco[0] = 0; lastRiskBand = lastHealthBand = -1;
  drainEvents();
  publishState(true);
  publishMetrics();
}

BLYNK_WRITE(VP_ACK) {
  if (param.asInt() && A.acknowledge(nowSec())) { drainEvents(); publishState(true); publishMetrics(); }
}

BLYNK_WRITE(VP_DEMO) {
  bool on = param.asInt() != 0;
  if (on != demoMode) setMode(on);
}

BLYNK_WRITE(VP_RESET) {
  if (!param.asInt()) return;
  A.reset();
  A.th.faultWindowSec = demoMode ? DEMO_FAULT_WINDOW : LIVE_FAULT_WINDOW;
  demoStartSec = nowSec();
  recoTerm.clear(); faultTerm.clear();
  faultTerm.println("---- analytics reset by operator ----"); faultTerm.flush();
  lastReco[0] = 0; publishState(true);
}

void setup() {
  Serial.begin(115200);
  Serial2.begin(BACKEND_BAUD, SERIAL_8N1, BACKEND_RX, BACKEND_TX);
  A.th.faultWindowSec = DEMO_FAULT_WINDOW;
  demoStartSec = nowSec();

  WiFi.begin(WIFI_SSID, WIFI_PASS);
  Blynk.config(BLYNK_AUTH_TOKEN);     // non-blocking: analytics keep running offline
  configTime(TZ_OFFSET_SEC, 0, "pool.ntp.org", "time.google.com");

  timer.setInterval(PUBLISH_MS, tick);
}

void loop() {
  readBackend();
  if (WiFi.status() == WL_CONNECTED) Blynk.run();
  timer.run();
}
