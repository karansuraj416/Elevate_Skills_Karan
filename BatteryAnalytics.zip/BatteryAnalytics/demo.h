#pragma once
// Scripted 5-minute demonstration that drives the dashboard through every state:
//   NORMAL -> WARNING (imbalance drift) -> FAULT (imbalance) -> WARNING (balancing)
//   -> NORMAL -> FAULT (over-temp) -> WARNING (recurring faults) -> FAULT (over-current)
//   -> CRITICAL (fault storm, latched) -> [ACK] -> WARNING -> NORMAL (faults age out)
// Use a 180 s fault window in demo mode so the final recovery happens within the run.
#include "analytics.h"

namespace bat {

static const uint32_t DEMO_PERIOD_SEC = 300;

inline Telemetry demoTelemetry(uint32_t t) {
  uint32_t p = t % DEMO_PERIOD_SEC;
  float soc  = 85.0f - p * 0.15f;
  float temp = 30.0f + 0.5f * sinf(t * 0.3f);
  float cur  = 8.0f + 0.6f * sinf(t * 0.7f);
  float imb  = 20.0f + 2.0f * sinf(t * 0.5f);

  if      (p >=  40 && p <  80) { imb = 20.0f + (p - 40) * 2.0f; temp = 36; } // drift -> WARNING
  else if (p >=  80 && p < 100) { imb = 165; temp = 37; }                     // -> FAULT (imbalance)
  else if (p >= 100 && p < 112) { imb = 95;  temp = 35; }                     // balancing -> WARNING
  else if (p >= 112 && p < 150) { imb = 40;  temp = 33; }                     // -> NORMAL
  else if (p >= 150 && p < 170) { imb = 40;  temp = 52; }                     // -> FAULT (over-temp)
  else if (p >= 170 && p < 190) { imb = 40;  temp = 38; }                     // -> WARNING (recurring)
  else if (p >= 190 && p < 210) { imb = 45;  temp = 39; cur = 34; }           // -> FAULT -> CRITICAL
  else if (p >= 210)            { imb = 35;  temp = 34; }                     // latched until ACK

  Telemetry x;
  float avg  = 3.30f + 0.90f * soc / 100.0f;   // 4S Li-ion cell average
  x.soc      = soc;
  x.tempC    = temp;
  x.currentA = cur;
  x.cellMinV = avg - imb / 2000.0f;
  x.cellMaxV = avg + imb / 2000.0f;
  x.packV    = avg * 4.0f;
  return x;
}

} // namespace bat
