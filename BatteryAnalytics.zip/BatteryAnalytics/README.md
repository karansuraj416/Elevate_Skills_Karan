# Battery Analytics & Decision Dashboard (Blynk IoT + ESP32)

Files:

| File | Purpose |
|---|---|
| `BatteryAnalytics.ino` | Blynk layer: Wi-Fi, data sources, widget publishing, ACK/demo/reset controls |
| `analytics.h` | Core logic: risk score, state machine, fault history, recommendations, executive summary (plain C++) |
| `demo.h` | Scripted demonstration that drives every state transition |

Install **Blynk** (≥ 1.3) from the Library Manager, select an ESP32 board, fill in
`BLYNK_TEMPLATE_ID`, `BLYNK_TEMPLATE_NAME`, `BLYNK_AUTH_TOKEN`, `WIFI_SSID` and `WIFI_PASS`, then upload.

---

## 1. State model (match this to Task 4)

| Code | State | Icon | Colour | Entered when (any one) | Leaves when |
|---|---|---|---|---|---|
| 0 | NORMAL | ✅ | `#23C48E` green | nothing abnormal | — |
| 1 | WARNING | ⚠️ | `#ED9D00` amber | temp ≥ 45 °C, cell < 3.20 V or > 4.15 V, \|I\| ≥ 25 A, imbalance ≥ 80 mV, SoC < 20 %, risk ≥ 50, ≥ 2 faults in window | 3 consecutive clear samples |
| 2 | FAULT | ❌ | `#D3435C` red | temp ≥ 50 °C, cell < 3.00 V or > 4.20 V, \|I\| ≥ 30 A, imbalance ≥ 150 mV, SoC < 10 % | 3 consecutive clear samples |
| 3 | CRITICAL | ⛔ | `#7A0019` dark red | temp ≥ 60 °C, cell < 2.80 V or > 4.25 V, \|I\| ≥ 40 A, imbalance ≥ 300 mV, risk ≥ 85, **3rd fault inside the window (fault storm)** | **Latched** — operator ACK, then 3 clear samples |

Escalation is immediate; de-escalation uses hysteresis so the state doesn't flicker.
All names, colours and thresholds are in one place: `STYLE[]` and `Thresholds` at the top of `analytics.h`.

**If your Task 4 backend already runs its own state machine**, send its state as the
7th CSV field. The dashboard then mirrors it exactly (no hysteresis, no local overrides),
so the dashboard shows exactly the transitions the backend makes.

## 2. Composite risk score (0–100)

| Factor | Weight | Full score at |
|---|---|---|
| Cell imbalance level | 30 | ≥ 150 mV |
| Imbalance **trend** (least-squares slope over the last 30 samples) | 20 | ≥ +20 mV/min |
| Fault frequency (faults in window) | 25 | ≥ 3 faults |
| Low SoC | 15 | 10 % (starts at 60 %) |
| Temperature | 10 | ≥ 50 °C (starts at 35 °C) |

**Battery Health Index** = 100 − 0.6 × (slow moving average of risk) − 3 × total faults (capped at 30).
Grades: Good ≥ 80, Fair ≥ 60, Poor < 60.
**Availability** = share of time spent in NORMAL or WARNING.

## 3. Blynk template — datastreams

Create these in **Developer Zone → Templates → Datastreams** (all *Virtual Pin*).
Turn on history for the numeric ones so the charts show trends.

| Pin | Name | Type | Min–Max | Units | Decimals |
|---|---|---|---|---|---|
| V0 | Pack Voltage | Double | 0–20 | V | #.## |
| V1 | Current | Double | -50–50 | A | #.# |
| V2 | SoC | Double | 0–100 | % | #.# |
| V3 | Temperature | Double | 0–80 | °C | #.# |
| V4 | Cell Imbalance | Double | 0–400 | mV | #.# |
| V5 | Risk Score | Double | 0–100 | — | # |
| V6 | State Code | Integer | 0–3 | — | — |
| V7 | State | String | | | |
| V8 | Recommendations | String | | | |
| V9 | Fault History | String | | | |
| V10 | Health Index | Double | 0–100 | — | # |
| V11 | Uptime | String | | | |
| V12 | Fault Count | Integer | 0–10000 | | |
| V13 | Executive Summary | String | | | |
| V14 | ACK | Integer | 0–1 | | |
| V15 | Demo Mode | Integer | 0–1 | | (default 1) |
| V16 | Faults in Window | Integer | 0–16 | | |
| V17 | Imbalance Trend | Double | -200–200 | mV/min | #.# |
| V18 | State LED | Integer | 0–255 | | |
| V19 | Transitions | Integer | 0–100000 | | |
| V20 | Top Recommendation | String | | | |
| V21 | Availability | Double | 0–100 | % | #.# |
| V22 | Active Conditions | String | | | |
| V23 | Risk Breakdown | String | | | |
| V24 | Reset | Integer | 0–1 | | |

## 4. Events (Timeline / notifications)

Template → **Events & Notifications**, create:

| Event code | Type | Notify |
|---|---|---|
| `state_normal` | Info | — |
| `state_warning` | Warning | optional |
| `state_fault` | Critical | push |
| `state_critical` | Critical | push + email |
| `operator_ack` | Info | — |

Each transition is logged with the reason, risk and active conditions, so the device
**Timeline** is a second, server-side record of every transition.
Blynk limits how many events a device can log per day. If you run the demo for a long time,
set `NOTIFY_RECOVERIES = false` to log only escalations.

## 5. Dashboard layout (web dashboard; mobile uses the same widgets)

**Row 1 – Executive summary**
- Label **V7** State (large; colour is set from the code)
- LED **V18** (colour follows state)
- Gauge **V10** Health Index · Value **V11** Uptime · Value **V21** Availability % · Value **V12** Fault Count · Value **V19** Transitions
- Label **V13** Executive Summary (full width)

**Row 2 – Risk & decisions**
- Gauge **V5** Risk Score (colour changes green → amber → red)
- Label **V23** Risk Breakdown · Label **V22** Active Conditions
- Terminal **V8** Operator Recommendations (input off)
- Switch **V14** ACK (push mode) · Switch **V15** Demo Mode · Switch **V24** Reset (push mode)

**Row 3 – Historical trends** (SuperChart / Chart widgets)
- Chart A: **V4** Imbalance + **V17** Imbalance Trend
- Chart B: **V5** Risk + **V10** Health
- Chart C: **V3** Temperature + **V1** Current
- Chart D: **V2** SoC + **V0** Pack Voltage
- Chart E: **V6** State Code as a *step* line (0–3) — a visual timeline of every transition

**Row 4 – Fault history**
- Terminal **V9** Fault History (input off), full width

Example fault-history lines:
```
#007 20-Oct 21:42:13  ⚠️ WARNING -> ❌ FAULT | Over-current 34.0 A | risk 30 | OVERCURRENT|RECURRING
#008 20-Oct 21:42:13  ❌ FAULT -> ⛔ CRITICAL | Fault storm: 3 faults in 180 s | risk 30 | OVERCURRENT|RECURRING|FAULT_STORM
#009 20-Oct 21:42:57  [OPERATOR] Operator acknowledged CRITICAL alarm
```

## 6. Demonstration script (Demo Mode on)

The scenario lasts about 5½ minutes (it repeats every 300 s), using a 180 s fault window.
This sequence was verified by running `analytics.h` + `demo.h` on a PC:

| t (s) | Transition | Cause |
|---|---|---|
| 72 | NORMAL → WARNING | imbalance drifting up (84 mV, trend +120 mV/min) |
| 80 | WARNING → FAULT | imbalance 165 mV |
| 104 | FAULT → WARNING | balancing, 95 mV (after hysteresis) |
| 116 | WARNING → NORMAL | recovered |
| 150 | NORMAL → FAULT | over-temperature 52 °C |
| 174 | FAULT → WARNING | recurring faults (2 in window) |
| 190 | WARNING → FAULT | over-current 34 A |
| 190 | FAULT → CRITICAL | fault storm (3rd fault in window) — **latched** |
| ≤ 240 | ACK | press V14 during the demo; auto-ACK at 240 s otherwise |
| 246 | CRITICAL → WARNING | recurring faults still in window |
| ~334 | WARNING → NORMAL | old faults age out of the window |

During the demo, point out: the state colour and icon changing, the risk gauge band, recommendations
rewriting themselves (e.g. "Isolate the pack… press ACK" in CRITICAL), the state step chart,
and that the number of state-change lines in Fault History equals the Transitions counter.

## 7. Connecting the Task 4 backend

Send one CSV line per sample to the ESP32's Serial2 (RX = GPIO16, TX = GPIO17, 115200 baud, common GND):

```
packV,currentA,soc,tempC,cellMinV,cellMaxV[,state,faultMask]
14.82,8.1,72.5,31.2,3.69,3.72,0,0
```

Then switch **Demo Mode** off. Each line is processed as soon as it arrives (not on the 2 s
refresh), so even transitions shorter than the refresh period appear in the history.
If no data arrives for 10 s, the summary shows **NO DATA**.

## 8. Guarantee that no transition is missed

- Every transition (and every ACK) goes into a 32-entry ordered queue with a sequence number.
- The queue is drained only while Blynk is connected. During a Wi-Fi drop the analytics keep
  running and events wait; they're flushed in order on reconnect.
- If more than 32 events build up offline, the oldest are dropped and the terminal prints
  a "N events lost" line. Gaps are never silent.
- The `#id` numbers in the fault log run without gaps. The number of state-change lines equals `Transitions` (V19); ACK lines are numbered too but aren't counted as transitions.
