// Host-side unit tests for LcdEngine.h (no hardware needed).
// Build: g++ -std=c++17 -O2 -I.. test_engine.cpp -o test_engine && ./test_engine
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <random>
#include "../LcdEngine.h"

struct MockLcd {
  char ddram[4][20];
  int col = 0, row = 0;
  int clears = 0, writes = 0, moves = 0;
  void clear() { memset(ddram, ' ', sizeof(ddram)); col = row = 0; clears++; }
  void setCursor(uint8_t c, uint8_t r) { col = c; row = r; moves++; }
  size_t write(uint8_t ch) {
    if (col >= 20) { printf("FAIL: write past end of line\n"); exit(1); }
    ddram[row][col++] = (char)ch; writes++; return 1;
  }
  void resetCounters() { writes = moves = 0; }
};

static int failures = 0;
#define CHECK(cond, msg) do { if (!(cond)) { printf("FAIL: %s\n", msg); failures++; } else printf("pass: %s\n", msg); } while (0)

int main() {
  MockLcd m;
  LcdEngine<MockLcd> e(m);
  e.begin();

  // 1. First frame appears correctly
  e.beginFrame(); e.text(0, 0, "BATTERY        1/3"); e.textf(0, 1, "Volt: %5.2f V", 12.34);
  e.flush();
  CHECK(memcmp(m.ddram[1], "Volt: 12.34 V       ", 20) == 0, "first frame rendered");

  // 2. Identical frame -> zero LCD traffic
  m.resetCounters();
  e.beginFrame(); e.text(0, 0, "BATTERY        1/3"); e.textf(0, 1, "Volt: %5.2f V", 12.34);
  e.flush();
  CHECK(m.writes == 0 && m.moves == 0, "unchanged frame sends nothing");

  // 3. One digit changes -> 1 move + 1 char
  m.resetCounters();
  e.beginFrame(); e.text(0, 0, "BATTERY        1/3"); e.textf(0, 1, "Volt: %5.2f V", 12.35);
  e.flush();
  CHECK(m.writes == 1 && m.moves == 1, "single-digit change = 1 move + 1 write");

  // 4. Gap merging
  m.resetCounters();
  e.beginFrame(); e.text(0, 0, "BATTERY        1/3"); e.textf(0, 1, "Volt: %5.2f V", 12.35);
  e.put(0, 3, 'A'); e.put(2, 3, 'B');           // 1-char gap -> merged
  e.flush();
  CHECK(m.moves == 1 && m.writes == 3, "1-char gap merged into one run");
  m.resetCounters();
  e.beginFrame(); e.text(0, 0, "BATTERY        1/3"); e.textf(0, 1, "Volt: %5.2f V", 12.35);
  e.put(0, 3, 'A'); e.put(2, 3, 'B'); e.put(10, 3, 'C');  // far gap -> new run
  e.flush();
  CHECK(m.moves == 1 && m.writes == 1, "distant change uses a separate run");

  // 5. Clipping
  e.beginFrame(); e.text(15, 2, "0123456789"); e.flush();
  CHECK(memcmp(m.ddram[2] + 15, "01234", 5) == 0, "text clipped at column 20");

  // 6. Fuzz: random frames, LCD must always equal the frame, never cleared again
  std::mt19937 rng(42);
  char expect[4][20];
  for (int it = 0; it < 20000; ++it) {
    memset(expect, ' ', sizeof(expect));
    e.beginFrame();
    int n = rng() % 12;
    for (int k = 0; k < n; ++k) {
      int r = rng() % 4, c = rng() % 20; char ch = 'A' + rng() % 26;
      e.put(c, r, ch); expect[r][c] = ch;
    }
    e.flush();
    if (memcmp(m.ddram, expect, sizeof(expect)) != 0) { printf("FAIL: fuzz mismatch at %d\n", it); failures++; break; }
  }
  CHECK(m.clears == 1, "clear() called exactly once (at boot) across 20000 frames");

  // 7. Realistic workload: a value ticking each frame on an otherwise static page
  MockLcd m2; LcdEngine<MockLcd> e2(m2); e2.begin();
  for (int i = 0; i < 1000; ++i) {
    e2.beginFrame();
    e2.text(0, 0, "TELEMETRY      3/3");
    e2.textf(0, 1, "Temp: %5.1f C OK", 40.0 + (i % 50) * 0.1);
    e2.textf(0, 2, "Uptime: 00:%02d:%02d", (i / 4) / 60, (i / 4) % 60);
    e2.text(0, 3, "Status: NORMAL");
    e2.flush();
  }
  printf("realistic workload: %lu chars + %lu moves over %lu frames -> %.2f ops/frame, saved %u%%\n",
         (unsigned long)e2.stats().charWrites, (unsigned long)e2.stats().cursorMoves,
         (unsigned long)e2.stats().frames,
         (double)(e2.stats().charWrites + e2.stats().cursorMoves) / e2.stats().frames,
         e2.savedPercent());
  CHECK(e2.savedPercent() >= 90, "realistic workload saves >= 90% of LCD traffic");

  printf("\n%s (%d failure%s)\n", failures ? "TESTS FAILED" : "ALL TESTS PASSED", failures, failures == 1 ? "" : "s");
  return failures ? 1 : 0;
}
