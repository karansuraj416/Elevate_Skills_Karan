# Flicker-Free LCD Display Engine

ESP32 + 20×4 I2C character LCD. Diff-based rendering (no `lcd.clear()` after boot),
three auto-rotating pages on a non-blocking timer, and a latched critical-fault
screen that overrides everything until it is explicitly cleared.

## Recommended simulator: Wokwi (free, runs in the browser)

**Why Wokwi:** it simulates the ESP32, the HD44780 20×4 LCD with a PCF8574 I2C
backpack, potentiometers, buttons, LEDs and the serial monitor; it installs Arduino
libraries automatically from `libraries.txt`; and it needs no install or account to run.

| Simulator | Verdict |
|---|---|
| **Wokwi** (wokwi.com or VS Code extension) | ✅ Best fit — ESP32 + I2C LCD2004 + library manager |
| Tinkercad Circuits | ⚠️ Arduino Uno only, no `LiquidCrystal_I2C` library, no 20×4 I2C LCD |
| Proteus | ⚠️ Works, but paid licence and needs a compiled `.hex` |
| SimulIDE | ⚠️ Free, but ESP32 support is limited |

## Run it in Wokwi (≈2 minutes)

1. Open **https://wokwi.com** → *Start from scratch* → **ESP32**.
2. Replace `sketch.ino` and `diagram.json` with the files from this project.
3. Create a new file (▾ next to the tabs → *New file…*) named `LcdEngine.h` and paste it in.
4. Create `libraries.txt` with the line `LiquidCrystal I2C` (or add it via the *Library Manager* tab).
5. Press ▶ **Start**.

## Controls

| Part | GPIO | Function |
|---|---|---|
| Left knob | 34 | Battery drain — fully left = 13.0 V, turn right to discharge |
| Right knob | 35 | Temperature 0–100 °C |
| Red button | 18 | E-STOP (critical fault) |
| Green button | 19 | CLEAR fault |
| Red LED | 4 | Blinks while a fault is latched |
| LCD 20×4 | SDA 21, SCL 22 | Address 0x27 |

## Fault thresholds

| Fault | Trips at | Can be cleared when |
|---|---|---|
| E01 UNDERVOLT | battery < 10.0 V | ≥ 10.2 V |
| E02 OVERTEMP | temp > 85 °C | ≤ 83 °C |
| E03 E-STOP | button pressed | button released |

Warnings (no override, state shows WARNING): battery < 11.0 V or temp > 70 °C.

## Demo script (for viva / video)

1. Watch the pages rotate every 4 s: BATTERY → SYSTEM → TELEMETRY. No flicker.
2. On TELEMETRY, note `LCD ops` (typically 1–6 per frame) and `sav` (~95%+).
3. Turn the temperature knob past 70 °C → SYSTEM page shows `WARNING`.
4. Turn it past 85 °C → fault screen appears instantly; rotation stops; LED blinks.
5. Press CLEAR while still hot → `CLR denied: active!`.
6. Turn the knob down, press CLEAR → normal pages resume; fault counter incremented.
7. Press E-STOP → immediate fault screen. Open the Serial Monitor to see logs and timing stats.

## Files

| File | Purpose |
|---|---|
| `sketch.ino` | Application: timers, sensors, fault state machine, pages |
| `LcdEngine.h` | Reusable flicker-free renderer (double buffer + diff) |
| `diagram.json` | Wokwi circuit |
| `libraries.txt` | Wokwi library list |
| `test/test_engine.cpp` | PC unit tests for the engine (`g++ -std=c++17 test_engine.cpp && ./a.out`) |
| `REPORT.md` | Design report incl. refresh-interval justification |

## Porting to real hardware
Works as-is on an ESP32 with a 20×4 I2C LCD. If nothing shows, try address `0x3F`
and adjust the contrast pot on the backpack. For an Arduino Uno, note that AVR
`printf` has no `%f`: format floats with `dtostrf()` first.
