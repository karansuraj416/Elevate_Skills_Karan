/*
 * LcdEngine.h — Flicker-free, diff-based character LCD renderer
 * ------------------------------------------------------------------
 * How it works (double buffering for a character LCD):
 *   frame_[][]  : what the application WANTS on screen this frame
 *   shown_[][]  : what is CURRENTLY on the glass (mirror of LCD DDRAM)
 *
 *   1. beginFrame()  -> clears frame_ to spaces (RAM only, no LCD traffic)
 *   2. text()/textf()/put() -> application composes the full page in RAM
 *   3. flush()       -> compares frame_ with shown_ and sends ONLY the
 *                       changed characters, grouped into runs so that each
 *                       run costs one setCursor() + N writes.
 *
 * lcd.clear() is called exactly once, in begin(). It is never used again,
 * so the screen never blanks -> no flicker.
 *
 * Templated on the LCD type so the same code runs on the ESP32
 * (LiquidCrystal_I2C) and on a PC with a mock LCD for unit testing.
 * The LCD class only needs: clear(), setCursor(col,row), write(uint8_t).
 */
#pragma once
#include <stdint.h>
#include <string.h>
#include <stdarg.h>
#include <stdio.h>

template <class LCD, uint8_t COLS_ = 20, uint8_t ROWS_ = 4>
class LcdEngine {
public:
  static constexpr uint8_t COLS = COLS_;
  static constexpr uint8_t ROWS = ROWS_;

  // An unchanged gap of MERGE_GAP chars between two changed chars is
  // re-written instead of issuing a new setCursor(). On an HD44780,
  // setCursor() is one command byte = same bus cost as one data byte,
  // so a 1-char gap costs the same either way; 2+ chars is cheaper to jump.
  static constexpr uint8_t MERGE_GAP = 1;

  // Cost of a naive "clear + rewrite everything" frame, in LCD operations:
  // 1 clear + 1 setCursor per row + every character.
  static constexpr uint16_t NAIVE_OPS_PER_FRAME = 1 + ROWS + ROWS * COLS;

  struct Stats {
    uint32_t frames = 0;       // number of flush() calls
    uint32_t charWrites = 0;   // data bytes sent to the LCD
    uint32_t cursorMoves = 0;  // setCursor commands sent
    uint16_t lastChars = 0;    // chars written by the last flush
    uint16_t lastMoves = 0;    // cursor moves in the last flush
  };

  explicit LcdEngine(LCD &lcd) : lcd_(lcd) {}

  // Call once after the LCD has been initialised.
  void begin() {
    lcd_.clear();                       // the ONLY clear, at boot
    memset(shown_, ' ', sizeof(shown_));
    memset(frame_, ' ', sizeof(frame_));
    full_ = false;
  }

  // Start composing a new frame (RAM only).
  void beginFrame() { memset(frame_, ' ', sizeof(frame_)); }

  // Place a string; anything past the right edge is clipped.
  void text(uint8_t col, uint8_t row, const char *s) {
    if (row >= ROWS) return;
    while (*s && col < COLS) frame_[row][col++] = *s++;
  }

  // printf-style placement, clipped to the line width.
  void textf(uint8_t col, uint8_t row, const char *fmt, ...) {
    char buf[COLS + 1];
    va_list ap;
    va_start(ap, fmt);
    vsnprintf(buf, sizeof(buf), fmt, ap);
    va_end(ap);
    text(col, row, buf);
  }

  void put(uint8_t col, uint8_t row, char c) {
    if (row < ROWS && col < COLS) frame_[row][col] = c;
  }

  // Force the next flush to rewrite every cell (e.g. after an LCD
  // re-init or a suspected glitch). Still no clear(), so still no flicker.
  void invalidate() { full_ = true; }

  // Send only the differences. Returns LCD operations used (chars + moves).
  uint16_t flush() {
    uint16_t chars = 0, moves = 0;
    for (uint8_t r = 0; r < ROWS; ++r) {
      uint8_t c = 0;
      while (c < COLS) {
        if (!dirty(r, c)) { ++c; continue; }
        // Grow the run, bridging small unchanged gaps.
        uint8_t start = c, last = c;
        for (uint8_t k = c + 1; k < COLS; ++k) {
          if (dirty(r, k)) last = k;
          else if (k - last > MERGE_GAP) break;
        }
        lcd_.setCursor(start, r);
        ++moves;
        for (uint8_t k = start; k <= last; ++k) {
          lcd_.write((uint8_t)frame_[r][k]);
          shown_[r][k] = frame_[r][k];
          ++chars;
        }
        c = last + 1;
      }
    }
    full_ = false;
    stats_.frames++;
    stats_.charWrites += chars;
    stats_.cursorMoves += moves;
    stats_.lastChars = chars;
    stats_.lastMoves = moves;
    return chars + moves;
  }

  // Percentage of LCD bus operations saved versus clear-and-redraw.
  uint8_t savedPercent() const {
    if (stats_.frames == 0) return 0;
    double naive = (double)stats_.frames * NAIVE_OPS_PER_FRAME;
    double used = (double)stats_.charWrites + stats_.cursorMoves;
    double pct = 100.0 * (1.0 - used / naive);
    if (pct < 0) pct = 0;
    return (uint8_t)(pct + 0.5);
  }

  const Stats &stats() const { return stats_; }
  char shownAt(uint8_t col, uint8_t row) const { return shown_[row][col]; }

private:
  bool dirty(uint8_t r, uint8_t c) const {
    return full_ || frame_[r][c] != shown_[r][c];
  }

  LCD &lcd_;
  char frame_[ROWS][COLS];
  char shown_[ROWS][COLS];
  bool full_ = false;
  Stats stats_;
};
