/*
 * Flicker-Free LCD Display Engine
 * ESP32 + 20x4 I2C LCD (HD44780 + PCF8574 backpack) — Wokwi simulation
 * ------------------------------------------------------------------
 * Features
 *  - Diff-based renderer (LcdEngine.h): only changed characters are sent,
 *    lcd.clear() is never called after boot -> no flicker.
 *  - 3 auto-rotating pages (Battery / System / Telemetry) on a
 *    non-blocking millis() timer. No delay() anywhere in the program.
 *  - Critical faults (under-voltage, over-temperature, E-STOP) immediately
 *    override the display with a latched fault screen that stays until the
 *    operator presses CLEAR *and* the cause has gone away.
 *
 * Controls (Wokwi)
 *  - Left knob  (GPIO34): "battery drain" — turn clockwise to discharge
 *  - Right knob (GPIO35): temperature 0..100 °C
 *  - Red button  (GPIO18): E-STOP (critical fault)
 *  - Green button(GPIO19): CLEAR fault
 *  - Red LED     (GPIO4) : blinks while a fault is latched
 */
#include <Wire.h>
#include <LiquidCrystal_I2C.h>
#include "LcdEngine.h"

// ---------------- Hardware ----------------
constexpr uint8_t PIN_BATT_POT  = 34;
constexpr uint8_t PIN_TEMP_POT  = 35;
constexpr uint8_t PIN_BTN_ESTOP = 18;
constexpr uint8_t PIN_BTN_CLEAR = 19;
constexpr uint8_t PIN_FAULT_LED = 4;
constexpr uint8_t LCD_ADDR      = 0x27;

// ---------------- Timing (ms) — justified in REPORT.md section 5 ----------------
constexpr uint32_t SAMPLE_MS     = 20;    // sensor + fault check period
constexpr uint32_t RENDER_MS     = 250;   // normal display refresh (4 Hz)
constexpr uint32_t PAGE_MS       = 4000;  // page rotation period
constexpr uint32_t BLINK_MS      = 500;   // fault blink / heartbeat half-period
constexpr uint32_t BOOT_MS       = 1500;  // splash screen duration
constexpr uint32_t DEBOUNCE_MS   = 25;
constexpr uint32_t CLR_DENIED_MS = 2000;  // how long "CLR denied" is shown
constexpr uint32_t STATS_LOG_MS  = 5000;  // serial statistics period

// ---------------- Thresholds ----------------
constexpr float BATT_MIN_V   = 9.5f,  BATT_MAX_V  = 13.0f;  // knob range
constexpr float BATT_EMPTY_V = 10.5f, BATT_FULL_V = 12.6f;  // 0%..100%
constexpr float BATT_WARN_V  = 11.0f, BATT_CRIT_V = 10.0f, BATT_HYST_V = 0.2f;
constexpr float TEMP_WARN_C  = 70.0f, TEMP_CRIT_C = 85.0f, TEMP_HYST_C = 2.0f;
constexpr float EMA_ALPHA    = 0.3f;  // sensor smoothing

// ---------------- Small helpers ----------------
// Non-blocking periodic timer based on millis(); wrap-around safe.
struct Interval {
  uint32_t period;
  uint32_t last = 0;
  explicit Interval(uint32_t p) : period(p) {}
  bool due(uint32_t now) {
    if (now - last >= period) { last = now; return true; }
    return false;
  }
  void reset(uint32_t now) { last = now; }
};

// Debounced active-low push button.
class Button {
  uint8_t pin_;
  bool stable_ = HIGH, lastRead_ = HIGH;
  uint32_t changedAt_ = 0;
public:
  explicit Button(uint8_t pin) : pin_(pin) {}
  void begin() { pinMode(pin_, INPUT_PULLUP); }
  // Returns true once on each debounced press.
  bool update(uint32_t now) {
    bool r = digitalRead(pin_);
    if (r != lastRead_) { lastRead_ = r; changedAt_ = now; }
    if (now - changedAt_ >= DEBOUNCE_MS && r != stable_) {
      stable_ = r;
      return stable_ == LOW;
    }
    return false;
  }
  bool isDown() const { return stable_ == LOW; }
};

// ---------------- Types ----------------
enum SysState : uint8_t { ST_BOOT, ST_RUNNING, ST_WARNING, ST_FAULT };
const char *const STATE_NAMES[] = {"BOOT", "RUNNING", "WARNING", "FAULT"};

enum FaultCode : uint8_t { F_NONE, F_UNDERVOLT, F_OVERTEMP, F_ESTOP };
const char *const FAULT_NAMES[] = {"NONE", "UNDERVOLT", "OVERTEMP", "E-STOP"};

enum Page : uint8_t { PAGE_BATTERY, PAGE_SYSTEM, PAGE_TELEMETRY, PAGE_COUNT };
const char *const PAGE_TITLES[] = {"BATTERY", "SYSTEM", "TELEMETRY"};

struct Fault {
  bool latched = false;
  FaultCode code = F_NONE;
  uint32_t since = 0;
  uint32_t deniedUntil = 0;
};

// ---------------- Globals ----------------
LiquidCrystal_I2C lcd(LCD_ADDR, 20, 4);
LcdEngine<LiquidCrystal_I2C, 20, 4> screen(lcd);

Button btnEstop(PIN_BTN_ESTOP);
Button btnClear(PIN_BTN_CLEAR);

Interval sampleTimer(SAMPLE_MS);
Interval renderTimer(RENDER_MS);
Interval pageTimer(PAGE_MS);
Interval blinkTimer(BLINK_MS);
Interval statsTimer(STATS_LOG_MS);
Interval loopRateTimer(1000);

float battV = 12.6f, tempC = 25.0f;
bool firstSample = true;

SysState sysState = ST_BOOT;
bool bootDone = false;
uint8_t page = PAGE_BATTERY;
bool blinkOn = false;

Fault fault;
uint16_t faultCount = 0, clearCount = 0;

uint32_t loopCounter = 0, loopHz = 0;
uint16_t lastOps = 0;
uint32_t lastFlushUs = 0, maxFlushUs = 0;

// ---------------- Sensors ----------------
void readSensors() {
  // Knob is a "drain" control: fully counter-clockwise = full battery.
  float v = BATT_MAX_V - analogRead(PIN_BATT_POT) * ((BATT_MAX_V - BATT_MIN_V) / 4095.0f);
  float t = analogRead(PIN_TEMP_POT) * (100.0f / 4095.0f);
  if (firstSample) { battV = v; tempC = t; firstSample = false; }
  else {
    battV += EMA_ALPHA * (v - battV);
    tempC += EMA_ALPHA * (t - tempC);
  }
}

// ---------------- Faults ----------------
FaultCode detectFault() {
  if (btnEstop.isDown())   return F_ESTOP;
  if (battV < BATT_CRIT_V) return F_UNDERVOLT;
  if (tempC > TEMP_CRIT_C) return F_OVERTEMP;
  return F_NONE;
}

// Is the cause of a latched fault still present? (with hysteresis)
bool conditionActive(FaultCode c) {
  switch (c) {
    case F_UNDERVOLT: return battV < BATT_CRIT_V + BATT_HYST_V;
    case F_OVERTEMP:  return tempC > TEMP_CRIT_C - TEMP_HYST_C;
    case F_ESTOP:     return btnEstop.isDown();
    default:          return false;
  }
}

// Returns true if the display must be redrawn immediately.
bool updateFaults(uint32_t now, bool clearPressed) {
  if (!fault.latched) {
    FaultCode f = detectFault();
    if (f == F_NONE) return false;
    fault.latched = true;
    fault.code = f;
    fault.since = now;
    fault.deniedUntil = 0;
    faultCount++;
    Serial.printf("[%8lu ms] FAULT LATCHED: E%02u %s (V=%.2f T=%.1f)\n",
                  (unsigned long)now, f, FAULT_NAMES[f], battV, tempC);
    return true;  // override the display NOW, don't wait for the render tick
  }
  // A fault is latched: only an explicit CLEAR can release it.
  if (!clearPressed) return false;
  if (conditionActive(fault.code)) {
    fault.deniedUntil = now + CLR_DENIED_MS;
    Serial.printf("[%8lu ms] CLEAR denied: %s still active\n",
                  (unsigned long)now, FAULT_NAMES[fault.code]);
    return true;
  }
  Serial.printf("[%8lu ms] FAULT CLEARED: %s\n", (unsigned long)now, FAULT_NAMES[fault.code]);
  fault.latched = false;
  fault.code = F_NONE;
  clearCount++;
  pageTimer.reset(now);  // give the operator a full page period
  return true;
}

// ---------------- System state ----------------
// Returns true if the state changed (forces an immediate redraw).
bool updateState(uint32_t now) {
  SysState prev = sysState;
  if (fault.latched) {
    sysState = ST_FAULT;
  } else if (!bootDone) {
    if (now >= BOOT_MS) { bootDone = true; pageTimer.reset(now); sysState = ST_RUNNING; }
    else sysState = ST_BOOT;
  } else {
    bool warnEnter = battV < BATT_WARN_V || tempC > TEMP_WARN_C;
    bool warnExit  = battV > BATT_WARN_V + BATT_HYST_V && tempC < TEMP_WARN_C - TEMP_HYST_C;
    if (sysState == ST_WARNING) { if (warnExit) sysState = ST_RUNNING; }
    else sysState = warnEnter ? ST_WARNING : ST_RUNNING;
  }
  return sysState != prev;
}

// ---------------- Page drawing (RAM only — no LCD traffic here) ----------------
void drawHeader(const char *title) {
  screen.textf(0, 0, "%-15s %u/%u", title, page + 1, PAGE_COUNT);
  screen.put(19, 0, blinkOn ? '*' : ' ');  // heartbeat: proves 1-char updates
}

void drawBoot(uint32_t now) {
  screen.text(0, 0, "Flicker-Free LCD");
  screen.text(0, 1, "Display Engine v1.0");
  screen.text(0, 2, "Booting...");
  uint8_t n = (uint8_t)((now * 20UL) / BOOT_MS);
  if (n > 20) n = 20;
  for (uint8_t i = 0; i < n; ++i) screen.put(i, 3, (char)0xFF);
}

void drawBattery() {
  drawHeader(PAGE_TITLES[PAGE_BATTERY]);
  int pct = (int)lroundf((battV - BATT_EMPTY_V) * 100.0f / (BATT_FULL_V - BATT_EMPTY_V));
  pct = constrain(pct, 0, 100);
  char bar[11];
  uint8_t filled = (pct + 5) / 10;
  for (uint8_t i = 0; i < 10; ++i) bar[i] = (i < filled) ? (char)0xFF : '-';
  bar[10] = '\0';
  const char *st = battV < BATT_CRIT_V ? "CRITICAL" : (battV < BATT_WARN_V ? "LOW" : "NORMAL");
  screen.textf(0, 1, "Volt: %5.2f V", battV);
  screen.textf(0, 2, "%3d%% [%s]", pct, bar);
  screen.textf(0, 3, "Status: %s", st);
}

void drawSystem(uint32_t now) {
  drawHeader(PAGE_TITLES[PAGE_SYSTEM]);
  uint32_t s = now / 1000;
  screen.textf(0, 1, "State: %s", STATE_NAMES[sysState]);
  screen.textf(0, 2, "Uptime: %02lu:%02lu:%02lu",
               (unsigned long)(s / 3600), (unsigned long)(s / 60 % 60), (unsigned long)(s % 60));
  screen.textf(0, 3, "Faults:%3u Clr:%3u", faultCount, clearCount);
}

void drawTelemetry() {
  drawHeader(PAGE_TITLES[PAGE_TELEMETRY]);
  const char *ts = tempC > TEMP_CRIT_C ? "CRIT" : (tempC > TEMP_WARN_C ? "HOT" : "OK");
  screen.textf(0, 1, "Temp: %5.1f C %s", tempC, ts);
  screen.textf(0, 2, "Loop: %7lu Hz", (unsigned long)loopHz);
  screen.textf(0, 3, "LCD ops:%3u sav:%3u%%", lastOps, screen.savedPercent());
}

void drawFault(uint32_t now) {
  const char *bang = blinkOn ? "!!" : "  ";
  screen.textf(0, 0, "%s CRITICAL FAULT %s", bang, bang);
  screen.textf(0, 1, "E%02u %s", fault.code, FAULT_NAMES[fault.code]);

  switch (fault.code) {
    case F_UNDERVOLT: screen.textf(0, 2, "V=%5.2f", battV); break;
    case F_OVERTEMP:  screen.textf(0, 2, "T=%5.1fC", tempC); break;
    case F_ESTOP:     screen.text(0, 2, "Manual stop"); break;
    default: break;
  }
  uint32_t el = (now - fault.since) / 1000;
  screen.textf(13, 2, "t+%02lu:%02lu", (unsigned long)(el / 60 % 100), (unsigned long)(el % 60));

  if ((int32_t)(fault.deniedUntil - now) > 0)       screen.text(0, 3, "CLR denied: active!");
  else if (fault.code == F_ESTOP && btnEstop.isDown()) screen.text(0, 3, "Release E-STOP first");
  else if (conditionActive(fault.code))             screen.text(0, 3, "Cause active - wait");
  else                                              screen.text(0, 3, "Press CLEAR to reset");
}

// ---------------- Render ----------------
void render(uint32_t now) {
  screen.beginFrame();
  if (fault.latched)  drawFault(now);      // fault always wins
  else if (!bootDone) drawBoot(now);
  else switch (page) {
    case PAGE_BATTERY:   drawBattery();    break;
    case PAGE_SYSTEM:    drawSystem(now);  break;
    case PAGE_TELEMETRY: drawTelemetry();  break;
  }
  uint32_t t0 = micros();
  lastOps = screen.flush();                // the only place the LCD is touched
  lastFlushUs = micros() - t0;
  if (lastFlushUs > maxFlushUs) maxFlushUs = lastFlushUs;
}

// ---------------- Arduino entry points ----------------
void setup() {
  Serial.begin(115200);
  pinMode(PIN_FAULT_LED, OUTPUT);
  btnEstop.begin();
  btnClear.begin();
  analogReadResolution(12);

  lcd.init();
  lcd.backlight();
  screen.begin();

  readSensors();
  render(millis());
  Serial.println("Flicker-free LCD engine started");
}

void loop() {
  const uint32_t now = millis();
  bool redrawNow = false;

  // Loop-rate measurement (shown on telemetry page)
  loopCounter++;
  if (loopRateTimer.due(now)) { loopHz = loopCounter; loopCounter = 0; }

  // Inputs
  btnEstop.update(now);
  bool clearPressed = btnClear.update(now);
  if (sampleTimer.due(now)) readSensors();

  // Fault handling has top priority and bypasses the render timer
  redrawNow |= updateFaults(now, clearPressed);
  redrawNow |= updateState(now);

  // Blink phase (fault banner + heartbeat)
  if (blinkTimer.due(now)) blinkOn = !blinkOn;

  // Page rotation — paused while a fault is latched or during boot
  if (!fault.latched && bootDone && pageTimer.due(now)) {
    page = (page + 1) % PAGE_COUNT;
    redrawNow = true;
  }

  // Display refresh: periodic, or immediately on events
  if (redrawNow) { render(now); renderTimer.reset(now); }
  else if (renderTimer.due(now)) render(now);

  digitalWrite(PIN_FAULT_LED, (fault.latched && blinkOn) ? HIGH : LOW);

  if (statsTimer.due(now)) {
    const auto &s = screen.stats();
    Serial.printf("[stats] frames=%lu chars=%lu moves=%lu saved=%u%% lastFlush=%luus maxFlush=%luus\n",
                  (unsigned long)s.frames, (unsigned long)s.charWrites,
                  (unsigned long)s.cursorMoves, screen.savedPercent(),
                  (unsigned long)lastFlushUs, (unsigned long)maxFlushUs);
  }
}
