/*
 * demo.c — scripted fault story printed as JSON Lines (same format as the ESP32)
 * Build & run:  make demo
 */
#include "sim.h"
#include <stdio.h>

static void sink(const fsm_log_rec_t *r, void *user)
{
    char buf[320];
    (void)user;
    fsm_format_log_json(r, buf, sizeof buf);
    puts(buf);
}

static void note(const sim_t *s, const char *msg)
{
    printf("# t=%lu ms  --- %s\n", (unsigned long)s->now, msg);
}

int main(void)
{
    static sim_t s;
    char buf[400];
    int i;

    sim_init(&s, 2026, sink, NULL);
    note(&s, "power on (boots in FAILSAFE, power-on self test runs automatically)");
    sim_run_ms(&s, 9000);

    note(&s, "cell 2 sags to 3.05 V (warning)");
    sim_set_cell_mv(&s, 1, 3050);
    sim_run_ms(&s, 1000);
    note(&s, "cell 2 back to 3.60 V");
    sim_set_cell_mv(&s, 1, 3600);
    sim_run_ms(&s, 6000);

    note(&s, "ADC channel 1 freezes");
    s.p.freeze[0] = true;
    sim_run_ms(&s, 3000);
    note(&s, "operator presses ACK while the fault is still live (ignored)");
    sim_press_ack(&s);
    note(&s, "ADC channel 1 recovers");
    s.p.freeze[0] = false;
    sim_run_ms(&s, 3500);
    note(&s, "operator presses ACK -> verification");
    sim_press_ack(&s);
    sim_run_ms(&s, 7000);

    note(&s, "relay contact welds, then heartbeat is lost");
    s.p.welded = true;
    s.p.hb_enabled = false;
    sim_run_ms(&s, 3000);

    note(&s, "final fault memory (faults that occurred)");
    for (i = 0; i < (int)FLT_COUNT; i++) {
        if (s.fsm.faults[i].occurrences) {
            fsm_format_fault_json(&s.fsm, (fault_idx_t)i, buf, sizeof buf);
            puts(buf);
        }
    }
    fsm_format_status_json(&s.fsm, buf, sizeof buf);
    puts(buf);
    return 0;
}
