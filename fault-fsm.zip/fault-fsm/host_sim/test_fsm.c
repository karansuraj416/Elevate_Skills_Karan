/*
 * test_fsm.c — scenario, property, determinism and fuzz tests for fault_fsm.c
 * Build & run:  make test
 */
#include "sim.h"
#include <stdio.h>
#include <string.h>
#include <stdlib.h>

/* ------------------------------------------------------------------------ */
/* Minimal test framework                                                   */
/* ------------------------------------------------------------------------ */
static int g_checks, g_fails;
#define CHECK(cond) do { g_checks++; if (!(cond)) { g_fails++; \
    printf("    FAIL %s:%d  %s\n", __FILE__, __LINE__, #cond); } } while (0)
#define CHECK_EQ(a, b) do { long _a = (long)(a), _b = (long)(b); g_checks++; if (_a != _b) { g_fails++; \
    printf("    FAIL %s:%d  %s == %s  (got %ld, want %ld)\n", __FILE__, __LINE__, #a, #b, _a, _b); } } while (0)

/* ------------------------------------------------------------------------ */
/* Log capture + invariant checks performed on every record                 */
/* ------------------------------------------------------------------------ */
#define CAP_MAX 4096
typedef struct {
    fsm_log_rec_t rec[CAP_MAX];
    int      n;
    uint32_t last_seq, last_t;
    int      violations;
    uint32_t hash;                  /* FNV-1a over the formatted log */
    bool     print;
} capture_t;

static void cap_reset(capture_t *c) { memset(c, 0, sizeof *c); c->hash = 2166136261u; }

static void violation(capture_t *c, const char *why, const fsm_log_rec_t *r)
{
    char buf[320];
    c->violations++;
    fsm_format_log_json(r, buf, sizeof buf);
    printf("    INVARIANT VIOLATION (%s): %s\n", why, buf);
}

static void cap_sink(const fsm_log_rec_t *r, void *user)
{
    capture_t *c = (capture_t *)user;
    char buf[320];
    const char *p;

    if (r->seq != c->last_seq + 1u)          violation(c, "seq not contiguous", r);
    if (c->last_seq && r->t_ms < c->last_t)  violation(c, "time went backwards", r);
    c->last_seq = r->seq;
    c->last_t   = r->t_ms;

    if (r->kind == LOG_TRANSITION && r->prev != FSM_STATE_POWER_ON) {
        if (r->next != fsm_transition_table[r->prev][r->event]) violation(c, "not in transition table", r);
        if (r->prev == ST_SHUTDOWN)                             violation(c, "left SHUTDOWN", r);
        if (r->prev == ST_FAILSAFE && r->next == ST_NORMAL)     violation(c, "FAILSAFE->NORMAL skip", r);
        if ((r->event == EV_WARN_FAULT || r->event == EV_CRIT_FAULT || r->event == EV_FATAL_FAULT)
            && r->fault_id == 0)                                violation(c, "fault transition without fault id", r);
    }

    fsm_format_log_json(r, buf, sizeof buf);
    for (p = buf; *p; p++) { c->hash ^= (uint8_t)*p; c->hash *= 16777619u; }
    if (c->print) puts(buf);
    if (c->n < CAP_MAX) c->rec[c->n++] = *r;
}

/* Last transition record into 'next' state, or NULL */
static const fsm_log_rec_t *last_transition_to(const capture_t *c, uint8_t next)
{
    int i;
    for (i = c->n - 1; i >= 0; i--)
        if (c->rec[i].kind == LOG_TRANSITION && c->rec[i].next == next) return &c->rec[i];
    return NULL;
}

static int count_recovery(const capture_t *c, uint8_t result)
{
    int i, k = 0;
    for (i = 0; i < c->n; i++) if (c->rec[i].kind == LOG_RECOVERY && c->rec[i].result == result) k++;
    return k;
}

static sim_t     S;
static capture_t C;

static void boot(uint32_t seed)
{
    cap_reset(&C);
    sim_init(&S, seed, cap_sink, &C);
}

static void boot_to_normal(void)
{
    boot(12345);
    sim_run_ms(&S, 9000);
}

/* ------------------------------------------------------------------------ */
/* Scenario tests                                                           */
/* ------------------------------------------------------------------------ */
static void test_power_on_self_test(void)
{
    const fsm_log_rec_t *r;
    boot(1);
    CHECK_EQ(S.fsm.state, ST_FAILSAFE);                 /* boots safe */
    sim_run_ms(&S, 900);
    CHECK_EQ(S.fsm.state, ST_FAILSAFE);                 /* POST hold not done */
    CHECK(!S.out.relay_on || S.out.rstep == RS_RELAY_CLOSE);
    sim_run_ms(&S, 1500);
    CHECK_EQ(S.fsm.state, ST_DEGRADED);                 /* POST passed, no ack needed */
    r = last_transition_to(&C, ST_DEGRADED);
    CHECK(r && r->event == EV_VERIFY_PASS && r->prev == ST_FAILSAFE);
    sim_run_ms(&S, 4000);
    CHECK_EQ(S.fsm.state, ST_DEGRADED);                 /* probation not finished */
    sim_run_ms(&S, 1500);
    CHECK_EQ(S.fsm.state, ST_NORMAL);
    r = last_transition_to(&C, ST_NORMAL);
    CHECK(r && r->event == EV_PROBATION_OK);
    CHECK(S.out.relay_on && S.p.relay_closed);
}

static void test_cell_warning_degraded(void)
{
    const fsm_log_rec_t *r;
    boot_to_normal();
    sim_set_cell_mv(&S, 1, 3050);                       /* cell 2 under-voltage warning */
    sim_run_ms(&S, 200);
    CHECK_EQ(S.fsm.state, ST_DEGRADED);
    r = last_transition_to(&C, ST_DEGRADED);
    CHECK(r && r->fault_id == 0x0203);                  /* CELL2 / UV_WARN */
    CHECK(S.out.relay_on);                              /* still operating */
    sim_set_cell_mv(&S, 1, 3600);
    sim_run_ms(&S, 4000);
    CHECK_EQ(S.fsm.state, ST_DEGRADED);
    sim_run_ms(&S, 1500);
    CHECK_EQ(S.fsm.state, ST_NORMAL);
    CHECK_EQ(S.fsm.faults[FLT_CELL2_UV_WARN].occurrences, 1);  /* remembered */
}

static void test_overvoltage_failsafe_and_verified_recovery(void)
{
    const fsm_log_rec_t *r;
    boot_to_normal();
    sim_set_cell_mv(&S, 3, 4300);                       /* cell 4 OV critical */
    sim_run_ms(&S, 200);
    CHECK_EQ(S.fsm.state, ST_FAILSAFE);
    r = last_transition_to(&C, ST_FAILSAFE);
    CHECK(r && r->fault_id == 0x0402 && r->prev == ST_NORMAL);
    CHECK(!S.out.relay_on);
    CHECK(!S.p.relay_closed);

    sim_press_ack(&S);                                  /* fault still present */
    sim_run_ms(&S, 5000);
    CHECK_EQ(S.fsm.state, ST_FAILSAFE);
    CHECK_EQ(S.fsm.rstep, RS_WAIT_CLEAR);

    sim_set_cell_mv(&S, 3, 3600);                       /* condition gone */
    sim_run_ms(&S, 1000);
    sim_press_ack(&S);                                  /* too early: hold not done */
    sim_run_ms(&S, 1000);
    CHECK_EQ(S.fsm.state, ST_FAILSAFE);
    CHECK_EQ(S.fsm.rstep, RS_WAIT_CLEAR);
    sim_run_ms(&S, 1500);
    CHECK_EQ(S.fsm.rstep, RS_WAIT_ACK);                 /* never auto-recovers */
    sim_run_ms(&S, 10000);
    CHECK_EQ(S.fsm.state, ST_FAILSAFE);

    sim_press_ack(&S);
    sim_run_ms(&S, 1500);
    CHECK_EQ(S.fsm.state, ST_DEGRADED);                 /* not NORMAL yet */
    CHECK(!S.fsm.faults[FLT_CELL4_OV_CRIT].latched);
    CHECK_EQ(S.fsm.faults[FLT_CELL4_OV_CRIT].occurrences, 1);
    sim_run_ms(&S, 5500);
    CHECK_EQ(S.fsm.state, ST_NORMAL);
    CHECK_EQ(C.violations, 0);
}

static void test_frozen_adc_isolated(void)
{
    const fsm_log_rec_t *r;
    boot_to_normal();
    S.p.freeze[0] = true;
    sim_run_ms(&S, 900);
    CHECK_EQ(S.fsm.state, ST_NORMAL);                   /* 1 s window not yet over */
    sim_run_ms(&S, 300);
    CHECK_EQ(S.fsm.state, ST_FAILSAFE);
    r = last_transition_to(&C, ST_FAILSAFE);
    CHECK(r && r->fault_id == 0x0610);                  /* ADC1 / FROZEN */

    sim_set_cell_mv(&S, 0, 2600);                       /* real cell sags, reading stuck */
    sim_run_ms(&S, 10000);
    CHECK_EQ(S.fsm.state, ST_FAILSAFE);
    CHECK_EQ(S.fsm.rstep, RS_WAIT_CLEAR);               /* no verification while live */
    CHECK_EQ(S.fsm.attempts, 0);
    CHECK_EQ(S.fsm.faults[FLT_CELL1_UV_CRIT].occurrences, 0);

    S.p.freeze[0] = false;                              /* channel alive again ... */
    sim_run_ms(&S, 200);
    CHECK(S.fsm.faults[FLT_CELL1_UV_CRIT].active);      /* ... and now sees the real sag */
    sim_set_cell_mv(&S, 0, 3600);
    sim_run_ms(&S, 3500);
    sim_press_ack(&S);
    sim_run_ms(&S, 1500);
    CHECK_EQ(S.fsm.state, ST_DEGRADED);
}

static void test_adc_rail_not_blamed_on_cell(void)
{
    const fsm_log_rec_t *r;
    boot_to_normal();
    S.p.cell_raw[2] = 0;                                /* shorted sense line */
    S.p.noise = false;
    sim_run_ms(&S, 200);
    CHECK_EQ(S.fsm.state, ST_FAILSAFE);
    r = last_transition_to(&C, ST_FAILSAFE);
    CHECK(r && r->fault_id == 0x0811);                  /* ADC3 / RAIL */
    CHECK_EQ(S.fsm.faults[FLT_CELL3_UV_CRIT].occurrences, 0);
    CHECK_EQ(S.fsm.faults[FLT_CELL3_UV_WARN].occurrences, 0);
    CHECK_EQ(S.fsm.faults[FLT_ADC3_FROZEN].occurrences, 0);
}

static void test_relay_stuck_open_exhausts_recovery(void)
{
    const fsm_log_rec_t *r;
    int i;
    boot_to_normal();
    S.p.coil_lost = true;
    sim_run_ms(&S, 200);
    CHECK_EQ(S.fsm.state, ST_FAILSAFE);
    r = last_transition_to(&C, ST_FAILSAFE);
    CHECK(r && r->fault_id == 0x0A20);                  /* RELAY / STUCK_OPEN */

    for (i = 0; i < 3; i++) {                           /* operator keeps trying */
        sim_run_ms(&S, 3500);
        CHECK_EQ(S.fsm.rstep, RS_WAIT_ACK);
        sim_press_ack(&S);
        sim_run_ms(&S, 1500);
    }
    CHECK_EQ(count_recovery(&C, RR_FAIL) + count_recovery(&C, RR_ABORT), 3);
    CHECK_EQ(S.fsm.state, ST_SHUTDOWN);
    r = last_transition_to(&C, ST_SHUTDOWN);
    CHECK(r && r->fault_id == 0x0C41);                  /* SYSTEM / RECOVERY_EXHAUSTED */
    CHECK(S.fsm.faults[FLT_RELAY_STUCK_OPEN].occurrences >= 1);
}

static void test_welded_relay_shutdown_is_terminal(void)
{
    const fsm_log_rec_t *r;
    int i;
    boot_to_normal();
    S.p.welded = true;                                  /* invisible while relay is ON */
    sim_run_ms(&S, 1000);
    CHECK_EQ(S.fsm.state, ST_NORMAL);
    S.p.cell_raw[1] = 4095; S.p.noise = false;          /* any CRIT -> FAILSAFE -> open */
    sim_run_ms(&S, 400);
    CHECK_EQ(S.fsm.state, ST_SHUTDOWN);
    r = last_transition_to(&C, ST_SHUTDOWN);
    CHECK(r && r->prev == ST_FAILSAFE && r->fault_id == 0x0A21);  /* RELAY / STUCK_CLOSED */

    S.p.noise = true;
    sim_heal(&S);
    for (i = 0; i < 5; i++) { sim_press_ack(&S); sim_run_ms(&S, 4000); }
    CHECK_EQ(S.fsm.state, ST_SHUTDOWN);
    CHECK(!S.out.relay_on);
}

static void test_comm_loss_escalation(void)
{
    const fsm_log_rec_t *r;
    boot_to_normal();
    S.p.hb_enabled = false;
    sim_run_ms(&S, 700);
    CHECK_EQ(S.fsm.state, ST_DEGRADED);
    r = last_transition_to(&C, ST_DEGRADED);
    CHECK(r && r->fault_id == 0x0B30);                  /* COMM / HB_LATE */
    sim_run_ms(&S, 1600);
    CHECK_EQ(S.fsm.state, ST_FAILSAFE);
    r = last_transition_to(&C, ST_FAILSAFE);
    CHECK(r && r->fault_id == 0x0B31);                  /* COMM / LINK_LOST */
    S.p.hb_enabled = true;
    sim_run_ms(&S, 3500);
    sim_press_ack(&S);
    sim_run_ms(&S, 7000);
    CHECK_EQ(S.fsm.state, ST_NORMAL);
}

static void test_feedback_implausible(void)
{
    const fsm_log_rec_t *r;
    boot_to_normal();
    S.p.fb_break = true;
    sim_run_ms(&S, 200);
    CHECK_EQ(S.fsm.state, ST_FAILSAFE);
    r = last_transition_to(&C, ST_FAILSAFE);
    CHECK(r && r->fault_id == 0x0A22);                  /* RELAY / FB_IMPLAUSIBLE */
    CHECK_EQ(S.fsm.faults[FLT_RELAY_STUCK_OPEN].occurrences, 0);  /* relay not blamed */
}

static void test_shutdown_request(void)
{
    const fsm_log_rec_t *r;
    boot_to_normal();
    S.shutdown_req = true;
    sim_run_ms(&S, 100);
    CHECK_EQ(S.fsm.state, ST_SHUTDOWN);
    r = last_transition_to(&C, ST_SHUTDOWN);
    CHECK(r && r->fault_id == 0x0C42 && r->prev == ST_NORMAL);
}

static void test_flapping_escalates(void)
{
    int i;
    boot_to_normal();
    for (i = 0; i < 5 && S.fsm.state != ST_SHUTDOWN; i++) {
        sim_set_cell_mv(&S, 0, 4300);
        sim_run_ms(&S, 200);
        sim_set_cell_mv(&S, 0, 3600);
        sim_run_ms(&S, 3200);
        sim_press_ack(&S);
        sim_run_ms(&S, 1000);
    }
    CHECK_EQ(S.fsm.state, ST_SHUTDOWN);
    CHECK(S.fsm.faults[FLT_SYS_RECOVERY_EXHAUST].latched);
    CHECK_EQ(C.violations, 0);
}

static void test_post_failure_needs_ack(void)
{
    boot(7);
    S.p.coil_lost = true;                               /* defective at power-on */
    sim_run_ms(&S, 3000);
    CHECK_EQ(S.fsm.state, ST_FAILSAFE);
    CHECK(count_recovery(&C, RR_FAIL) + count_recovery(&C, RR_ABORT) == 1);
    sim_run_ms(&S, 10000);
    CHECK_EQ(S.fsm.rstep, RS_WAIT_ACK);                 /* no automatic retry loop */
    CHECK_EQ(S.fsm.attempts, 1);
    S.p.coil_lost = false;
    sim_press_ack(&S);
    sim_run_ms(&S, 7000);
    CHECK_EQ(S.fsm.state, ST_NORMAL);
}

/* ------------------------------------------------------------------------ */
/* Static properties of the transition table                                */
/* ------------------------------------------------------------------------ */
static bool reachable(uint8_t from, uint8_t to)
{
    bool seen[ST_COUNT] = { false };
    uint8_t queue[ST_COUNT * EV_COUNT + 1];
    int head = 0, tail = 0, e;
    queue[tail++] = from; seen[from] = true;
    while (head < tail) {
        uint8_t s = queue[head++];
        if (s == to) return true;
        for (e = 0; e < EV_COUNT; e++) {
            uint8_t n = fsm_transition_table[s][e];
            if (!seen[n]) { seen[n] = true; queue[tail++] = n; }
        }
    }
    return false;
}

static void test_transition_table_properties(void)
{
    int s, e;
    for (s = 0; s < ST_COUNT; s++) {
        bool has_exit = false;
        for (e = 0; e < EV_COUNT; e++) {
            CHECK(fsm_transition_table[s][e] < ST_COUNT);
            if (fsm_transition_table[s][e] != s) has_exit = true;
        }
        if (s != ST_SHUTDOWN) {
            CHECK(has_exit);                                  /* no dead state */
            CHECK(reachable((uint8_t)s, ST_NORMAL));          /* can recover   */
            CHECK(reachable((uint8_t)s, ST_SHUTDOWN));        /* can be stopped */
        } else {
            CHECK(!has_exit);                                 /* terminal      */
        }
        CHECK_EQ(fsm_transition_table[s][EV_FATAL_FAULT], ST_SHUTDOWN);
    }
    for (e = 0; e < EV_COUNT; e++) CHECK(fsm_transition_table[ST_FAILSAFE][e] != ST_NORMAL);
    /* Fault IDs unique */
    for (s = 0; s < FLT_COUNT; s++)
        for (e = s + 1; e < FLT_COUNT; e++) CHECK(fsm_fault_id((fault_idx_t)s) != fsm_fault_id((fault_idx_t)e));
}

/* ------------------------------------------------------------------------ */
/* Random fault campaign: determinism, invariants, deadlock freedom         */
/* ------------------------------------------------------------------------ */
static void random_campaign(uint32_t seed, uint32_t duration_ms, bool allow_shutdown_req)
{
    uint32_t r = seed * 2654435761u + 1u, t;
    boot(seed);
    for (t = 0; t < duration_ms; t += FSM_TICK_MS) {
        uint32_t x = sim_rand(&r);
        if (x % 1000u < 4u) {                                     /* ~1 change / 5 s */
            switch (sim_rand(&r) % 9u) {
            case 0: sim_set_cell_mv(&S, sim_rand(&r) % 4u, (uint16_t)(2400u + sim_rand(&r) % 2200u)); break;
            case 1: sim_set_cell_mv(&S, sim_rand(&r) % 4u, 3600); break;
            case 2: { unsigned ch = sim_rand(&r) % 4u; S.p.freeze[ch] = !S.p.freeze[ch]; break; }
            case 3: S.p.coil_lost = !S.p.coil_lost; break;
            case 4: S.p.welded = (sim_rand(&r) % 8u == 0u) ? !S.p.welded : false; break;
            case 5: S.p.fb_break = !S.p.fb_break; break;
            case 6: S.p.hb_enabled = !S.p.hb_enabled; break;
            case 7: S.shutdown_req = allow_shutdown_req && (sim_rand(&r) % 10u == 0u); break;
            default: sim_heal(&S); break;
            }
        }
        S.ack = (x % 1000u >= 995u);                               /* random ack presses */
        sim_tick(&S);

        /* per-tick output invariants */
        if (S.out.state == ST_SHUTDOWN && S.out.relay_on) C.violations++;
        if (S.out.state == ST_FAILSAFE && S.out.relay_on && S.out.rstep != RS_RELAY_CLOSE) C.violations++;
    }
}

static void test_determinism(void)
{
    uint32_t h1, h2;
    uint8_t  st1;
    random_campaign(42, 120000, true);
    h1 = C.hash; st1 = (uint8_t)S.fsm.state;
    random_campaign(42, 120000, true);
    h2 = C.hash;
    CHECK_EQ(h1, h2);
    CHECK_EQ(st1, S.fsm.state);
    random_campaign(43, 120000, true);
    CHECK(C.hash != h1);                                /* sanity: different seed differs */
}

static void test_fuzz_no_deadlock(void)
{
    uint32_t seed;
    int normal = 0, shutdown = 0, stuck = 0, viol = 0, transitions = 0;
    for (seed = 1; seed <= 400; seed++) {
        int k;
        random_campaign(seed, 120000, (seed % 2u) == 0u);
        /* Liveness: heal the plant, an operator acks every 4 s */
        sim_heal(&S);
        for (k = 0; k < 10; k++) { sim_run_ms(&S, 4000); sim_press_ack(&S); }
        sim_run_ms(&S, 6000);
        if (S.fsm.state == ST_NORMAL) normal++;
        else if (S.fsm.state == ST_SHUTDOWN) shutdown++;
        else { stuck++; printf("    seed %u stuck in %s step %s\n", (unsigned)seed,
                               fsm_state_name((uint8_t)S.fsm.state), fsm_step_name(S.fsm.rstep)); }
        viol += C.violations;
        for (k = 0; k < C.n; k++) if (C.rec[k].kind == LOG_TRANSITION) transitions++;
    }
    printf("    400 runs x 120 s: %d ended NORMAL, %d SHUTDOWN, %d stuck; %d transitions checked\n",
           normal, shutdown, stuck, transitions);
    CHECK_EQ(stuck, 0);
    CHECK_EQ(viol, 0);
}

/* ------------------------------------------------------------------------ */
int main(void)
{
    struct { const char *name; void (*fn)(void); } tests[] = {
        { "transition table properties",            test_transition_table_properties },
        { "power-on self test -> DEGRADED -> NORMAL", test_power_on_self_test },
        { "cell warning -> DEGRADED -> NORMAL",     test_cell_warning_degraded },
        { "over-voltage -> FAILSAFE -> verified recovery", test_overvoltage_failsafe_and_verified_recovery },
        { "frozen ADC isolated from cell faults",   test_frozen_adc_isolated },
        { "ADC rail not blamed on cell",            test_adc_rail_not_blamed_on_cell },
        { "relay stuck-open exhausts recovery",     test_relay_stuck_open_exhausts_recovery },
        { "welded relay -> terminal SHUTDOWN",      test_welded_relay_shutdown_is_terminal },
        { "comm loss: DEGRADED then FAILSAFE",      test_comm_loss_escalation },
        { "relay feedback implausible",             test_feedback_implausible },
        { "operator shutdown request",              test_shutdown_request },
        { "fault flapping escalates to SHUTDOWN",   test_flapping_escalates },
        { "failed POST waits for operator ack",     test_post_failure_needs_ack },
        { "determinism (same inputs -> same log)",  test_determinism },
        { "fuzz: invariants + no deadlock",         test_fuzz_no_deadlock },
    };
    size_t i;
    for (i = 0; i < sizeof tests / sizeof tests[0]; i++) {
        int before = g_fails;
        tests[i].fn();
        if (C.violations && tests[i].fn != test_fuzz_no_deadlock) {
            g_fails++; printf("    %d invariant violations\n", C.violations);
        }
        printf("[%s] %s\n", g_fails == before ? "PASS" : "FAIL", tests[i].name);
    }
    printf("\n%d checks, %d failed\n", g_checks, g_fails);
    return g_fails ? 1 : 0;
}
