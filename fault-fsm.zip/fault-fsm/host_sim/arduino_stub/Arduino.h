/*
 * Minimal Arduino/ESP32 API stub so sketch.ino can be compiled and smoke-run
 * on a PC (make sketch). Not used by the real firmware build.
 */
#pragma once
#include <stdint.h>
#include <stdio.h>
#include <string.h>

#define HIGH 1
#define LOW 0
#define INPUT 0
#define OUTPUT 1
#define INPUT_PULLUP 2
#define ADC_11db 3
#define F(s) (s)

uint32_t millis(void);
void delay(uint32_t ms);
void pinMode(uint8_t pin, uint8_t mode);
void digitalWrite(uint8_t pin, uint8_t val);
int  digitalRead(uint8_t pin);
int  analogRead(uint8_t pin);
void analogReadResolution(int bits);
void analogSetAttenuation(int att);

struct SerialStub {
    void begin(unsigned long) {}
    int  available();
    int  read();
    void println(const char *s);
};
extern SerialStub Serial;
