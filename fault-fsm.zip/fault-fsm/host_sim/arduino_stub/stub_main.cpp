/*
 * Smoke-run the real sketch.ino on a PC with a tiny hardware model:
 *   - relay: NO feedback (GPIO27) closes when IN (GPIO26) is HIGH, NC (GPIO14) otherwise
 *   - pots read mid-scale; switches/button open unless the script below closes them
 * Script: t=12 s freeze ADC1 (SW1) for 3 s, t=20 s press ACK, t=35 s weld relay (SW4)
 * then freeze ADC1 again -> must end in SHUTDOWN.
 */
#include "Arduino.h"

void setup();
void loop();

SerialStub Serial;
static uint32_t g_ms;
static uint8_t  g_pin[40];
static const char *g_rx = "";

uint32_t millis(void) { return g_ms; }
void delay(uint32_t ms) { g_ms += ms; }
void pinMode(uint8_t, uint8_t) {}
void analogReadResolution(int) {}
void analogSetAttenuation(int) {}
void digitalWrite(uint8_t pin, uint8_t v) { g_pin[pin] = v; }
int  analogRead(uint8_t) { return 2048; }

static bool closed_switch(uint8_t pin)
{
    if (pin == 4)  return (g_ms >= 12000 && g_ms < 15000) || g_ms >= 36000;  /* SW1 freeze */
    if (pin == 18) return g_ms >= 35000;                                     /* SW4 weld   */
    if (pin == 13) return g_ms >= 20000 && g_ms < 20200;                     /* ACK button */
    return false;
}

int digitalRead(uint8_t pin)
{
    bool energised = g_pin[26] == HIGH;
    if (pin == 27) return energised ? LOW : HIGH;     /* NO contact to GND */
    if (pin == 14) return energised ? HIGH : LOW;     /* NC contact to GND */
    return closed_switch(pin) ? LOW : HIGH;
}

int  SerialStub::available() { return *g_rx ? 1 : 0; }
int  SerialStub::read() { return *g_rx ? *g_rx++ : -1; }
void SerialStub::println(const char *s) { printf("[%6lu] %s\n", (unsigned long)g_ms, s); }

int main()
{
    setup();
    while (g_ms < 40000) {
        if (g_ms == 30000) g_rx = "f";                  /* serial command: fault memory */
        loop();
        g_ms++;
    }
    return 0;
}
