/* sim.c — plant model for host testing of fault_fsm.c */
#include "sim.h"
#include <string.h>

uint32_t sim_rand(uint32_t *x)            /* xorshift32: deterministic */
{
    *x ^= *x << 13; *x ^= *x >> 17; *x ^= *x << 5;
    return *x;
}

uint16_t mv_to_raw(uint16_t mv)
{
    uint32_t raw;
    if (mv <= CFG_CELL_MV_MIN) return 0;
    raw = ((uint32_t)(mv - CFG_CELL_MV_MIN) * CFG_ADC_MAX + CFG_CELL_MV_SPAN / 2u) / CFG_CELL_MV_SPAN;
    return (uint16_t)(raw > CFG_ADC_MAX ? CFG_ADC_MAX : raw);
}

void sim_set_cell_mv(sim_t *s, unsigned ch, uint16_t mv) { s->p.cell_raw[ch] = mv_to_raw(mv); }

void sim_heal(sim_t *s)
{
    unsigned ch;
    for (ch = 0; ch < FSM_NUM_CELLS; ch++) {
        s->p.freeze[ch] = false;
        s->p.frozen_val[ch] = 0xFFFFu;      /* "not captured yet" sentinel */
        sim_set_cell_mv(s, ch, 3600);
    }
    s->p.coil_lost = false;
    s->p.welded    = false;
    s->p.fb_break  = false;
    s->p.hb_enabled = true;
    s->shutdown_req = false;
}

void sim_init(sim_t *s, uint32_t seed, fsm_log_sink_t sink, void *user)
{
    memset(s, 0, sizeof *s);
    s->now = 1000;                            /* arbitrary boot time */
    s->p.rng = seed ? seed : 1u;
    s->p.noise = true;
    s->p.relay_delay_ticks = 1;               /* 20 ms contact travel */
    s->p.hb_period_ms = 100;
    s->p.next_hb_ms = s->now + s->p.hb_period_ms;
    sim_heal(s);
    fsm_init(&s->fsm, s->now, sink, user);
    s->out.state = s->fsm.state;
}

static uint16_t read_adc(plant_t *p, unsigned ch)
{
    int v = p->cell_raw[ch];
    if (p->noise) v += (int)(sim_rand(&p->rng) % 4u) - 1;   /* -1..+2 LSB */
    if (v < 0) v = 0;
    if (v > (int)CFG_ADC_MAX) v = (int)CFG_ADC_MAX;
    if (p->freeze[ch]) {
        if (p->frozen_val[ch] == 0xFFFFu) p->frozen_val[ch] = (uint16_t)v;
        return p->frozen_val[ch];
    }
    p->frozen_val[ch] = 0xFFFFu;
    return (uint16_t)v;
}

void sim_tick(sim_t *s)
{
    fsm_inputs_t in;
    plant_t *p = &s->p;
    unsigned ch;
    bool energise;

    s->now += FSM_TICK_MS;
    in.now_ms = s->now;
    for (ch = 0; ch < FSM_NUM_CELLS; ch++) in.adc_raw[ch] = read_adc(p, ch);
    in.relay_fb_no  = p->relay_closed && !p->fb_break;
    in.relay_fb_nc  = !p->relay_closed && !p->fb_break;
    in.heartbeat    = false;
    while ((int32_t)(s->now - p->next_hb_ms) >= 0) {
        p->next_hb_ms += p->hb_period_ms;
        if (p->hb_enabled) in.heartbeat = true;
    }
    in.recovery_ack = s->ack;
    in.shutdown_req = s->shutdown_req;

    fsm_step(&s->fsm, &in, &s->out);

    /* relay physics: contact follows the coil after a travel delay */
    energise = s->out.relay_on;
    if (p->coil_lost) energise = false;
    if (p->welded)    energise = true;
    if (energise != p->relay_closed) {
        if (++p->relay_move_cnt >= p->relay_delay_ticks) { p->relay_closed = energise; p->relay_move_cnt = 0; }
    } else {
        p->relay_move_cnt = 0;
    }
}

void sim_run_ms(sim_t *s, uint32_t ms)
{
    uint32_t t;
    for (t = 0; t < ms; t += FSM_TICK_MS) sim_tick(s);
}

void sim_press_ack(sim_t *s)
{
    s->ack = true;  sim_tick(s); sim_tick(s);
    s->ack = false; sim_tick(s);
}
