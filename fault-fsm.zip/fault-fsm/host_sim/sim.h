/*
 * sim.h — host-side plant model that drives the real fault_fsm.c
 *
 * The plant models: 4 cell voltages read through ADC channels (with LSB noise),
 * a relay with mechanical delay and NO/NC feedback contacts, and a remote
 * heartbeat. Faults are injected by flipping fields in plant_t.
 */
#ifndef SIM_H
#define SIM_H

#include "fault_fsm.h"

typedef struct {
    uint16_t cell_raw[FSM_NUM_CELLS];  /* "true" ADC value per channel       */
    bool     freeze[FSM_NUM_CELLS];    /* ADC channel stuck at last value    */
    uint16_t frozen_val[FSM_NUM_CELLS];
    bool     noise;                    /* +-LSB noise like a real front end  */

    bool     coil_lost;                /* relay can never energise           */
    bool     welded;                   /* relay contact can never open       */
    bool     fb_break;                 /* both feedback lines read open      */
    bool     relay_closed;             /* physical contact state             */
    uint8_t  relay_delay_ticks;        /* mechanical travel time             */
    uint8_t  relay_move_cnt;

    bool     hb_enabled;
    uint32_t hb_period_ms;
    uint32_t next_hb_ms;

    uint32_t rng;
} plant_t;

typedef struct {
    fsm_ctx_t     fsm;
    fsm_outputs_t out;
    plant_t       p;
    uint32_t      now;
    bool          ack;          /* operator button level   */
    bool          shutdown_req;
} sim_t;

uint16_t mv_to_raw(uint16_t mv);
uint32_t sim_rand(uint32_t *state);

void sim_init(sim_t *s, uint32_t seed, fsm_log_sink_t sink, void *user);
void sim_tick(sim_t *s);
void sim_run_ms(sim_t *s, uint32_t ms);
void sim_press_ack(sim_t *s);          /* press for 2 ticks, release */
void sim_set_cell_mv(sim_t *s, unsigned ch, uint16_t mv);
void sim_heal(sim_t *s);               /* remove every injected fault */

#endif
