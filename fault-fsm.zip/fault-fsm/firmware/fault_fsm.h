/*
 * fault_fsm.h — Deterministic fault state machine with structured recovery
 *
 * Portable C99. No dynamic memory, no floating point, no hardware access.
 * The same code runs on the ESP32 (Wokwi sketch) and on a PC (host_sim tests).
 *
 * States : NORMAL, DEGRADED, FAILSAFE, SHUTDOWN
 * Events : derived once per tick from the fault table (one transition per tick max)
 * Faults : identified by source (cell / ADC channel / relay / comm / system)
 *          and type; ID = (source << 8) | type, e.g. 0x0610 = ADC1 frozen.
 */
#ifndef FAULT_FSM_H
#define FAULT_FSM_H

#include <stdint.h>
#include <stdbool.h>
#include <stddef.h>

#ifdef __cplusplus
extern "C" {
#endif

/* ------------------------------------------------------------------------ */
/* Configuration (override with -D or before including)                     */
/* ------------------------------------------------------------------------ */
#define FSM_NUM_CELLS 4
#ifndef FSM_LOG_DEPTH
#define FSM_LOG_DEPTH 64u            /* ring buffer of structured log records */
#endif
#ifndef FSM_TICK_MS
#define FSM_TICK_MS 20u              /* fsm_step() must be called at this period */
#endif

/* ADC / cell scaling: 12-bit raw 0..4095 -> 2500..4500 mV                  */
#define CFG_ADC_MAX              4095u
#define CFG_CELL_MV_MIN          2500u
#define CFG_CELL_MV_SPAN         2000u
#define CFG_ADC_RAIL_LO          8u     /* raw <= this : shorted / open sensor  */
#define CFG_ADC_RAIL_HI          4087u  /* raw >= this : shorted / open sensor  */
#define CFG_ADC_FROZEN_SAMPLES   50u    /* identical samples => frozen (1 s)    */

/* Cell thresholds in mV: set / clear (hysteresis)                          */
#define CFG_OV_WARN_SET   4150u
#define CFG_OV_WARN_CLR   4100u
#define CFG_OV_CRIT_SET   4250u
#define CFG_OV_CRIT_CLR   4200u
#define CFG_UV_WARN_SET   3100u
#define CFG_UV_WARN_CLR   3150u
#define CFG_UV_CRIT_SET   2900u
#define CFG_UV_CRIT_CLR   2950u
#define CFG_IMBAL_SET     250u
#define CFG_IMBAL_CLR     200u

/* Relay                                                                     */
#define CFG_RELAY_SETTLE_MS        60u  /* ignore mismatch right after a command */
#define CFG_RELAY_CONFIRM_SAMPLES  3u   /* self-test: consecutive good samples   */
#define CFG_RELAY_TEST_TIMEOUT_MS  300u

/* Communication heartbeat                                                   */
#define CFG_HB_LATE_MS    500u           /* -> WARN  (DEGRADED)                  */
#define CFG_HB_LOST_MS    2000u          /* -> CRIT  (FAILSAFE)                  */

/* Recovery / probation                                                      */
#define CFG_POST_HOLD_MS           1000u /* power-on: faults clear this long     */
#define CFG_RECOVERY_HOLD_MS       3000u /* FAILSAFE: faults clear this long     */
#define CFG_ADC_CHECK_MS           500u
#define CFG_ADC_MIN_CHANGES        3u    /* liveness: changes per channel        */
#define CFG_COMM_CHECK_TIMEOUT_MS  1000u
#define CFG_MAX_RECOVERY_ATTEMPTS  3u    /* failed verifications -> SHUTDOWN     */
#define CFG_PROBATION_MS           5000u /* DEGRADED fault-free -> NORMAL        */
#define CFG_FLAP_MAX_ENTRIES       5u    /* FAILSAFE entries within window ...   */
#define CFG_FLAP_WINDOW_MS         60000u/* ... -> SHUTDOWN (anti-livelock)      */

/* ------------------------------------------------------------------------ */
/* States and events                                                        */
/* ------------------------------------------------------------------------ */
typedef enum {
    ST_NORMAL = 0,
    ST_DEGRADED,
    ST_FAILSAFE,
    ST_SHUTDOWN,
    ST_COUNT
} fsm_state_t;

#define FSM_STATE_POWER_ON 0xFFu  /* pseudo "previous state" of the boot record */

typedef enum {
    EV_NONE = 0,        /* nothing new                                     */
    EV_WARN_FAULT,      /* highest latched severity = WARN                 */
    EV_CRIT_FAULT,      /* highest latched severity = CRIT                 */
    EV_FATAL_FAULT,     /* highest latched severity = FATAL                */
    EV_PROBATION_OK,    /* DEGRADED: fault-free for CFG_PROBATION_MS       */
    EV_VERIFY_PASS,     /* FAILSAFE: recovery verification succeeded       */
    EV_COUNT
} fsm_event_t;

/* Transition table: next = fsm_transition_table[current][event] */
extern const uint8_t fsm_transition_table[ST_COUNT][EV_COUNT];

/* ------------------------------------------------------------------------ */
/* Fault identification                                                     */
/* ------------------------------------------------------------------------ */
typedef enum { SEV_WARN = 1, SEV_CRIT = 2, SEV_FATAL = 3 } fault_sev_t;

typedef enum {
    SRC_NONE  = 0x00,
    SRC_CELL1 = 0x01, SRC_CELL2 = 0x02, SRC_CELL3 = 0x03, SRC_CELL4 = 0x04,
    SRC_PACK  = 0x05,
    SRC_ADC1  = 0x06, SRC_ADC2  = 0x07, SRC_ADC3  = 0x08, SRC_ADC4  = 0x09,
    SRC_RELAY = 0x0A,
    SRC_COMM  = 0x0B,
    SRC_SYS   = 0x0C
} fault_src_t;

typedef enum {
    FT_OV_WARN          = 0x01,
    FT_OV_CRIT          = 0x02,
    FT_UV_WARN          = 0x03,
    FT_UV_CRIT          = 0x04,
    FT_IMBALANCE        = 0x05,
    FT_FROZEN           = 0x10,
    FT_RAIL             = 0x11,
    FT_STUCK_OPEN       = 0x20,
    FT_STUCK_CLOSED     = 0x21,
    FT_FB_IMPLAUSIBLE   = 0x22,
    FT_HB_LATE          = 0x30,
    FT_LINK_LOST        = 0x31,
    FT_SELFTEST_FAIL    = 0x40,
    FT_RECOVERY_EXHAUST = 0x41,
    FT_SHUTDOWN_REQ     = 0x42
} fault_type_t;

/* X(name, source, type, severity, set_debounce, clear_debounce) */
#define FSM_FAULT_LIST(X) \
    X(CELL1_OV_WARN,  SRC_CELL1, FT_OV_WARN,  SEV_WARN, 3, 3) \
    X(CELL1_OV_CRIT,  SRC_CELL1, FT_OV_CRIT,  SEV_CRIT, 3, 3) \
    X(CELL1_UV_WARN,  SRC_CELL1, FT_UV_WARN,  SEV_WARN, 3, 3) \
    X(CELL1_UV_CRIT,  SRC_CELL1, FT_UV_CRIT,  SEV_CRIT, 3, 3) \
    X(CELL2_OV_WARN,  SRC_CELL2, FT_OV_WARN,  SEV_WARN, 3, 3) \
    X(CELL2_OV_CRIT,  SRC_CELL2, FT_OV_CRIT,  SEV_CRIT, 3, 3) \
    X(CELL2_UV_WARN,  SRC_CELL2, FT_UV_WARN,  SEV_WARN, 3, 3) \
    X(CELL2_UV_CRIT,  SRC_CELL2, FT_UV_CRIT,  SEV_CRIT, 3, 3) \
    X(CELL3_OV_WARN,  SRC_CELL3, FT_OV_WARN,  SEV_WARN, 3, 3) \
    X(CELL3_OV_CRIT,  SRC_CELL3, FT_OV_CRIT,  SEV_CRIT, 3, 3) \
    X(CELL3_UV_WARN,  SRC_CELL3, FT_UV_WARN,  SEV_WARN, 3, 3) \
    X(CELL3_UV_CRIT,  SRC_CELL3, FT_UV_CRIT,  SEV_CRIT, 3, 3) \
    X(CELL4_OV_WARN,  SRC_CELL4, FT_OV_WARN,  SEV_WARN, 3, 3) \
    X(CELL4_OV_CRIT,  SRC_CELL4, FT_OV_CRIT,  SEV_CRIT, 3, 3) \
    X(CELL4_UV_WARN,  SRC_CELL4, FT_UV_WARN,  SEV_WARN, 3, 3) \
    X(CELL4_UV_CRIT,  SRC_CELL4, FT_UV_CRIT,  SEV_CRIT, 3, 3) \
    X(PACK_IMBALANCE, SRC_PACK,  FT_IMBALANCE, SEV_WARN, 5, 5) \
    X(ADC1_FROZEN,    SRC_ADC1,  FT_FROZEN,   SEV_CRIT, 1, 3) \
    X(ADC2_FROZEN,    SRC_ADC2,  FT_FROZEN,   SEV_CRIT, 1, 3) \
    X(ADC3_FROZEN,    SRC_ADC3,  FT_FROZEN,   SEV_CRIT, 1, 3) \
    X(ADC4_FROZEN,    SRC_ADC4,  FT_FROZEN,   SEV_CRIT, 1, 3) \
    X(ADC1_RAIL,      SRC_ADC1,  FT_RAIL,     SEV_CRIT, 3, 3) \
    X(ADC2_RAIL,      SRC_ADC2,  FT_RAIL,     SEV_CRIT, 3, 3) \
    X(ADC3_RAIL,      SRC_ADC3,  FT_RAIL,     SEV_CRIT, 3, 3) \
    X(ADC4_RAIL,      SRC_ADC4,  FT_RAIL,     SEV_CRIT, 3, 3) \
    X(RELAY_STUCK_OPEN,   SRC_RELAY, FT_STUCK_OPEN,     SEV_CRIT,  3, 3) \
    X(RELAY_STUCK_CLOSED, SRC_RELAY, FT_STUCK_CLOSED,   SEV_FATAL, 3, 3) \
    X(RELAY_FB_IMPLAUSIBLE, SRC_RELAY, FT_FB_IMPLAUSIBLE, SEV_CRIT, 3, 3) \
    X(COMM_HB_LATE,   SRC_COMM,  FT_HB_LATE,  SEV_WARN, 1, 3) \
    X(COMM_LINK_LOST, SRC_COMM,  FT_LINK_LOST, SEV_CRIT, 1, 3) \
    X(SYS_SELFTEST_FAIL,    SRC_SYS, FT_SELFTEST_FAIL,    SEV_CRIT,  1, 1) \
    X(SYS_RECOVERY_EXHAUST, SRC_SYS, FT_RECOVERY_EXHAUST, SEV_FATAL, 1, 1) \
    X(SYS_SHUTDOWN_REQ,     SRC_SYS, FT_SHUTDOWN_REQ,     SEV_FATAL, 3, 3)

#define FSM_X_ENUM(name, src, type, sev, set_n, clr_n) FLT_##name,
typedef enum { FSM_FAULT_LIST(FSM_X_ENUM) FLT_COUNT } fault_idx_t;
#undef FSM_X_ENUM

typedef struct {
    const char *name;
    uint8_t     source;    /* fault_src_t  */
    uint8_t     type;      /* fault_type_t */
    uint8_t     severity;  /* fault_sev_t  */
    uint8_t     set_n;     /* consecutive detections to activate */
    uint8_t     clr_n;     /* consecutive non-detections to deactivate */
} fault_def_t;

extern const fault_def_t fsm_fault_defs[FLT_COUNT];

/* Per-fault memory, kept for the whole run (fault isolation record) */
typedef struct {
    bool     active;       /* condition present now (debounced)                 */
    bool     latched;      /* WARN: follows active; CRIT/FATAL: held until
                              a verified recovery clears it                     */
    uint8_t  set_cnt;
    uint8_t  clr_cnt;
    uint16_t occurrences;  /* number of activations since boot                  */
    uint32_t first_ms;     /* first activation since boot                       */
    uint32_t last_ms;      /* last time the condition was seen                  */
} fault_rec_t;

/* ------------------------------------------------------------------------ */
/* FAILSAFE recovery verification steps                                     */
/* ------------------------------------------------------------------------ */
typedef enum {
    RS_WAIT_CLEAR = 0,  /* no CRIT/FATAL active for hold time               */
    RS_WAIT_ACK,        /* operator acknowledge (skipped once at power-on)  */
    RS_ADC_CHECK,       /* every ADC channel alive and in range             */
    RS_RELAY_CLOSE,     /* command ON  -> feedback must confirm closed      */
    RS_RELAY_OPEN,      /* command OFF -> feedback must confirm open        */
    RS_COMM_CHECK,      /* heartbeat fresh                                  */
    RS_COUNT
} recovery_step_t;

typedef enum { RR_ENTER = 0, RR_PASS, RR_FAIL, RR_ABORT } recovery_result_t;

/* ------------------------------------------------------------------------ */
/* Structured log                                                           */
/* ------------------------------------------------------------------------ */
typedef enum { LOG_TRANSITION = 0, LOG_RECOVERY = 1 } log_kind_t;

typedef struct {
    uint32_t seq;       /* monotonically increasing                         */
    uint32_t t_ms;      /* timestamp (ms since boot)                        */
    uint8_t  kind;      /* log_kind_t                                       */
    uint8_t  prev;      /* fsm_state_t or FSM_STATE_POWER_ON                */
    uint8_t  next;      /* fsm_state_t                                      */
    uint8_t  event;     /* fsm_event_t (transition)                         */
    uint16_t fault_id;  /* (source << 8) | type ; 0 = none                  */
    uint8_t  fault_idx; /* fault_idx_t or 0xFF                              */
    uint8_t  step;      /* recovery_step_t (recovery records)               */
    uint8_t  result;    /* recovery_result_t (recovery records)             */
    uint8_t  attempt;   /* recovery attempt number                          */
} fsm_log_rec_t;

typedef void (*fsm_log_sink_t)(const fsm_log_rec_t *rec, void *user);

/* ------------------------------------------------------------------------ */
/* I/O                                                                      */
/* ------------------------------------------------------------------------ */
typedef struct {
    uint32_t now_ms;
    uint16_t adc_raw[FSM_NUM_CELLS];
    bool     relay_fb_no;    /* true: NO contact closed (relay energised)   */
    bool     relay_fb_nc;    /* true: NC contact closed (relay released)    */
    bool     heartbeat;      /* heartbeat frame received since last step    */
    bool     recovery_ack;   /* operator acknowledge (level; edge-detected) */
    bool     shutdown_req;   /* operator / supervisor shutdown request      */
} fsm_inputs_t;

typedef struct {
    bool        relay_on;    /* command for the relay driver                */
    fsm_state_t state;
    uint8_t     rstep;       /* recovery_step_t, meaningful in FAILSAFE     */
} fsm_outputs_t;

/* ------------------------------------------------------------------------ */
/* Context                                                                  */
/* ------------------------------------------------------------------------ */
typedef struct {
    fsm_state_t state;
    uint32_t    now_ms;
    uint32_t    state_enter_ms;

    fault_rec_t faults[FLT_COUNT];

    /* ADC */
    uint16_t last_raw[FSM_NUM_CELLS];
    uint16_t same_cnt[FSM_NUM_CELLS];
    uint16_t adc_changes[FSM_NUM_CELLS];
    uint16_t cell_mv[FSM_NUM_CELLS];
    bool     adc_seen;

    /* relay */
    bool     relay_cmd;
    uint32_t relay_cmd_change_ms;
    uint8_t  relay_confirm;

    /* comm */
    uint32_t last_hb_ms;

    /* recovery */
    uint8_t  rstep;
    uint32_t rstep_enter_ms;
    uint32_t clear_since_ms;
    uint8_t  attempts;
    bool     auto_ack;          /* power-on self test needs no operator ack */
    bool     prev_ack;
    bool     verify_pass;       /* set for one tick                         */
    uint32_t fs_entry_ms[CFG_FLAP_MAX_ENTRIES];
    uint8_t  fs_entry_count;
    uint8_t  fs_entry_head;

    /* probation */
    uint32_t last_fault_seen_ms;

    /* log */
    fsm_log_rec_t log[FSM_LOG_DEPTH];
    uint32_t      log_seq;
    uint16_t      log_head;     /* next write slot                           */
    uint16_t      log_count;
    fsm_log_sink_t sink;
    void          *sink_user;
} fsm_ctx_t;

/* ------------------------------------------------------------------------ */
/* API                                                                      */
/* ------------------------------------------------------------------------ */
void        fsm_init(fsm_ctx_t *ctx, uint32_t now_ms, fsm_log_sink_t sink, void *user);
void        fsm_step(fsm_ctx_t *ctx, const fsm_inputs_t *in, fsm_outputs_t *out);

fsm_state_t fsm_next_state(fsm_state_t s, fsm_event_t e);
uint16_t    fsm_fault_id(fault_idx_t idx);
int         fsm_primary_fault(const fsm_ctx_t *ctx);  /* -1 if none latched */

const char *fsm_state_name(uint8_t s);
const char *fsm_event_name(uint8_t e);
const char *fsm_source_name(uint8_t src);
const char *fsm_sev_name(uint8_t sev);
const char *fsm_step_name(uint8_t step);
const char *fsm_result_name(uint8_t r);

/* Log access: i = 0 is the oldest record still in the ring buffer */
uint16_t             fsm_log_count(const fsm_ctx_t *ctx);
const fsm_log_rec_t *fsm_log_get(const fsm_ctx_t *ctx, uint16_t i);

/* Formatting helpers (JSON Lines). Return snprintf-style length. */
int fsm_format_log_json(const fsm_log_rec_t *r, char *buf, size_t n);
int fsm_format_fault_json(const fsm_ctx_t *ctx, fault_idx_t idx, char *buf, size_t n);
int fsm_format_status_json(const fsm_ctx_t *ctx, char *buf, size_t n);

#ifdef __cplusplus
}
#endif
#endif /* FAULT_FSM_H */
