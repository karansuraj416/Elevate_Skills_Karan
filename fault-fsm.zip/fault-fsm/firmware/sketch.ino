/*
 * sketch.ino — ESP32 board-support layer for the fault state machine.
 * Runs in the Wokwi simulator (diagram.json) or on a real ESP32 DevKit.
 *
 * Everything safety-relevant lives in fault_fsm.c. This file only:
 *   - samples the hardware every FSM_TICK_MS and calls fsm_step()
 *   - drives the relay and state LEDs from the outputs
 *   - provides fault-injection hooks (DIP switches) for the demo
 *   - prints the structured log (JSON Lines) and handles serial commands
 *
 * Fault injection DIP switch (ON = pulled to GND):
 *   SW1  freeze ADC channel 1 (cell 1 reading stops updating)
 *   SW2  drop communication heartbeat
 *   SW3  relay coil drive lost  -> relay cannot close  (stuck-open)
 *   SW4  relay contact welded   -> relay cannot open   (stuck-closed, FATAL)
 *   SW5  operator shutdown request
 * Button "ACK" : request FAILSAFE recovery verification
 * Pots 1..4    : cell voltages 2.50 V .. 4.50 V
 */
#include <Arduino.h>
#include "fault_fsm.h"

/* ---------------- Pin map (ESP32 DevKit C v4) ---------------- */
static const uint8_t PIN_CELL[FSM_NUM_CELLS] = { 34, 35, 32, 33 };  /* ADC1 pins */
static const uint8_t PIN_RELAY_IN  = 26;
static const uint8_t PIN_FB_NO     = 27;   /* relay NO contact -> GND when closed */
static const uint8_t PIN_FB_NC     = 14;   /* relay NC contact -> GND when closed */
static const uint8_t PIN_SW_FREEZE = 4;
static const uint8_t PIN_SW_COMM   = 16;
static const uint8_t PIN_SW_COIL   = 17;
static const uint8_t PIN_SW_WELD   = 18;
static const uint8_t PIN_SW_SHUT   = 19;
static const uint8_t PIN_BTN_ACK   = 13;
static const uint8_t PIN_LED_NORMAL   = 21;  /* green  */
static const uint8_t PIN_LED_DEGRADED = 22;  /* yellow */
static const uint8_t PIN_LED_FAILSAFE = 23;  /* red    */
static const uint8_t PIN_LED_SHUTDOWN = 25;  /* blue   */

/* Wokwi relay module default ("npn"): IN HIGH energises the coil (COM->NO).
 * If your relay module is active-low, set this to 0. */
#define RELAY_IN_ACTIVE_HIGH 1

/* Wokwi potentiometers are perfectly noise-free, so a healthy channel would
 * look "frozen". Real ADC front-ends always show a few LSB of noise; this
 * adds that noise in simulation. Set to 0 on real hardware. */
#define SIM_ADC_DITHER 1

#define HEARTBEAT_PERIOD_MS 100u
#define STATUS_PERIOD_MS    5000u

static fsm_ctx_t     g_fsm;
static fsm_outputs_t g_out;
static uint32_t      g_next_tick;
static uint32_t      g_next_hb;
static uint32_t      g_next_status;
static bool          g_hb_pending;
static bool          g_serial_ack;
static bool          g_periodic_status = true;
static uint16_t      g_frozen_raw;
static bool          g_freeze_active;
static uint32_t      g_lfsr = 0xACE1u;
static char          g_line[320];

/* ---------------- Helpers ---------------- */
static bool sw_on(uint8_t pin) { return digitalRead(pin) == LOW; }

static uint16_t lfsr_noise(void)          /* deterministic pseudo-noise */
{
    g_lfsr ^= g_lfsr << 13; g_lfsr ^= g_lfsr >> 17; g_lfsr ^= g_lfsr << 5;
    return (uint16_t)(g_lfsr & 0x3u);       /* 0..3 */
}

static uint16_t read_cell_raw(uint8_t ch)
{
    int raw = analogRead(PIN_CELL[ch]);     /* 0..4095 */
#if SIM_ADC_DITHER
    raw += (int)lfsr_noise() - 1;           /* -1..+2 LSB */
    if (raw < 0) raw = 0;
    if (raw > 4095) raw = 4095;
#endif
    if (ch == 0) {                          /* fault injection: stuck ADC */
        if (sw_on(PIN_SW_FREEZE)) {
            if (!g_freeze_active) { g_frozen_raw = (uint16_t)raw; g_freeze_active = true; }
            return g_frozen_raw;
        }
        g_freeze_active = false;
    }
    return (uint16_t)raw;
}

static void drive_relay(bool cmd_on)
{
    bool energise = cmd_on;
    if (sw_on(PIN_SW_COIL)) energise = false;   /* injected: coil drive lost  */
    if (sw_on(PIN_SW_WELD)) energise = true;    /* injected: contact welded   */
    digitalWrite(PIN_RELAY_IN, (energise == (bool)RELAY_IN_ACTIVE_HIGH) ? HIGH : LOW);
}

static void drive_leds(uint32_t now)
{
    bool blink = ((now / 250u) & 1u) != 0u;
    bool fs    = (g_out.state == ST_FAILSAFE);
    /* Red blinks while waiting for the operator, solid otherwise */
    bool red   = fs && ((g_out.rstep == RS_WAIT_ACK) ? blink : true);
    digitalWrite(PIN_LED_NORMAL,   g_out.state == ST_NORMAL   ? HIGH : LOW);
    digitalWrite(PIN_LED_DEGRADED, g_out.state == ST_DEGRADED ? HIGH : LOW);
    digitalWrite(PIN_LED_FAILSAFE, red ? HIGH : LOW);
    digitalWrite(PIN_LED_SHUTDOWN, g_out.state == ST_SHUTDOWN ? HIGH : LOW);
}

/* Every log record (transition or recovery step) is printed immediately. */
static void log_sink(const fsm_log_rec_t *rec, void *user)
{
    (void)user;
    fsm_format_log_json(rec, g_line, sizeof g_line);
    Serial.println(g_line);
}

static void print_status(void)
{
    fsm_format_status_json(&g_fsm, g_line, sizeof g_line);
    Serial.println(g_line);
}

static void print_faults(bool all)
{
    for (int i = 0; i < (int)FLT_COUNT; i++) {
        if (all || g_fsm.faults[i].occurrences > 0 || g_fsm.faults[i].latched) {
            fsm_format_fault_json(&g_fsm, (fault_idx_t)i, g_line, sizeof g_line);
            Serial.println(g_line);
        }
    }
}

static void print_log(void)
{
    for (uint16_t i = 0; i < fsm_log_count(&g_fsm); i++) {
        fsm_format_log_json(fsm_log_get(&g_fsm, i), g_line, sizeof g_line);
        Serial.println(g_line);
    }
}

static void print_help(void)
{
    Serial.println(F("# Commands: s=status  f=faults seen  F=all faults  l=log dump"));
    Serial.println(F("#           r=recovery ack  p=toggle periodic status  h=help"));
    Serial.println(F("# DIP: 1=freeze ADC1 2=comm drop 3=coil lost 4=contact weld 5=shutdown"));
}

static void handle_serial(void)
{
    while (Serial.available() > 0) {
        char c = (char)Serial.read();
        switch (c) {
        case 's': print_status(); break;
        case 'f': print_faults(false); break;
        case 'F': print_faults(true); break;
        case 'l': print_log(); break;
        case 'r': g_serial_ack = true; Serial.println(F("# ack requested")); break;
        case 'p': g_periodic_status = !g_periodic_status; break;
        case 'h': case '?': print_help(); break;
        default: break;
        }
    }
}

/* ---------------- Arduino entry points ---------------- */
void setup()
{
    Serial.begin(115200);
    analogReadResolution(12);
    analogSetAttenuation(ADC_11db);         /* ~0..3.3 V full scale */

    pinMode(PIN_RELAY_IN, OUTPUT);
    pinMode(PIN_FB_NO, INPUT_PULLUP);
    pinMode(PIN_FB_NC, INPUT_PULLUP);
    pinMode(PIN_SW_FREEZE, INPUT_PULLUP);
    pinMode(PIN_SW_COMM,   INPUT_PULLUP);
    pinMode(PIN_SW_COIL,   INPUT_PULLUP);
    pinMode(PIN_SW_WELD,   INPUT_PULLUP);
    pinMode(PIN_SW_SHUT,   INPUT_PULLUP);
    pinMode(PIN_BTN_ACK,   INPUT_PULLUP);
    pinMode(PIN_LED_NORMAL, OUTPUT);
    pinMode(PIN_LED_DEGRADED, OUTPUT);
    pinMode(PIN_LED_FAILSAFE, OUTPUT);
    pinMode(PIN_LED_SHUTDOWN, OUTPUT);
    drive_relay(false);                     /* safe default before the FSM runs */

    delay(50);
    Serial.println(F("# Fault FSM demo - JSON Lines log follows"));
    print_help();

    uint32_t now = millis();
    fsm_init(&g_fsm, now, log_sink, nullptr);
    g_next_tick   = now + FSM_TICK_MS;
    g_next_hb     = now + HEARTBEAT_PERIOD_MS;
    g_next_status = now + STATUS_PERIOD_MS;
}

void loop()
{
    uint32_t now = millis();
    handle_serial();

    /* Simulated remote supervisor: sends a heartbeat every 100 ms */
    if ((int32_t)(now - g_next_hb) >= 0) {
        g_next_hb += HEARTBEAT_PERIOD_MS;
        if (!sw_on(PIN_SW_COMM)) g_hb_pending = true;
    }

    /* Fixed-period FSM tick */
    if ((int32_t)(now - g_next_tick) >= 0) {
        fsm_inputs_t in;
        g_next_tick += FSM_TICK_MS;

        in.now_ms = now;
        for (uint8_t ch = 0; ch < FSM_NUM_CELLS; ch++) in.adc_raw[ch] = read_cell_raw(ch);
        in.relay_fb_no  = (digitalRead(PIN_FB_NO) == LOW);
        in.relay_fb_nc  = (digitalRead(PIN_FB_NC) == LOW);
        in.heartbeat    = g_hb_pending;
        in.recovery_ack = sw_on(PIN_BTN_ACK) || g_serial_ack;
        in.shutdown_req = sw_on(PIN_SW_SHUT);
        g_hb_pending = false;
        g_serial_ack = false;   /* serial ack is a one-tick pulse */

        fsm_step(&g_fsm, &in, &g_out);
        drive_relay(g_out.relay_on);
    }

    drive_leds(now);

    if (g_periodic_status && (int32_t)(now - g_next_status) >= 0) {
        g_next_status += STATUS_PERIOD_MS;
        print_status();
    }
}
