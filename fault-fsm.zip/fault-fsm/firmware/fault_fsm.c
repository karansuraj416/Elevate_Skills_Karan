/*
 * fault_fsm.c — Deterministic fault state machine with structured recovery
 *
 * Determinism rules followed here:
 *   - one call to fsm_step() per fixed tick, all inputs passed in explicitly
 *   - integer arithmetic only, no heap, no clocks read internally
 *   - at most ONE state transition per tick, chosen by a fixed priority
 *   - ties between faults of equal severity are broken by table index
 *
 * Deadlock / livelock freedom:
 *   - every state except SHUTDOWN has an outgoing transition in the table
 *   - every recovery verification step has a timeout
 *   - failed verifications are counted; CFG_MAX_RECOVERY_ATTEMPTS -> SHUTDOWN
 *   - repeated FAILSAFE entries (flapping) inside a window -> SHUTDOWN
 *   - SHUTDOWN is the single intentional absorbing (terminal) state
 */
#include "fault_fsm.h"
#include <string.h>
#include <stdio.h>

/* ------------------------------------------------------------------------ */
/* Tables                                                                   */
/* ------------------------------------------------------------------------ */
#define N ST_NORMAL
#define D ST_DEGRADED
#define F ST_FAILSAFE
#define S ST_SHUTDOWN
/*                                   NONE WARN CRIT FATAL PROB_OK VERIFY_PASS */
const uint8_t fsm_transition_table[ST_COUNT][EV_COUNT] = {
    /* NORMAL   */ {               N,   D,   F,   S,    N,      N },
    /* DEGRADED */ {               D,   D,   F,   S,    N,      D },
    /* FAILSAFE */ {               F,   F,   F,   S,    F,      D },
    /* SHUTDOWN */ {               S,   S,   S,   S,    S,      S },
};
#undef N
#undef D
#undef F
#undef S
/* Note: FAILSAFE never goes straight to NORMAL. A verified recovery lands in
 * DEGRADED (probation) and only a fault-free probation period reaches NORMAL. */

#define FSM_X_DEF(name, src, type, sev, set_n, clr_n) \
    { #name, (uint8_t)(src), (uint8_t)(type), (uint8_t)(sev), (uint8_t)(set_n), (uint8_t)(clr_n) },
const fault_def_t fsm_fault_defs[FLT_COUNT] = { FSM_FAULT_LIST(FSM_X_DEF) };
#undef FSM_X_DEF

static const char *const k_state_names[ST_COUNT] = { "NORMAL", "DEGRADED", "FAILSAFE", "SHUTDOWN" };
static const char *const k_event_names[EV_COUNT] = {
    "NONE", "WARN_FAULT", "CRIT_FAULT", "FATAL_FAULT", "PROBATION_OK", "VERIFY_PASS" };
static const char *const k_step_names[RS_COUNT] = {
    "WAIT_CLEAR", "WAIT_ACK", "ADC_CHECK", "RELAY_CLOSE", "RELAY_OPEN", "COMM_CHECK" };
static const char *const k_result_names[4] = { "ENTER", "PASS", "FAIL", "ABORT" };

/* ------------------------------------------------------------------------ */
/* Small helpers                                                            */
/* ------------------------------------------------------------------------ */
static uint32_t elapsed(const fsm_ctx_t *c, uint32_t since)
{
    return (uint32_t)(c->now_ms - since);      /* wrap-safe */
}

uint16_t fsm_fault_id(fault_idx_t idx)
{
    if ((int)idx < 0 || idx >= FLT_COUNT) return 0;
    return (uint16_t)(((uint16_t)fsm_fault_defs[idx].source << 8) | fsm_fault_defs[idx].type);
}

fsm_state_t fsm_next_state(fsm_state_t s, fsm_event_t e)
{
    if (s >= ST_COUNT || e >= EV_COUNT) return ST_SHUTDOWN;  /* defensive */
    return (fsm_state_t)fsm_transition_table[s][e];
}

const char *fsm_state_name(uint8_t s)
{
    if (s == FSM_STATE_POWER_ON) return "POWER_ON";
    return (s < ST_COUNT) ? k_state_names[s] : "?";
}
const char *fsm_event_name(uint8_t e)  { return (e < EV_COUNT) ? k_event_names[e] : "?"; }
const char *fsm_step_name(uint8_t st)  { return (st < RS_COUNT) ? k_step_names[st] : "VERIFIED"; }
const char *fsm_result_name(uint8_t r) { return (r < 4) ? k_result_names[r] : "?"; }

const char *fsm_sev_name(uint8_t sev)
{
    switch (sev) {
    case SEV_WARN:  return "WARN";
    case SEV_CRIT:  return "CRIT";
    case SEV_FATAL: return "FATAL";
    default:        return "NONE";
    }
}

const char *fsm_source_name(uint8_t src)
{
    switch (src) {
    case SRC_CELL1: return "CELL1"; case SRC_CELL2: return "CELL2";
    case SRC_CELL3: return "CELL3"; case SRC_CELL4: return "CELL4";
    case SRC_PACK:  return "PACK";
    case SRC_ADC1:  return "ADC1";  case SRC_ADC2:  return "ADC2";
    case SRC_ADC3:  return "ADC3";  case SRC_ADC4:  return "ADC4";
    case SRC_RELAY: return "RELAY";
    case SRC_COMM:  return "COMM";
    case SRC_SYS:   return "SYSTEM";
    default:        return "NONE";
    }
}

/* ------------------------------------------------------------------------ */
/* Logging                                                                  */
/* ------------------------------------------------------------------------ */
static void log_push(fsm_ctx_t *c, fsm_log_rec_t *r)
{
    r->seq  = ++c->log_seq;
    r->t_ms = c->now_ms;
    c->log[c->log_head] = *r;
    c->log_head = (uint16_t)((c->log_head + 1u) % FSM_LOG_DEPTH);
    if (c->log_count < FSM_LOG_DEPTH) c->log_count++;
    if (c->sink) c->sink(r, c->sink_user);
}

static void log_transition(fsm_ctx_t *c, uint8_t prev, uint8_t next, uint8_t ev, int fault)
{
    fsm_log_rec_t r;
    memset(&r, 0, sizeof r);
    r.kind      = LOG_TRANSITION;
    r.prev      = prev;
    r.next      = next;
    r.event     = ev;
    r.fault_idx = (fault >= 0) ? (uint8_t)fault : 0xFFu;
    r.fault_id  = (fault >= 0) ? fsm_fault_id((fault_idx_t)fault) : 0u;
    r.attempt   = c->attempts;
    log_push(c, &r);
}

static void log_recovery(fsm_ctx_t *c, uint8_t step, uint8_t result, int fault)
{
    fsm_log_rec_t r;
    memset(&r, 0, sizeof r);
    r.kind      = LOG_RECOVERY;
    r.prev      = (uint8_t)c->state;
    r.next      = (uint8_t)c->state;
    r.step      = step;
    r.result    = result;
    r.fault_idx = (fault >= 0) ? (uint8_t)fault : 0xFFu;
    r.fault_id  = (fault >= 0) ? fsm_fault_id((fault_idx_t)fault) : 0u;
    r.attempt   = c->attempts;
    log_push(c, &r);
}

uint16_t fsm_log_count(const fsm_ctx_t *c) { return c->log_count; }

const fsm_log_rec_t *fsm_log_get(const fsm_ctx_t *c, uint16_t i)
{
    uint16_t oldest;
    if (i >= c->log_count) return NULL;
    oldest = (uint16_t)((c->log_head + FSM_LOG_DEPTH - c->log_count) % FSM_LOG_DEPTH);
    return &c->log[(oldest + i) % FSM_LOG_DEPTH];
}

/* ------------------------------------------------------------------------ */
/* Fault memory                                                             */
/* ------------------------------------------------------------------------ */
/* Debounced update from a live detection condition. */
static void fault_update(fsm_ctx_t *c, fault_idx_t i, bool cond)
{
    fault_rec_t *r = &c->faults[i];
    const fault_def_t *d = &fsm_fault_defs[i];

    if (cond) {
        r->clr_cnt = 0;
        if (r->active) {
            r->last_ms = c->now_ms;
        } else {
            if (r->set_cnt < 0xFFu) r->set_cnt++;
            if (r->set_cnt >= d->set_n) {
                r->active  = true;
                r->latched = true;
                r->set_cnt = 0;
                if (r->occurrences == 0) r->first_ms = c->now_ms;
                if (r->occurrences < 0xFFFFu) r->occurrences++;
                r->last_ms = c->now_ms;
            }
        }
    } else {
        r->set_cnt = 0;
        if (r->active) {
            if (r->clr_cnt < 0xFFu) r->clr_cnt++;
            if (r->clr_cnt >= d->clr_n) {
                r->active  = false;
                r->clr_cnt = 0;
                if (d->severity == SEV_WARN) r->latched = false;  /* self-clearing */
            }
        }
    }
}

/* Latch a fault directly (verification results, system decisions). */
static void fault_raise(fsm_ctx_t *c, fault_idx_t i)
{
    fault_rec_t *r = &c->faults[i];
    if (!r->latched) {
        if (r->occurrences == 0) r->first_ms = c->now_ms;
        if (r->occurrences < 0xFFFFu) r->occurrences++;
    }
    r->latched = true;
    r->last_ms = c->now_ms;
}

/* First (lowest index) fault that is ACTIVE with severity >= min_sev, or -1 */
static int first_active_at_least(const fsm_ctx_t *c, uint8_t min_sev)
{
    int i;
    for (i = 0; i < (int)FLT_COUNT; i++)
        if (c->faults[i].active && fsm_fault_defs[i].severity >= min_sev) return i;
    return -1;
}

/* Highest-severity latched fault; ties -> lowest index. -1 if none. */
int fsm_primary_fault(const fsm_ctx_t *c)
{
    int i, best = -1;
    uint8_t best_sev = 0;
    for (i = 0; i < (int)FLT_COUNT; i++) {
        if (c->faults[i].latched && fsm_fault_defs[i].severity > best_sev) {
            best_sev = fsm_fault_defs[i].severity;
            best = i;
        }
    }
    return best;
}

/* ------------------------------------------------------------------------ */
/* Detection                                                                */
/* ------------------------------------------------------------------------ */
static bool hyst_high(bool active, uint16_t v, uint16_t set, uint16_t clr)
{
    return active ? (v > clr) : (v >= set);
}
static bool hyst_low(bool active, uint16_t v, uint16_t set, uint16_t clr)
{
    return active ? (v < clr) : (v <= set);
}

static void detect_adc_and_cells(fsm_ctx_t *c, const fsm_inputs_t *in)
{
    bool     trusted[FSM_NUM_CELLS];
    uint16_t vmin = 0xFFFFu, vmax = 0;
    unsigned ch, n_trusted = 0;

    for (ch = 0; ch < FSM_NUM_CELLS; ch++) {
        uint16_t raw  = in->adc_raw[ch];
        bool     rail = (raw <= CFG_ADC_RAIL_LO) || (raw >= CFG_ADC_RAIL_HI);
        bool     frozen;

        if (c->adc_seen && raw == c->last_raw[ch]) {
            if (c->same_cnt[ch] < 0xFFFFu) c->same_cnt[ch]++;
        } else {
            if (c->adc_seen && c->adc_changes[ch] < 0xFFFFu) c->adc_changes[ch]++;
            c->same_cnt[ch] = 0;
        }
        c->last_raw[ch] = raw;

        /* A railed channel is reported as RAIL, not FROZEN (fault isolation) */
        frozen = (c->same_cnt[ch] >= CFG_ADC_FROZEN_SAMPLES) && !rail;
        fault_update(c, (fault_idx_t)(FLT_ADC1_FROZEN + ch), frozen);
        fault_update(c, (fault_idx_t)(FLT_ADC1_RAIL + ch), rail);

        c->cell_mv[ch] = (uint16_t)(CFG_CELL_MV_MIN +
                         ((uint32_t)raw * CFG_CELL_MV_SPAN) / CFG_ADC_MAX);

        /* Isolation: never blame the cell for a bad measurement channel.
         * Uses the instantaneous rail condition so a railed reading cannot
         * raise a cell UV/OV fault even before the RAIL fault debounces. */
        trusted[ch] = !rail && !c->faults[FLT_ADC1_FROZEN + ch].active;
    }
    c->adc_seen = true;

    for (ch = 0; ch < FSM_NUM_CELLS; ch++) {
        fault_idx_t base = (fault_idx_t)(FLT_CELL1_OV_WARN + ch * 4u);
        uint16_t mv = c->cell_mv[ch];
        if (!trusted[ch]) continue;           /* hold cell faults as they are */

        fault_update(c, (fault_idx_t)(base + 0), hyst_high(c->faults[base + 0].active, mv, CFG_OV_WARN_SET, CFG_OV_WARN_CLR));
        fault_update(c, (fault_idx_t)(base + 1), hyst_high(c->faults[base + 1].active, mv, CFG_OV_CRIT_SET, CFG_OV_CRIT_CLR));
        fault_update(c, (fault_idx_t)(base + 2), hyst_low (c->faults[base + 2].active, mv, CFG_UV_WARN_SET, CFG_UV_WARN_CLR));
        fault_update(c, (fault_idx_t)(base + 3), hyst_low (c->faults[base + 3].active, mv, CFG_UV_CRIT_SET, CFG_UV_CRIT_CLR));

        if (mv < vmin) vmin = mv;
        if (mv > vmax) vmax = mv;
        n_trusted++;
    }

    if (n_trusted >= 2u) {
        uint16_t spread = (uint16_t)(vmax - vmin);
        fault_update(c, FLT_PACK_IMBALANCE,
                     hyst_high(c->faults[FLT_PACK_IMBALANCE].active, spread, CFG_IMBAL_SET, CFG_IMBAL_CLR));
    }
}

static void detect_relay(fsm_ctx_t *c, const fsm_inputs_t *in)
{
    bool closed    = in->relay_fb_no;
    bool plausible = (in->relay_fb_no != in->relay_fb_nc);  /* exactly one contact closed */

    fault_update(c, FLT_RELAY_FB_IMPLAUSIBLE, !plausible);

    /* Mismatch only after the contact had time to move, and only with
     * believable feedback (otherwise the relay is not to blame). */
    if (plausible && elapsed(c, c->relay_cmd_change_ms) >= CFG_RELAY_SETTLE_MS) {
        fault_update(c, FLT_RELAY_STUCK_OPEN,    c->relay_cmd && !closed);
        fault_update(c, FLT_RELAY_STUCK_CLOSED, !c->relay_cmd &&  closed);
    }
}

static void detect_comm(fsm_ctx_t *c, const fsm_inputs_t *in)
{
    uint32_t age;
    if (in->heartbeat) c->last_hb_ms = c->now_ms;
    age = elapsed(c, c->last_hb_ms);
    fault_update(c, FLT_COMM_HB_LATE,   age > CFG_HB_LATE_MS);
    fault_update(c, FLT_COMM_LINK_LOST, age > CFG_HB_LOST_MS);
}

/* ------------------------------------------------------------------------ */
/* FAILSAFE recovery verification                                           */
/* ------------------------------------------------------------------------ */
static void set_step(fsm_ctx_t *c, uint8_t step)
{
    c->rstep          = step;
    c->rstep_enter_ms = c->now_ms;
    c->relay_confirm  = 0;
    if (step == RS_WAIT_CLEAR) c->clear_since_ms = c->now_ms;
    if (step == RS_ADC_CHECK) {
        unsigned ch;
        for (ch = 0; ch < FSM_NUM_CELLS; ch++) c->adc_changes[ch] = 0;
    }
    log_recovery(c, step, RR_ENTER, -1);
}

static void recovery_fail(fsm_ctx_t *c, int fault, uint8_t result)
{
    log_recovery(c, c->rstep, result, fault);
    fault_raise(c, FLT_SYS_SELFTEST_FAIL);
    c->auto_ack = false;                         /* further tries need an ack */
    if (c->attempts >= CFG_MAX_RECOVERY_ATTEMPTS)
        fault_raise(c, FLT_SYS_RECOVERY_EXHAUST);  /* FATAL -> SHUTDOWN next */
    set_step(c, RS_WAIT_CLEAR);
}

static void recovery_pass(fsm_ctx_t *c)
{
    int i;
    /* Verified: release CRIT latches whose condition is gone. */
    for (i = 0; i < (int)FLT_COUNT; i++) {
        if (fsm_fault_defs[i].severity == SEV_CRIT && !c->faults[i].active)
            c->faults[i].latched = false;
    }
    log_recovery(c, RS_COUNT, RR_PASS, -1);      /* step name "VERIFIED" */
    c->verify_pass = true;
    c->auto_ack    = false;
    c->rstep          = RS_WAIT_CLEAR;           /* parked; re-armed on next entry */
    c->rstep_enter_ms = c->now_ms;
}

static void recovery_run(fsm_ctx_t *c, const fsm_inputs_t *in)
{
    bool ack_edge = in->recovery_ack && !c->prev_ack;
    int  live     = first_active_at_least(c, SEV_CRIT);
    uint32_t t    = elapsed(c, c->rstep_enter_ms);

    switch (c->rstep) {
    case RS_WAIT_CLEAR: {
        uint32_t hold = c->auto_ack ? CFG_POST_HOLD_MS : CFG_RECOVERY_HOLD_MS;
        if (live >= 0) {
            c->clear_since_ms = c->now_ms;           /* restart the hold timer */
        } else if (elapsed(c, c->clear_since_ms) >= hold) {
            if (c->auto_ack) { c->attempts++; set_step(c, RS_ADC_CHECK); }
            else             { set_step(c, RS_WAIT_ACK); }
        }
        break;
    }
    case RS_WAIT_ACK:
        if (live >= 0)      { set_step(c, RS_WAIT_CLEAR); }
        else if (ack_edge)  { c->attempts++; set_step(c, RS_ADC_CHECK); }
        break;

    default:
        /* Any live CRIT/FATAL fault during verification aborts it. */
        if (live >= 0) { recovery_fail(c, live, RR_ABORT); break; }

        switch (c->rstep) {
        case RS_ADC_CHECK:
            if (t >= CFG_ADC_CHECK_MS) {
                unsigned ch;
                int dead = -1;
                for (ch = 0; ch < FSM_NUM_CELLS; ch++) {
                    if (c->adc_changes[ch] < CFG_ADC_MIN_CHANGES) { dead = (int)ch; break; }
                }
                if (dead < 0) {
                    set_step(c, RS_RELAY_CLOSE);
                } else {
                    fault_idx_t f = (fault_idx_t)(FLT_ADC1_FROZEN + dead);
                    fault_raise(c, f);                 /* isolate the dead channel */
                    recovery_fail(c, (int)f, RR_FAIL);
                }
            }
            break;

        case RS_RELAY_CLOSE:
            c->relay_confirm = (in->relay_fb_no && !in->relay_fb_nc) ? (uint8_t)(c->relay_confirm + 1u) : 0u;
            if (c->relay_confirm >= CFG_RELAY_CONFIRM_SAMPLES) {
                set_step(c, RS_RELAY_OPEN);
            } else if (t >= CFG_RELAY_TEST_TIMEOUT_MS) {
                fault_raise(c, FLT_RELAY_STUCK_OPEN);
                recovery_fail(c, FLT_RELAY_STUCK_OPEN, RR_FAIL);
            }
            break;

        case RS_RELAY_OPEN:
            c->relay_confirm = (!in->relay_fb_no && in->relay_fb_nc) ? (uint8_t)(c->relay_confirm + 1u) : 0u;
            if (c->relay_confirm >= CFG_RELAY_CONFIRM_SAMPLES) {
                set_step(c, RS_COMM_CHECK);
            } else if (t >= CFG_RELAY_TEST_TIMEOUT_MS) {
                fault_raise(c, FLT_RELAY_STUCK_CLOSED);  /* FATAL: cannot isolate */
                recovery_fail(c, FLT_RELAY_STUCK_CLOSED, RR_FAIL);
            }
            break;

        case RS_COMM_CHECK:
            if (elapsed(c, c->last_hb_ms) < CFG_HB_LATE_MS) {
                recovery_pass(c);
            } else if (t >= CFG_COMM_CHECK_TIMEOUT_MS) {
                recovery_fail(c, FLT_COMM_HB_LATE, RR_FAIL);
            }
            break;

        default:                                       /* unreachable: re-arm */
            set_step(c, RS_WAIT_CLEAR);
            break;
        }
        break;
    }
}

/* ------------------------------------------------------------------------ */
/* State machine                                                            */
/* ------------------------------------------------------------------------ */
static fsm_event_t derive_event(const fsm_ctx_t *c, int primary)
{
    uint8_t sev = (primary >= 0) ? fsm_fault_defs[primary].severity : 0u;

    if (sev == SEV_FATAL) return EV_FATAL_FAULT;
    if (sev == SEV_CRIT)  return EV_CRIT_FAULT;
    if (c->verify_pass)   return EV_VERIFY_PASS;
    if (sev == SEV_WARN)  return EV_WARN_FAULT;
    if (c->state == ST_DEGRADED &&
        elapsed(c, c->last_fault_seen_ms) >= CFG_PROBATION_MS)
        return EV_PROBATION_OK;
    return EV_NONE;
}

static void enter_state(fsm_ctx_t *c, fsm_state_t next)
{
    c->state          = next;
    c->state_enter_ms = c->now_ms;

    switch (next) {
    case ST_NORMAL:
        c->attempts = 0;                       /* fully recovered */
        break;
    case ST_DEGRADED:
        c->last_fault_seen_ms = c->now_ms;     /* probation starts now */
        break;
    case ST_FAILSAFE: {
        unsigned k, recent = 0;
        c->fs_entry_ms[c->fs_entry_head] = c->now_ms;
        c->fs_entry_head = (uint8_t)((c->fs_entry_head + 1u) % CFG_FLAP_MAX_ENTRIES);
        if (c->fs_entry_count < CFG_FLAP_MAX_ENTRIES) c->fs_entry_count++;
        for (k = 0; k < c->fs_entry_count; k++)
            if (elapsed(c, c->fs_entry_ms[k]) < CFG_FLAP_WINDOW_MS) recent++;
        if (recent >= CFG_FLAP_MAX_ENTRIES)
            fault_raise(c, FLT_SYS_RECOVERY_EXHAUST);   /* flapping -> SHUTDOWN */
        set_step(c, RS_WAIT_CLEAR);
        break;
    }
    case ST_SHUTDOWN:
    default:
        break;
    }
}

void fsm_init(fsm_ctx_t *c, uint32_t now_ms, fsm_log_sink_t sink, void *user)
{
    memset(c, 0, sizeof *c);
    c->sink                = sink;
    c->sink_user           = user;
    c->now_ms              = now_ms;
    c->state               = ST_FAILSAFE;   /* boot safe: relay open, run POST */
    c->state_enter_ms      = now_ms;
    c->auto_ack            = true;          /* power-on self test, no ack needed */
    c->relay_cmd           = false;
    c->relay_cmd_change_ms = now_ms;
    c->last_hb_ms          = now_ms;
    c->last_fault_seen_ms  = now_ms;

    log_transition(c, FSM_STATE_POWER_ON, ST_FAILSAFE, EV_NONE, -1);
    set_step(c, RS_WAIT_CLEAR);
}

void fsm_step(fsm_ctx_t *c, const fsm_inputs_t *in, fsm_outputs_t *out)
{
    int primary;
    fsm_event_t ev;
    fsm_state_t next;
    bool cmd;

    c->now_ms      = in->now_ms;
    c->verify_pass = false;

    /* 1. Detection and fault isolation */
    detect_adc_and_cells(c, in);
    detect_relay(c, in);
    detect_comm(c, in);
    fault_update(c, FLT_SYS_SHUTDOWN_REQ, in->shutdown_req);

    /* 2. Structured recovery (only meaningful in FAILSAFE) */
    if (c->state == ST_FAILSAFE) recovery_run(c, in);
    c->prev_ack = in->recovery_ack;

    /* 3. One event, one table lookup, at most one transition */
    primary = fsm_primary_fault(c);
    if (primary >= 0) c->last_fault_seen_ms = c->now_ms;
    ev   = derive_event(c, primary);
    next = fsm_next_state(c->state, ev);
    if (next != c->state) {
        bool fault_event = (ev == EV_WARN_FAULT || ev == EV_CRIT_FAULT || ev == EV_FATAL_FAULT);
        log_transition(c, (uint8_t)c->state, (uint8_t)next, (uint8_t)ev, fault_event ? primary : -1);
        enter_state(c, next);
    }

    /* 4. Outputs: relay command is a pure function of state (+ test step) */
    switch (c->state) {
    case ST_NORMAL:
    case ST_DEGRADED: cmd = true;  break;
    case ST_FAILSAFE: cmd = (c->rstep == RS_RELAY_CLOSE); break;
    default:          cmd = false; break;
    }
    if (cmd != c->relay_cmd) {
        c->relay_cmd = cmd;
        c->relay_cmd_change_ms = c->now_ms;
    }

    if (out) {
        out->relay_on = c->relay_cmd;
        out->state    = c->state;
        out->rstep    = c->rstep;
    }
}

/* ------------------------------------------------------------------------ */
/* JSON Lines formatting                                                    */
/* ------------------------------------------------------------------------ */
static void fault_strings(int idx, const char **name, const char **src, const char **sev)
{
    if (idx >= 0 && idx < (int)FLT_COUNT) {
        *name = fsm_fault_defs[idx].name;
        *src  = fsm_source_name(fsm_fault_defs[idx].source);
        *sev  = fsm_sev_name(fsm_fault_defs[idx].severity);
    } else {
        *name = "NONE"; *src = "NONE"; *sev = "NONE";
    }
}

int fsm_format_log_json(const fsm_log_rec_t *r, char *buf, size_t n)
{
    const char *fname, *fsrc, *fsev;
    int idx = (r->fault_idx == 0xFFu) ? -1 : (int)r->fault_idx;
    fault_strings(idx, &fname, &fsrc, &fsev);

    if (r->kind == LOG_TRANSITION) {
        return snprintf(buf, n,
            "{\"type\":\"TRANSITION\",\"seq\":%lu,\"t_ms\":%lu,\"prev\":\"%s\",\"next\":\"%s\","
            "\"event\":\"%s\",\"fault_id\":\"0x%04X\",\"fault\":\"%s\",\"src\":\"%s\",\"sev\":\"%s\"}",
            (unsigned long)r->seq, (unsigned long)r->t_ms,
            fsm_state_name(r->prev), fsm_state_name(r->next), fsm_event_name(r->event),
            (unsigned)r->fault_id, fname, fsrc, fsev);
    }
    return snprintf(buf, n,
        "{\"type\":\"RECOVERY\",\"seq\":%lu,\"t_ms\":%lu,\"state\":\"%s\",\"step\":\"%s\","
        "\"result\":\"%s\",\"attempt\":%u,\"fault_id\":\"0x%04X\",\"fault\":\"%s\",\"src\":\"%s\",\"sev\":\"%s\"}",
        (unsigned long)r->seq, (unsigned long)r->t_ms,
        fsm_state_name(r->prev), fsm_step_name(r->step), fsm_result_name(r->result),
        (unsigned)r->attempt, (unsigned)r->fault_id, fname, fsrc, fsev);
}

int fsm_format_fault_json(const fsm_ctx_t *c, fault_idx_t idx, char *buf, size_t n)
{
    const fault_rec_t *r = &c->faults[idx];
    const fault_def_t *d = &fsm_fault_defs[idx];
    return snprintf(buf, n,
        "{\"type\":\"FAULT\",\"fault_id\":\"0x%04X\",\"fault\":\"%s\",\"src\":\"%s\",\"sev\":\"%s\","
        "\"active\":%s,\"latched\":%s,\"count\":%u,\"first_ms\":%lu,\"last_ms\":%lu}",
        (unsigned)fsm_fault_id(idx), d->name, fsm_source_name(d->source), fsm_sev_name(d->severity),
        r->active ? "true" : "false", r->latched ? "true" : "false",
        (unsigned)r->occurrences, (unsigned long)r->first_ms, (unsigned long)r->last_ms);
}

int fsm_format_status_json(const fsm_ctx_t *c, char *buf, size_t n)
{
    int p = fsm_primary_fault(c);
    const char *fname, *fsrc, *fsev;
    fault_strings(p, &fname, &fsrc, &fsev);
    return snprintf(buf, n,
        "{\"type\":\"STATUS\",\"t_ms\":%lu,\"state\":\"%s\",\"in_state_ms\":%lu,\"rstep\":\"%s\","
        "\"attempts\":%u,\"relay_cmd\":%s,\"cells_mv\":[%u,%u,%u,%u],"
        "\"primary_fault_id\":\"0x%04X\",\"primary_fault\":\"%s\",\"src\":\"%s\",\"sev\":\"%s\"}",
        (unsigned long)c->now_ms, fsm_state_name((uint8_t)c->state),
        (unsigned long)elapsed(c, c->state_enter_ms),
        (c->state == ST_FAILSAFE) ? fsm_step_name(c->rstep) : "-",
        (unsigned)c->attempts, c->relay_cmd ? "true" : "false",
        (unsigned)c->cell_mv[0], (unsigned)c->cell_mv[1], (unsigned)c->cell_mv[2], (unsigned)c->cell_mv[3],
        (unsigned)((p >= 0) ? fsm_fault_id((fault_idx_t)p) : 0u), fname, fsrc, fsev);
}
