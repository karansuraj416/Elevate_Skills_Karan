# Fault State Machine with Structured Recovery

A deterministic four-state fault manager (NORMAL / DEGRADED / FAILSAFE / SHUTDOWN) for a
4-cell battery pack with a relay output, ADC sensing and a supervisory comm link.
It isolates every fault to its source, keeps a fault memory for the whole run, logs every
transition as structured JSON, and leaves FAILSAFE only through a verification sequence.

**Simulator: [Wokwi](https://wokwi.com)** (free, runs in the browser, has an ESP32, relay
module, potentiometers, DIP switch and serial monitor — everything this project needs).
A PC test harness runs the *same* C core without any hardware.

```
fault-fsm/
├── firmware/                 <- the Wokwi project
│   ├── sketch.ino            ESP32 board layer: sampling, relay, LEDs, fault injection, serial
│   ├── fault_fsm.h           portable core: states, events, fault table, API
│   ├── fault_fsm.c           portable core: detection, transition table, recovery, logging
│   └── diagram.json          Wokwi circuit
└── host_sim/                 <- PC simulation + tests (gcc/make)
    ├── sim.c / sim.h         plant model: cells, ADC noise, relay physics, heartbeat
    ├── test_fsm.c            13 scenario tests + table proofs + determinism + 400-run fuzz
    ├── demo.c                scripted fault story printed as JSON Lines
    ├── arduino_stub/         lets the real sketch.ino compile and run on a PC
    └── Makefile
```

---

## 1. Run it in Wokwi (browser)

1. Open **wokwi.com → New Project → ESP32**.
2. Replace the content of `sketch.ino` with `firmware/sketch.ino`.
3. Open the `diagram.json` tab and replace it with `firmware/diagram.json`.
4. Use the tab-bar dropdown (▾) → **New file…** to add `fault_fsm.h` and `fault_fsm.c`, and
   paste their contents. *(If your Wokwi build complains about the `.c` file, name it
   `fault_fsm.cpp` instead — the header is C/C++ safe.)*
5. Press **▶ Start**. Watch the serial monitor and the four state LEDs.

**Controls**

| Part | Action | Fault created |
|---|---|---|
| Pots 1–4 | Cell voltage 2.50–4.50 V (mid = 3.50 V) | <3.10 V / >4.15 V warn, <2.90 V / >4.25 V critical, spread >250 mV warn |
| DIP 1 | Freeze ADC channel 1 | `0x0610 ADC1_FROZEN` → FAILSAFE |
| DIP 2 | Stop heartbeat | `0x0B30` after 0.5 s (DEGRADED), `0x0B31` after 2 s (FAILSAFE) |
| DIP 3 | Relay coil drive lost | `0x0A20 RELAY_STUCK_OPEN` → FAILSAFE |
| DIP 4 | Relay contact welded | `0x0A21 RELAY_STUCK_CLOSED` (FATAL) when the FSM tries to open it |
| DIP 5 | Shutdown request | `0x0C42` → SHUTDOWN |
| Green button (key **a**) | Operator ACK — starts recovery verification | |
| Pot at either end stop | Sensor shorted/open | `0x06..0x09 11 ADCn_RAIL` (not blamed on the cell) |

Click the DIP switch to select it, then keys **1–8** toggle switches.
Serial commands: `s` status · `f` faults seen · `F` all faults · `l` log dump · `r` ack · `p` periodic status on/off.

LEDs: green NORMAL · yellow DEGRADED · red FAILSAFE (blinks = waiting for ACK) · blue SHUTDOWN.

**Suggested demo:** wait ~7 s for NORMAL → turn pot 2 down a little (DEGRADED) and back →
flip DIP 1 (FAILSAFE, relay opens) → flip it back, wait for the red LED to blink, press ACK
(verification → DEGRADED → NORMAL) → flip DIP 4, then DIP 1 → SHUTDOWN (terminal).

> Polarity note: the sketch assumes the Wokwi relay energises with IN = HIGH
> (`RELAY_IN_ACTIVE_HIGH 1`). If the power-on self test immediately reports
> `RELAY_STUCK_OPEN`, set it to `0`.

## 2. Run it on a PC

```bash
cd host_sim
make test     # full test suite
make demo     # scripted fault story, JSON output
make sketch   # compiles the real sketch.ino against an Arduino stub and runs 40 s
```

---

## 3. Design

### States and transition table

One event is derived per 20 ms tick, looked up in a constant table → at most one transition per tick.

| current \ event | NONE | WARN_FAULT | CRIT_FAULT | FATAL_FAULT | PROBATION_OK | VERIFY_PASS |
|---|---|---|---|---|---|---|
| **NORMAL**   | NORMAL | DEGRADED | FAILSAFE | SHUTDOWN | NORMAL | NORMAL |
| **DEGRADED** | DEGRADED | DEGRADED | FAILSAFE | SHUTDOWN | NORMAL | DEGRADED |
| **FAILSAFE** | FAILSAFE | FAILSAFE | FAILSAFE | SHUTDOWN | FAILSAFE | **DEGRADED** |
| **SHUTDOWN** | SHUTDOWN | SHUTDOWN | SHUTDOWN | SHUTDOWN | SHUTDOWN | SHUTDOWN |

```mermaid
stateDiagram-v2
    [*] --> FAILSAFE: power on (self test)
    NORMAL --> DEGRADED: WARN fault
    NORMAL --> FAILSAFE: CRIT fault
    DEGRADED --> FAILSAFE: CRIT fault
    DEGRADED --> NORMAL: 5 s fault-free probation
    FAILSAFE --> DEGRADED: verification passed
    NORMAL --> SHUTDOWN: FATAL
    DEGRADED --> SHUTDOWN: FATAL
    FAILSAFE --> SHUTDOWN: FATAL / attempts exhausted / flapping
    SHUTDOWN --> [*]
```

Event priority: FATAL > CRIT > VERIFY_PASS > WARN > PROBATION_OK > NONE.
Relay output is a pure function of state: ON in NORMAL/DEGRADED, OFF in FAILSAFE/SHUTDOWN
(except the commanded test pulse during verification).

### Fault isolation

Fault ID = `(source << 8) | type`. Sources: `CELL1–4 (01–04)`, `PACK (05)`, `ADC1–4 (06–09)`,
`RELAY (0A)`, `COMM (0B)`, `SYSTEM (0C)`. All 33 faults are declared once in an X-macro
table (`FSM_FAULT_LIST`) with severity and debounce counts.

- **Measurement vs cell:** a cell is only judged when its ADC channel is trusted. A railed
  channel (≤8 or ≥4087 counts) raises `ADCn_RAIL`, a frozen one `ADCn_FROZEN` — never a
  cell UV/OV fault. Cell faults are *held* (not cleared) while the channel is untrusted.
- **Frozen ADC:** 50 identical consecutive samples (1 s). Real ADCs always show LSB noise;
  Wokwi pots don't, so the sketch adds ±2 LSB dither (`SIM_ADC_DITHER`, set 0 on hardware).
- **Relay:** two feedback contacts (NO and NC). Exactly one must be closed, otherwise
  `RELAY_FB_IMPLAUSIBLE` (wiring) — and the relay itself is not blamed. Command/feedback
  mismatch is checked only after a 60 ms settle time: stuck-open is CRIT, stuck-closed is
  FATAL (the pack can no longer be isolated).
- **Comm:** heartbeat age >0.5 s WARN, >2 s CRIT.

Each fault keeps `active`, `latched`, occurrence count, first and last time for the whole run.
WARN faults self-clear with hysteresis; CRIT/FATAL stay latched until a verified recovery.

### FAILSAFE recovery (verification, not a jump back)

```
WAIT_CLEAR  no CRIT/FATAL active for 3 s (1 s at power-on)
WAIT_ACK    operator ACK (skipped once for the power-on self test)
ADC_CHECK   every channel alive (≥3 changes in 500 ms) and in range
RELAY_CLOSE command ON  → 3 consecutive "closed" feedback samples within 300 ms
RELAY_OPEN  command OFF → 3 consecutive "open"   feedback samples within 300 ms
COMM_CHECK  heartbeat fresh within 1 s
→ VERIFIED  release CRIT latches → DEGRADED (probation 5 s) → NORMAL
```
Any live CRIT/FATAL aborts the sequence. A failure latches `SYS_SELFTEST_FAIL`, records the
failing step and the isolated fault, and returns to WAIT_CLEAR (next try needs an ACK).

### Why it cannot deadlock or livelock

- Every state except SHUTDOWN has an exit in the table; SHUTDOWN is the only, intentional,
  terminal state (checked by BFS in the tests).
- Every verification step has a timeout.
- 3 failed verifications → `SYS_RECOVERY_EXHAUST` (FATAL) → SHUTDOWN.
- 5 FAILSAFE entries within 60 s (flapping) → SHUTDOWN.
- Fuzz test: 400 runs × 120 s of random fault injection, then the plant is healed and an
  operator acks every 4 s — every run ends in NORMAL or SHUTDOWN, none stuck.

### Determinism

Integer-only, no heap, no clock reads inside the core; time and all inputs are passed to
`fsm_step()`. Equal-severity faults are ordered by table index. The test suite replays the
same random 120 s fault campaign twice and compares a hash of the full log.

### Structured log

Every transition (and each recovery step) goes to a 64-entry ring buffer and is printed
immediately as one JSON line:

```json
{"type":"TRANSITION","seq":12,"t_ms":18020,"prev":"NORMAL","next":"FAILSAFE","event":"CRIT_FAULT","fault_id":"0x0610","fault":"ADC1_FROZEN","src":"ADC1","sev":"CRIT"}
{"type":"RECOVERY","seq":19,"t_ms":24220,"state":"FAILSAFE","step":"VERIFIED","result":"PASS","attempt":1,"fault_id":"0x0000","fault":"NONE","src":"NONE","sev":"NONE"}
{"type":"FAULT","fault_id":"0x0A21","fault":"RELAY_STUCK_CLOSED","src":"RELAY","sev":"FATAL","active":true,"latched":true,"count":1,"first_ms":32720,"last_ms":33620}
```

## 4. Test results

```
[PASS] transition table properties
[PASS] power-on self test -> DEGRADED -> NORMAL
[PASS] cell warning -> DEGRADED -> NORMAL
[PASS] over-voltage -> FAILSAFE -> verified recovery
[PASS] frozen ADC isolated from cell faults
[PASS] ADC rail not blamed on cell
[PASS] relay stuck-open exhausts recovery
[PASS] welded relay -> terminal SHUTDOWN
[PASS] comm loss: DEGRADED then FAILSAFE
[PASS] relay feedback implausible
[PASS] operator shutdown request
[PASS] fault flapping escalates to SHUTDOWN
[PASS] failed POST waits for operator ack
[PASS] determinism (same inputs -> same log)
    400 runs x 120 s: 230 ended NORMAL, 170 SHUTDOWN, 0 stuck; 3004 transitions checked
[PASS] fuzz: invariants + no deadlock

653 checks, 0 failed
```

All tunables (thresholds, timings, attempt limits) are `#define`s at the top of `fault_fsm.h`.
