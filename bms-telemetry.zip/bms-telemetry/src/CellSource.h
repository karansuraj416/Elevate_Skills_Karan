// CellSource.h — where cell voltages come from: simulated pack or ADC taps.
#pragma once

#include "DemoSupport.h"
#include "TelemetryTypes.h"

class ICellSource {
 public:
  virtual ~ICellSource() = default;
  virtual void        begin() = 0;
  virtual void        read(uint32_t nowMs, tel::CellSnapshot& out) = 0;
  virtual const char* name() const = 0;
};

class SimCellSource : public ICellSource {
 public:
  explicit SimCellSource(uint8_t cells) : pack_(cells) {}
  void begin() override {}
  void read(uint32_t nowMs, tel::CellSnapshot& out) override { pack_.sample(nowMs, out); }
  const char* name() const override { return "SIMULATED"; }

 private:
  tel::SimulatedPack pack_;
};

// Stacked-tap measurement: tap k sees cells 1..k, so
//   cell_k = tap_k - tap_(k-1).
// Fine for a demo / lab bench. For a production pack use a dedicated BMS
// front-end IC (e.g. BQ769x0, LTC681x) - divider errors accumulate up the
// stack and the dividers slowly drain the lower cells.
class AdcCellSource : public ICellSource {
 public:
  explicit AdcCellSource(uint8_t cells) : cells_(cells) {}
  void begin() override;
  void read(uint32_t nowMs, tel::CellSnapshot& out) override;
  const char* name() const override { return "ADC_TAPS"; }

 private:
  uint32_t readTapMv(uint8_t idx);
  uint8_t cells_;
};
