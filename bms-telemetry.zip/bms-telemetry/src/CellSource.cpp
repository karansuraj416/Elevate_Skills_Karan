#include "CellSource.h"

#include <Arduino.h>

#include "config.h"

static const uint8_t kTapPins[] = TAP_PINS;
static const float   kRatios[] = TAP_DIVIDER_RATIOS;
static const float   kCal[] = TAP_CALIBRATION;

static_assert(sizeof(kTapPins) / sizeof(kTapPins[0]) >= CELL_COUNT, "TAP_PINS needs CELL_COUNT entries");
static_assert(sizeof(kRatios) / sizeof(kRatios[0]) >= CELL_COUNT, "TAP_DIVIDER_RATIOS needs CELL_COUNT entries");
static_assert(sizeof(kCal) / sizeof(kCal[0]) >= CELL_COUNT, "TAP_CALIBRATION needs CELL_COUNT entries");

void AdcCellSource::begin() {
  analogReadResolution(12);
  for (uint8_t i = 0; i < cells_; ++i) {
    pinMode(kTapPins[i], INPUT);
    analogSetPinAttenuation(kTapPins[i], ADC_11db);  // ~0.15 - 2.45 V usable range
  }
}

uint32_t AdcCellSource::readTapMv(uint8_t idx) {
  // analogReadMilliVolts() applies the factory eFuse calibration.
  uint32_t acc = 0;
  for (uint8_t k = 0; k < ADC_OVERSAMPLE; ++k) acc += analogReadMilliVolts(kTapPins[idx]);
  const float pinMv = (float)acc / ADC_OVERSAMPLE;
  return (uint32_t)(pinMv * kRatios[idx] * kCal[idx] + 0.5f);
}

void AdcCellSource::read(uint32_t nowMs, tel::CellSnapshot& out) {
  out.tMs = nowMs;
  out.count = cells_;
  uint32_t prev = 0;
  for (uint8_t i = 0; i < tel::kMaxCells; ++i) {
    if (i >= cells_) { out.mv[i] = 0; continue; }
    const uint32_t tap = readTapMv(i);
    const int32_t cell = (int32_t)tap - (int32_t)prev;
    out.mv[i] = (uint16_t)(cell < 0 ? 0 : (cell > 65535 ? 65535 : cell));
    prev = tap;
  }
}
