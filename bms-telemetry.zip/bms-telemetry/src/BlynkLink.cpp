// BlynkLink.cpp — Wi-Fi / Blynk driver and dashboard publisher.
#include "secrets.h"   // BLYNK_TEMPLATE_ID etc. must come before BlynkSimpleEsp32.h
#include "config.h"

#define BLYNK_PRINT Serial
#define BLYNK_NO_BUILTIN        // we own every GPIO
#define BLYNK_NO_FANCY_LOGO

#include <WiFi.h>
#include <BlynkSimpleEsp32.h>
#include <sys/time.h>
#include <time.h>

#include "BlynkLink.h"
#include "pins.h"

using namespace tel;

extern BlynkLink g_link;  // defined in main.cpp

// ============================================================== value cache
// Live values are not written immediately: they update this cache and the
// pump sends only values that changed, a few per pass, in priority order.
namespace {

uint32_t g_msgs = 0;  // messages sent to Blynk since boot (quota check)

template <typename... A> void vw(int pin, A... a) { Blynk.virtualWrite(pin, a...); ++g_msgs; }
template <typename... A> void le(A... a) { Blynk.logEvent(a...); ++g_msgs; }

constexpr int kMaxPins = 32;
constexpr int kStrLen = 120;

struct Slot {
  bool  used = false;
  bool  dirty = false;
  bool  isStr = false;
  float num = 0;
  uint8_t decimals = 0;
  char  str[kStrLen] = {0};
};
Slot g_slots[kMaxPins];

void setNum(int pin, float v, uint8_t decimals) {
  if (pin < 0 || pin >= kMaxPins) return;
  Slot& s = g_slots[pin];
  if (s.used && !s.isStr && s.num == v) return;
  s.used = true; s.isStr = false; s.num = v; s.decimals = decimals; s.dirty = true;
}

void setStr(int pin, const char* v) {
  if (pin < 0 || pin >= kMaxPins) return;
  Slot& s = g_slots[pin];
  if (s.used && s.isStr && strncmp(s.str, v, kStrLen) == 0) return;
  s.used = true; s.isStr = true; strncpy(s.str, v, kStrLen - 1); s.dirty = true;
}

// Pending log lines (each one must be delivered, not just the last).
constexpr int kLogDepth = 8;
char g_log[kLogDepth][kStrLen];
int  g_logHead = 0, g_logCount = 0;

void queueLog(const char* line) {
  if (g_logCount == kLogDepth) {           // keep the newest lines
    g_logHead = (g_logHead + 1) % kLogDepth;
    --g_logCount;
  }
  strncpy(g_log[(g_logHead + g_logCount) % kLogDepth], line, kStrLen - 1);
  g_log[(g_logHead + g_logCount) % kLogDepth][kStrLen - 1] = '\0';
  ++g_logCount;
}

// Most important first.
#if DASHBOARD_PROFILE == DASHBOARD_FULL
const int kPriority[] = {VP_RELAY, VP_FAULT_CODE, VP_FAULT_TEXT, VP_DATA_MODE, VP_QUEUE_DEPTH,
                         VP_WEAK_V, VP_WEAK_IDX, VP_STRONG_V, VP_STRONG_IDX, VP_DELTA_MV,
                         VP_PACK_V, VP_CELL_BASE + 0, VP_CELL_BASE + 1, VP_CELL_BASE + 2,
                         VP_CELL_BASE + 3, VP_CELL_BASE + 4, VP_CELL_BASE + 5, VP_CELL_BASE + 6,
                         VP_CELL_BASE + 7, VP_LIVE_SEQ, VP_RSSI, VP_LINK_PCT, VP_LINK_TEXT,
                         VP_QUEUE_DROPPED, VP_DISCONNECTS, VP_LAST_OUTAGE_S, VP_UPTIME_MIN};
#else
const int kPriority[] = {VP_RELAY, VP_FAULT_CODE, VP_STATUS_TEXT, VP_QUEUE_DEPTH, VP_WEAK_V,
                         VP_STRONG_V, VP_CELLS_TEXT, VP_RSSI};
#endif

void writeSlot(int pin) {
  Slot& s = g_slots[pin];
  if (s.isStr) vw(pin, s.str);
  else if (s.decimals == 0) vw(pin, (long)s.num);
  else {
    char b[16];
    dtostrf(s.num, 0, s.decimals, b);
    vw(pin, b);
  }
  s.dirty = false;
}

void fmtClock(uint32_t uptimeMs, bool timeOk, uint64_t epochMs, char* out, size_t len) {
  if (timeOk) {
    time_t t = (time_t)(epochMs / 1000ULL);
    struct tm tmv;
    localtime_r(&t, &tmv);
    strftime(out, len, "%H:%M:%S", &tmv);
  } else {
    snprintf(out, len, "t+%lu.%lus", (unsigned long)(uptimeMs / 1000),
             (unsigned long)((uptimeMs % 1000) / 100));
  }
}

// Describe an event in one line.
void describe(const TelemetryEvent& e, char* out, size_t len) {
  char faults[24];
  faultsToString(e.faults, faults, sizeof faults);
  const CellStats st = statsOf(e);
  switch (e.type) {
    case EventType::FaultSet:
    case EventType::FaultClear: {
      char changed[24];
      faultsToString((uint16_t)e.arg, changed, sizeof changed);
      if (e.type == EventType::FaultSet && e.faultCell)
        snprintf(out, len, "%s %s cell %u, relay %s", eventName(e.type), changed, e.faultCell,
                 e.relayClosed ? "CLOSED" : "OPEN");
      else
        snprintf(out, len, "%s %s, now %s, relay %s", eventName(e.type), changed, faults,
                 e.relayClosed ? "CLOSED" : "OPEN");
      break;
    }
    case EventType::RelayChange:
      snprintf(out, len, "RELAY %s (%s)", e.arg ? "CLOSED" : "OPEN", faults);
      break;
    case EventType::LinkRestored:
      snprintf(out, len, "LINK_RESTORED after %lu s", (unsigned long)(e.arg / 1000));
      break;
    case EventType::LinkQuality:
      snprintf(out, len, "LINK_QUALITY %s (%d dBm)", linkQualityName((LinkQuality)e.arg), e.rssi);
      break;
    case EventType::QueueOverflow:
      snprintf(out, len, "QUEUE_OVERFLOW %ld events lost", (long)e.arg);
      break;
    default:
      snprintf(out, len, "%s W:C%u %.3f S:C%u %.3f d=%umV", eventName(e.type), st.minIdx + 1,
               st.minMv / 1000.0, st.maxIdx + 1, st.maxMv / 1000.0, st.deltaMv);
  }
}

}  // namespace

// ============================================================ INetDriver
void BlynkLink::begin(IControlHandler* handler) {
  handler_ = handler;
  WiFi.mode(WIFI_STA);
  WiFi.setAutoReconnect(false);   // the WifiStateMachine owns reconnection
  WiFi.persistent(false);
  WiFi.setSleep(false);           // lower latency for the dashboard
  Blynk.config(BLYNK_AUTH_TOKEN); // no network activity yet
  Blynk.disconnect();             // stay idle until the state machine says go
  configured_ = true;
}

void BlynkLink::wifiBegin() {
  WiFi.disconnect(false, false);
  WiFi.begin(WIFI_SSID, WIFI_PASS);  // returns immediately
}

bool BlynkLink::wifiConnected() { return WiFi.status() == WL_CONNECTED; }

void BlynkLink::wifiDisconnect() { WiFi.disconnect(false, false); }

void BlynkLink::cloudBegin() {
  if (!ntpStarted_) {               // SNTP runs in the background (lwIP)
    configTzTime(TZ_INFO, NTP_SERVER_1, NTP_SERVER_2);
    ntpStarted_ = true;
  }
  Blynk.connect(0);                 // timeout 0: only arms the login, never waits
}

bool BlynkLink::cloudConnected() { return Blynk.connected(); }

// Note: the TCP connect inside the first Blynk.run() of a login attempt is a
// socket call that can take up to the WiFiClient connect timeout (~3 s).
// This only delays the network loop; protection and event detection run in
// their own tasks and events wait in the hand-off queue with their original
// timestamps.
void BlynkLink::cloudService() { Blynk.run(); }

void BlynkLink::cloudDisconnect() { Blynk.disconnect(); }

int BlynkLink::rssi() { return WiFi.RSSI(); }

// ============================================================ IPublisher
bool BlynkLink::canPublish() { return Blynk.connected(); }

bool BlynkLink::timeValid() const {
  struct timeval tv;
  gettimeofday(&tv, nullptr);
  return tv.tv_sec > 1700000000;    // after Nov 2023 -> SNTP has synced
}

uint64_t BlynkLink::epochMsFor(uint32_t uptimeMs) const {
  struct timeval tv;
  gettimeofday(&tv, nullptr);
  const uint64_t nowEpoch = (uint64_t)tv.tv_sec * 1000ULL + tv.tv_usec / 1000;
  return nowEpoch - (uint64_t)(millis() - uptimeMs);
}

void BlynkLink::setLive(const TelemetryEvent& e) {
  const CellStats st = statsOf(e);
  char faults[24];
  faultsToString(e.faults, faults, sizeof faults);
  relayClosed_ = e.relayClosed;
#if DASHBOARD_PROFILE == DASHBOARD_FULL
  for (uint8_t i = 0; i < e.cellCount; ++i) setNum(VP_CELL_BASE + i, e.mv[i] / 1000.0f, 3);
  setNum(VP_WEAK_V, st.minMv / 1000.0f, 3);
  setNum(VP_WEAK_IDX, st.minIdx + 1, 0);
  setNum(VP_STRONG_V, st.maxMv / 1000.0f, 3);
  setNum(VP_STRONG_IDX, st.maxIdx + 1, 0);
  setNum(VP_DELTA_MV, st.deltaMv, 0);
  setNum(VP_PACK_V, st.packMv / 1000.0f, 2);
  setNum(VP_RELAY, e.relayClosed ? 1 : 0, 0);
  setNum(VP_FAULT_CODE, e.faults, 0);
  char ft[64];
  if (e.faults) snprintf(ft, sizeof ft, "%s (cell %u)", faults, e.faultCell);
  else snprintf(ft, sizeof ft, e.relayClosed ? "OK" : "OK - relay open (reset needed)");
  setStr(VP_FAULT_TEXT, ft);
  if (e.seq) setNum(VP_LIVE_SEQ, (float)e.seq, 0);  // snapshots carry seq 0
#else
  char cells[kStrLen];
  int used = 0;
  for (uint8_t i = 0; i < e.cellCount && used < kStrLen; ++i)
    used += snprintf(cells + used, kStrLen - used, "%sC%u %.3f", i ? " | " : "", i + 1, e.mv[i] / 1000.0);
  snprintf(cells + used, kStrLen - used, " | W:C%u S:C%u d=%umV", st.minIdx + 1, st.maxIdx + 1, st.deltaMv);
  setStr(VP_CELLS_TEXT, cells);
  setNum(VP_WEAK_V, st.minMv / 1000.0f, 3);
  setNum(VP_STRONG_V, st.maxMv / 1000.0f, 3);
  setNum(VP_RELAY, e.relayClosed ? 1 : 0, 0);
  setNum(VP_FAULT_CODE, e.faults, 0);
#endif
  snprintf(faultShort_, sizeof faultShort_, "%s", faults);
}

bool BlynkLink::publishLive(const TelemetryEvent& e) {
  if (!Blynk.connected()) return false;
  setLive(e);
  if (priorityOf(e.type) == Priority::Critical) {
    char what[90], clock[16], line[kStrLen];
    describe(e, what, sizeof what);
    fmtClock(e.tMs, timeValid(), epochMsFor(e.tMs), clock, sizeof clock);
    snprintf(line, sizeof line, "LIVE   #%lu %s %s", (unsigned long)e.seq, clock, what);
    queueLog(line);
#if ENABLE_BLYNK_EVENTS
    if (e.type == EventType::FaultSet) le("bms_fault", what);
    if (e.type == EventType::LinkRestored) le("link_restored", what);
#endif
  }
  if (priorityOf(e.type) == Priority::Critical) pump(millis(), true);  // out right away
  return true;
}

bool BlynkLink::publishReplay(const TelemetryEvent& e, uint32_t ageMs, size_t remaining) {
  if (!Blynk.connected()) return false;
  const bool tOk = timeValid();
  const uint64_t ts = epochMsFor(e.tMs);

#if DASHBOARD_PROFILE == DASHBOARD_FULL
  const CellStats st = statsOf(e);
  // Back-fill the replay charts at the time the event really happened.
  if (tOk) Blynk.beginGroup(ts);
  else Blynk.beginGroup();
  char b[16];
  vw(VP_RP_WEAK_V, dtostrf(st.minMv / 1000.0, 0, 3, b));
  vw(VP_RP_STRONG_V, dtostrf(st.maxMv / 1000.0, 0, 3, b));
  vw(VP_RP_FAULT_CODE, (int)e.faults);
  vw(VP_RP_RELAY, e.relayClosed ? 1 : 0);
  Blynk.endGroup();
#endif

  char what[90], clock[16], line[kStrLen];
  describe(e, what, sizeof what);
  fmtClock(e.tMs, tOk, ts, clock, sizeof clock);
  snprintf(line, sizeof line, "REPLAY #%lu %s (-%lus) %s [%u left]", (unsigned long)e.seq, clock,
           (unsigned long)(ageMs / 1000), what, (unsigned)remaining);
  queueLog(line);

#if ENABLE_BLYNK_EVENTS
  if (e.type == EventType::FaultSet) {
    char d[110];
    snprintf(d, sizeof d, "[queued, %lus ago] %s", (unsigned long)(ageMs / 1000), what);
    le("bms_fault", d);
  }
#endif
  setNum(VP_QUEUE_DEPTH, (float)remaining, 0);
#if DASHBOARD_PROFILE == DASHBOARD_FULL
  setNum(VP_DATA_MODE, remaining ? 1 : 0, 0);
#endif
  return Blynk.connected();
}

void BlynkLink::publishSnapshot(const TelemetryEvent& current) {
  if (Blynk.connected()) setLive(current);
}

void BlynkLink::publishStatus(const DashboardStatus& s) {
  char lq[32];
  if (s.rssiValid) snprintf(lq, sizeof lq, "%s %d dBm", linkQualityName(s.quality), s.rssi);
  else snprintf(lq, sizeof lq, "UNKNOWN");
#if DASHBOARD_PROFILE == DASHBOARD_FULL
  setNum(VP_DATA_MODE, s.mode == DataMode::Replaying ? 1 : 0, 0);
  setNum(VP_QUEUE_DEPTH, (float)s.queueDepth, 0);
  setNum(VP_QUEUE_DROPPED, (float)s.dropped, 0);
  setNum(VP_DISCONNECTS, (float)s.disconnects, 0);
  setNum(VP_LAST_OUTAGE_S, (float)(s.lastOutageMs / 1000), 0);
  setNum(VP_UPTIME_MIN, (float)(s.uptimeS / 60), 0);  // minute resolution = 1 msg/min
  if (s.rssiValid) {
    // Don't spend messages on 1-2 dB jitter: RSSI, % and text move together.
    const Slot& cur = g_slots[VP_RSSI];
    if (!cur.used || fabsf(cur.num - s.rssi) >= RSSI_PUBLISH_STEP_DB || s.quality != lastQuality_) {
      setNum(VP_RSSI, s.rssi, 0);
      setNum(VP_LINK_PCT, s.linkPercent, 0);
      setStr(VP_LINK_TEXT, lq);
      lastQuality_ = s.quality;
    }
  } else {
    setStr(VP_LINK_TEXT, lq);
  }
#else
  char st[kStrLen];
  snprintf(st, sizeof st, "%s | Q %u/%u%s | %s | out %lu | %s",
           s.mode == DataMode::Replaying ? "REPLAYING" : "LIVE", (unsigned)s.queueDepth,
           (unsigned)s.queueCapacity, s.dropped ? " (lost!)" : "", lq,
           (unsigned long)s.disconnects, faultShort_);
  setStr(VP_STATUS_TEXT, st);
  setNum(VP_QUEUE_DEPTH, (float)s.queueDepth, 0);
  if (s.rssiValid) {
    const Slot& cur = g_slots[VP_RSSI];
    if (!cur.used || fabsf(cur.num - s.rssi) >= RSSI_PUBLISH_STEP_DB) setNum(VP_RSSI, s.rssi, 0);
  }
#endif
  lastMode_ = s.mode;
}

void BlynkLink::pump(uint32_t nowMs, bool force) {
  if (!Blynk.connected()) return;
  if (!force && nowMs - lastPumpMs_ < PUMP_PERIOD_MS) return;
  lastPumpMs_ = nowMs;
  int budget = WRITES_PER_PUMP;
  // Relay + fault first, then pending log lines, then everything else.
  static const int kFirst[] = {VP_RELAY, VP_FAULT_CODE};
  for (int pin : kFirst) {
    if (budget && g_slots[pin].dirty) { writeSlot(pin); --budget; }
  }
  while (budget && g_logCount) {
    vw(VP_LOG, g_log[g_logHead]);
    g_logHead = (g_logHead + 1) % kLogDepth;
    --g_logCount;
    --budget;
  }
  for (int pin : kPriority) {
    if (!budget) break;
    if (g_slots[pin].dirty) { writeSlot(pin); --budget; }
  }
}

void BlynkLink::logLine(const char* text) { queueLog(text); }

uint32_t BlynkLink::messagesSent() const { return g_msgs; }

void BlynkLink::invalidateAll() {
  for (auto& s : g_slots)
    if (s.used) s.dirty = true;
}

// ============================================================ controls
void BlynkLink::handleWrite(int pin, int value) {
  if (!handler_) return;
#if DASHBOARD_PROFILE == DASHBOARD_FULL
  switch (pin) {
    case VP_CTL_CELL:
      selectedCell_ = (uint8_t)constrain(value, 1, CELL_COUNT);
      break;
    case VP_CTL_INJECT:
      if (value <= 0) handler_->onClearInjection();
      else handler_->onInject((InjectKind)constrain(value, 1, 4), selectedCell_);
      break;
    case VP_CTL_RESET:
      if (value) handler_->onOperatorReset("dashboard");
      break;
    case VP_CTL_OUTAGE:
      if (value) handler_->onNetOutage(OUTAGE_DEMO_MS);
      break;
    case VP_CTL_SCENARIO:
      handler_->onScenario((ScenarioId)constrain(value, 0, 3));
      break;
  }
#else
  if (pin != VP_CTL_COMMAND) return;
  const uint8_t last = CELL_COUNT;
  switch (value) {
    case 1: handler_->onInject(InjectKind::OverVolt, 2 <= last ? 2 : 1); break;
    case 2: handler_->onInject(InjectKind::UnderVolt, 1); break;
    case 3: handler_->onInject(InjectKind::Imbalance, 3 <= last ? 3 : 1); break;
    case 4: handler_->onInject(InjectKind::OpenWire, last); break;
    case 5: handler_->onClearInjection(); break;
    case 6: handler_->onOperatorReset("dashboard"); break;
    case 7: handler_->onNetOutage(OUTAGE_DEMO_MS); break;
    case 8: handler_->onScenario(ScenarioId::Fault); break;
    case 9: handler_->onScenario(ScenarioId::Outage); break;
    case 10: handler_->onScenario(ScenarioId::Full); break;
    case 11: handler_->onScenario(ScenarioId::None); break;
    default: break;
  }
  if (value) vw(VP_CTL_COMMAND, 0);  // menu back to "Choose..."
#endif
}

// ============================================================ Blynk hooks
BLYNK_CONNECTED() {
  g_link.invalidateAll();  // dashboard may have missed anything; re-send state
  // Deliberately NO Blynk.syncVirtual() for controls: a stale "inject" or
  // "outage" value must never re-apply itself after a reboot/reconnect.
#if DASHBOARD_PROFILE == DASHBOARD_FULL
  vw(VP_CTL_RESET, 0);
  vw(VP_CTL_OUTAGE, 0);
#endif
}

#if DASHBOARD_PROFILE == DASHBOARD_FULL
BLYNK_WRITE(VP_CTL_INJECT)   { g_link.handleWrite(VP_CTL_INJECT, param.asInt()); }
BLYNK_WRITE(VP_CTL_CELL)     { g_link.handleWrite(VP_CTL_CELL, param.asInt()); }
BLYNK_WRITE(VP_CTL_RESET)    { g_link.handleWrite(VP_CTL_RESET, param.asInt()); }
BLYNK_WRITE(VP_CTL_OUTAGE)   { g_link.handleWrite(VP_CTL_OUTAGE, param.asInt()); }
BLYNK_WRITE(VP_CTL_SCENARIO) { g_link.handleWrite(VP_CTL_SCENARIO, param.asInt()); }
#else
BLYNK_WRITE(VP_CTL_COMMAND)  { g_link.handleWrite(VP_CTL_COMMAND, param.asInt()); }
#endif
