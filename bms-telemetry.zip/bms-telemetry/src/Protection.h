// Protection.h — the safety loop: sample cells, evaluate faults, drive the
// relay. Runs as its own FreeRTOS task at a higher priority than the
// network/telemetry loop, so a slow Wi-Fi or cloud call can never delay a
// trip. The telemetry side only reads a copy of the latest state.
#pragma once

#include "CellSource.h"
#include "DemoSupport.h"
#include "FaultManager.h"

struct ProtectionState {
  tel::CellSnapshot cells;      // after fault injection (what protection sees)
  uint16_t faults = 0;          // active
  uint16_t latched = 0;         // seen since last operator reset
  uint8_t  faultCell = 0;
  bool     relayClosed = false;
  bool     startupOk = false;
  tel::Injection injection;
  uint32_t samples = 0;
  uint32_t worstLoopUs = 0;     // longest protection iteration seen
};

namespace protection {

void begin(ICellSource& source, const tel::FaultConfig& cfg);
ProtectionState snapshot();                 // thread-safe copy
void setInjection(const tel::Injection& inj);
bool requestReset();                        // false if a fault is still active

}  // namespace protection
