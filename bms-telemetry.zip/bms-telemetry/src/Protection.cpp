#include "Protection.h"

#include <Arduino.h>

#include "config.h"

namespace {

ICellSource*       g_source = nullptr;
tel::FaultManager* g_faults = nullptr;
ProtectionState    g_state;
tel::Injection     g_injection;
portMUX_TYPE       g_mux = portMUX_INITIALIZER_UNLOCKED;

inline void writeRelay(bool closed) {
  const bool high = RELAY_ACTIVE_HIGH ? closed : !closed;
  digitalWrite(RELAY_PIN, high ? HIGH : LOW);
}

void protectionTask(void*) {
  TickType_t wake = xTaskGetTickCount();
  for (;;) {
    const uint32_t t0 = micros();
    tel::CellSnapshot s;
    g_source->read(millis(), s);           // ADC work happens outside the lock

    portENTER_CRITICAL(&g_mux);
    tel::applyInjection(s, g_injection);
    g_faults->update(s);
    const bool closed = g_faults->relayClosed();
    g_state.cells = s;
    g_state.faults = g_faults->active();
    g_state.latched = g_faults->latched();
    g_state.faultCell = g_faults->faultCell();
    g_state.relayClosed = closed;
    g_state.startupOk = g_faults->startupOk();
    g_state.injection = g_injection;
    g_state.samples++;
    portEXIT_CRITICAL(&g_mux);

    writeRelay(closed);

    const uint32_t dt = micros() - t0;
    if (dt > g_state.worstLoopUs) g_state.worstLoopUs = dt;
    vTaskDelayUntil(&wake, pdMS_TO_TICKS(PROTECTION_PERIOD_MS));
  }
}

}  // namespace

namespace protection {

void begin(ICellSource& source, const tel::FaultConfig& cfg) {
  pinMode(RELAY_PIN, OUTPUT);
  writeRelay(false);                       // safe state until self-check passes
  g_source = &source;
  g_source->begin();
  g_faults = new tel::FaultManager(cfg);
  // Core 1, priority 3: above the Arduino loop (priority 1) on the same core,
  // away from the Wi-Fi stack on core 0.
  xTaskCreatePinnedToCore(protectionTask, "protection", 4096, nullptr, 3, nullptr, 1);
}

ProtectionState snapshot() {
  portENTER_CRITICAL(&g_mux);
  ProtectionState copy = g_state;
  portEXIT_CRITICAL(&g_mux);
  return copy;
}

void setInjection(const tel::Injection& inj) {
  portENTER_CRITICAL(&g_mux);
  g_injection = inj;
  portEXIT_CRITICAL(&g_mux);
}

bool requestReset() {
  portENTER_CRITICAL(&g_mux);
  const bool ok = g_faults && g_faults->requestReset();
  if (ok) {
    g_state.latched = g_faults->latched();
    g_state.relayClosed = g_faults->relayClosed();
  }
  portEXIT_CRITICAL(&g_mux);
  return ok;  // relay pin follows on the next protection cycle (<= 100 ms)
}

}  // namespace protection
