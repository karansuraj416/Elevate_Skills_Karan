// BlynkLink.h — everything that touches Wi-Fi and Blynk.
//
// Implements:
//   tel::INetDriver  - low-level, non-blocking Wi-Fi/Blynk primitives used by
//                      the WifiStateMachine
//   tel::IPublisher  - how LIVE and REPLAYED events reach the dashboard
//
// Live values go to the "live" datastreams through a de-duplicating cache that
// is drained a couple of writes at a time (Blynk rate-limits writes, and each
// write can stall ~66 ms). Replayed events go to separate "replay"
// datastreams, stamped with the time they actually happened, so the operator
// never mistakes queued history for the current state.
//
// Only BlynkLink.cpp includes the Blynk headers (they define globals).
#pragma once

#include "DemoSupport.h"
#include "TelemetryManager.h"
#include "TelemetryTypes.h"
#include "WifiStateMachine.h"

struct DashboardStatus {
  tel::DataMode    mode = tel::DataMode::Offline;
  size_t           queueDepth = 0;
  size_t           queueCapacity = 0;
  uint32_t         dropped = 0;
  uint32_t         oldestAgeMs = 0;
  bool             rssiValid = false;
  int8_t           rssi = 0;
  uint8_t          linkPercent = 0;
  tel::LinkQuality quality = tel::LinkQuality::Unknown;
  uint32_t         disconnects = 0;
  uint32_t         lastOutageMs = 0;
  uint32_t         uptimeS = 0;
};

// Dashboard controls are forwarded to the application through this.
class IControlHandler {
 public:
  virtual ~IControlHandler() = default;
  virtual void onInject(tel::InjectKind k, uint8_t cell) = 0;
  virtual void onClearInjection() = 0;
  virtual void onOperatorReset(const char* source) = 0;
  virtual void onNetOutage(uint32_t durationMs) = 0;
  virtual void onScenario(tel::ScenarioId id) = 0;
};

class BlynkLink : public tel::INetDriver, public tel::IPublisher {
 public:
  void begin(IControlHandler* handler);

  // ---- tel::INetDriver ----
  void wifiBegin() override;
  bool wifiConnected() override;
  void wifiDisconnect() override;
  void cloudBegin() override;
  bool cloudConnected() override;
  void cloudService() override;
  void cloudDisconnect() override;
  int  rssi() override;

  // ---- tel::IPublisher ----
  bool canPublish() override;
  bool publishLive(const tel::TelemetryEvent& e) override;
  bool publishReplay(const tel::TelemetryEvent& e, uint32_t ageMs, size_t remaining) override;

  // Refresh every live value from the current state (after a backlog drains
  // or a reconnect) without creating a new event.
  void publishSnapshot(const tel::TelemetryEvent& current);
  void publishStatus(const DashboardStatus& s);
  void pump(uint32_t nowMs, bool force = false);  // drain a few dirty pins
  void logLine(const char* text);     // operator log (replay/log datastream)
  uint32_t messagesSent() const;      // Blynk messages since boot (plan quota)

  bool timeValid() const;
  void invalidateAll();               // re-send everything (after login)
  void handleWrite(int pin, int value);

 private:
  void setLive(const tel::TelemetryEvent& e);
  uint64_t epochMsFor(uint32_t uptimeMs) const;

  IControlHandler* handler_ = nullptr;
  bool     configured_ = false;
  bool     ntpStarted_ = false;
  uint8_t  selectedCell_ = 1;
  uint32_t lastPumpMs_ = 0;
  tel::DataMode lastMode_ = tel::DataMode::Offline;
  char     faultShort_[24] = "OK";
  bool     relayClosed_ = false;
  tel::LinkQuality lastQuality_ = tel::LinkQuality::Unknown;
};
