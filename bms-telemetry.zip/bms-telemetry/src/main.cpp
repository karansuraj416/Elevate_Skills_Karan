// main.cpp — Event-driven BMS telemetry node with offline queue and a live
// Blynk dashboard.
//
//  Task layout (ESP32, Arduino core):
//
//   protection task  (core 1, prio 3, 10 Hz)  cells -> faults -> relay
//          | shared state (spinlock)
//   detector task    (core 1, prio 2, 10 Hz)  state -> EventDetector -> g_eventQ
//          | FreeRTOS queue (events keep their original timestamp)
//   loop()           (core 1, prio 1)         WifiStateMachine, TelemetryManager
//                                             (live or offline queue + replay),
//                                             dashboard pump, console, demos
//
//  The network loop is the only place that can be slowed down by the radio,
//  and nothing safety-related or time-stamping depends on it.

#include <Arduino.h>

#include "BlynkLink.h"
#include "CellSource.h"
#include "DemoSupport.h"
#include "EventDetector.h"
#include "Protection.h"
#include "RssiMonitor.h"
#include "TelemetryManager.h"
#include "WifiStateMachine.h"
#include "config.h"

using namespace tel;

// ================================================================ globals
#if USE_SIMULATED_CELLS
static SimCellSource g_cells(CELL_COUNT);
#else
static AdcCellSource g_cells(CELL_COUNT);
#endif

BlynkLink g_link;  // BlynkLink.cpp's Blynk hooks reach it through this
static RssiMonitor g_rssi;
static WifiStateMachine* g_net = nullptr;
static TelemetryManager<QUEUE_CAPACITY>* g_tm = nullptr;
static EventDetector* g_detector = nullptr;
static QueueHandle_t g_eventQ = nullptr;

// Link info shared with the detector task.
static portMUX_TYPE g_linkMux = portMUX_INITIALIZER_UNLOCKED;
static int8_t       g_sharedRssi = 0;
static LinkQuality  g_sharedQuality = LinkQuality::Unknown;
static uint32_t     g_sharedThrottle = 0;
static volatile uint32_t g_handoffDrops = 0;

// Deferred requests from Blynk handlers (they run *inside* Blynk.run(), i.e.
// in the middle of a state-machine tick, so they must not touch it directly).
static volatile uint32_t g_pendingOutageMs = 0;
static volatile bool     g_pendingRestore = false;

// ============================================================== helpers
static TelemetryEvent eventFromState(EventType type, int32_t arg) {
  const ProtectionState ps = protection::snapshot();
  TelemetryEvent e;
  e.tMs = millis();
  e.type = type;
  e.cellCount = ps.cells.count;
  memcpy(e.mv, ps.cells.mv, sizeof(e.mv));
  e.faults = ps.faults;
  e.faultCell = ps.faultCell;
  e.relayClosed = ps.relayClosed;
  portENTER_CRITICAL(&g_linkMux);
  e.rssi = g_sharedRssi;
  portEXIT_CRITICAL(&g_linkMux);
  e.arg = arg;
  return e;
}

static void postEvent(const TelemetryEvent& e) {
  if (xQueueSend(g_eventQ, &e, 0) != pdTRUE) g_handoffDrops = g_handoffDrops + 1;
}

static void printEvent(const TelemetryEvent& e, const char* route) {
  char f[24];
  faultsToString(e.faults, f, sizeof f);
  const CellStats st = statsOf(e);
  Serial.printf("[%8lu] %-6s #%-4lu %-15s W:C%u %.3fV S:C%u %.3fV d=%3umV relay=%s faults=%s arg=%ld\n",
                (unsigned long)e.tMs, route, (unsigned long)e.seq, eventName(e.type),
                st.minIdx + 1, st.minMv / 1000.0, st.maxIdx + 1, st.maxMv / 1000.0, st.deltaMv,
                e.relayClosed ? "CLOSED" : "OPEN", f, (long)e.arg);
}

// ======================================================== detector task
static void detectorTask(void*) {
  TickType_t wake = xTaskGetTickCount();
  TelemetryEvent out[EventDetector::kMaxEventsPerEval];
  for (;;) {
    const ProtectionState ps = protection::snapshot();
    if (ps.samples > 0) {
      DetectorInput in;
      in.cells = ps.cells;
      in.faults = ps.faults;
      in.faultCell = ps.faultCell;
      in.relayClosed = ps.relayClosed;
      portENTER_CRITICAL(&g_linkMux);
      in.rssi = g_sharedRssi;
      in.link = g_sharedQuality;
      const uint32_t thr = g_sharedThrottle;
      portEXIT_CRITICAL(&g_linkMux);
      g_detector->setThrottle(thr);

      const size_t n = g_detector->evaluate(in, millis(), out, EventDetector::kMaxEventsPerEval);
      for (size_t i = 0; i < n; ++i) postEvent(out[i]);
    }
    vTaskDelayUntil(&wake, pdMS_TO_TICKS(DETECT_PERIOD_MS));
  }
}

// ======================================================= app / controls
class App : public IControlHandler, public IScenarioActions {
 public:
  // ---- IControlHandler (dashboard) + IScenarioActions (scripted demo) ----
  void onInject(InjectKind k, uint8_t cell) override {
    Injection inj;
    inj.kind = k;
    inj.cell = (uint8_t)constrain(cell, 1, CELL_COUNT);
    protection::setInjection(inj);
    Serial.printf(">> INJECT %s on cell %u\n", injectName(k), inj.cell);
  }
  void onClearInjection() override {
    protection::setInjection(Injection());
    Serial.println(">> injection cleared");
  }
  void onOperatorReset(const char* source) override {
    const bool ok = protection::requestReset();
    Serial.printf(">> operator reset from %s: %s\n", source, ok ? "accepted" : "REFUSED (fault still active)");
    if (ok) postEvent(eventFromState(EventType::OperatorReset, 0));
    else g_link.logLine("Operator reset refused: fault still active");
  }
  void onNetOutage(uint32_t durationMs) override {
    g_pendingOutageMs = durationMs ? durationMs : UINT32_MAX;  // 0 = until 'restore'
  }
  void onScenario(ScenarioId id) override;

  void scenarioLog(const char* text) override {
    Serial.printf("\n==== DEMO: %s ====\n", text);
    char line[100];
    snprintf(line, sizeof line, "DEMO: %s", text);
    // Only narrate on the dashboard while online; offline steps show up
    // there as the replayed events they caused, in the right order.
    if (g_net && g_net->online()) g_link.logLine(line);
  }
  void scenarioInject(InjectKind k, uint8_t cell) override { onInject(k, cell); }
  void scenarioClearInjection() override { onClearInjection(); }
  void scenarioOperatorReset() override { onOperatorReset("demo"); }
  void scenarioNetOutage(uint32_t d) override { onNetOutage(d); }
  void scenarioNetRestore() override { g_pendingRestore = true; }
};

static App g_app;
static ScenarioRunner g_demo(g_app);

void App::onScenario(ScenarioId id) {
  if (id == ScenarioId::None) {
    g_demo.stop();
    Serial.println(">> demo stopped");
    return;
  }
  g_demo.start(id, millis());
  Serial.printf(">> demo %s started\n", scenarioName(id));
}

// ============================================================== console
static void printStatus() {
  const ProtectionState ps = protection::snapshot();
  const uint32_t now = millis();
  const bool online = g_net->online();
  char f[24], l[24];
  faultsToString(ps.faults, f, sizeof f);
  faultsToString(ps.latched, l, sizeof l);
  const CellStats st = computeStats(ps.cells);
  Serial.println(F("------------------------------------------------------------"));
  Serial.printf("source=%s  cells:", g_cells.name());
  for (uint8_t i = 0; i < ps.cells.count; ++i) Serial.printf(" %.3f", ps.cells.mv[i] / 1000.0);
  Serial.printf("\nweakest C%u %.3f V | strongest C%u %.3f V | delta %u mV | pack %.2f V\n",
                st.minIdx + 1, st.minMv / 1000.0, st.maxIdx + 1, st.maxMv / 1000.0, st.deltaMv,
                st.packMv / 1000.0);
  Serial.printf("relay=%s  faults=%s  latched=%s  injection=%s@C%u  selfcheck=%s  worstLoop=%luus\n",
                ps.relayClosed ? "CLOSED" : "OPEN", f, l, injectName(ps.injection.kind),
                ps.injection.cell, ps.startupOk ? "OK" : "PENDING", (unsigned long)ps.worstLoopUs);
  Serial.printf("net=%s  mode=%s  rssi=%d dBm (%s, %u%%)  disconnects=%lu  lastOutage=%lus  offlineFor=%lus\n",
                netStateName(g_net->state()), dataModeName(g_tm->mode(online)), g_rssi.rssi(),
                linkQualityName(g_rssi.quality()), g_rssi.percent(),
                (unsigned long)g_net->disconnects(), (unsigned long)(g_net->lastOutageMs() / 1000),
                (unsigned long)(g_net->offlineForMs(now) / 1000));
  Serial.printf("blynk messages sent=%lu (%.0f/hour)\n", (unsigned long)g_link.messagesSent(),
                g_link.messagesSent() * 3600000.0 / (now ? now : 1));
  Serial.printf("queue %u/%u  oldest=%lus  dropped=%lu  live=%lu replayed=%lu queued=%lu  handoffDrops=%lu  heap=%u\n",
                (unsigned)g_tm->depth(), (unsigned)g_tm->capacity(),
                (unsigned long)(g_tm->oldestAgeMs(now) / 1000), (unsigned long)g_tm->dropped(),
                (unsigned long)g_tm->sentLive(), (unsigned long)g_tm->sentReplay(),
                (unsigned long)g_tm->queuedTotal(), (unsigned long)g_handoffDrops,
                (unsigned)ESP.getFreeHeap());
  if (g_demo.running()) Serial.printf("demo %s running\n", scenarioName(g_demo.current()));
  Serial.println(F("------------------------------------------------------------"));
}

static void printHelp() {
  Serial.println(F(
      "Commands:\n"
      "  status | s                 full status\n"
      "  inject ov|uv|imb|open <n>  inject a fault on cell n\n"
      "  clear                      remove injected fault\n"
      "  reset                      operator reset (acknowledge trip)\n"
      "  outage <sec>               drop Wi-Fi for <sec> seconds (0 = until 'restore')\n"
      "  restore                    end a forced outage now\n"
      "  demo fault|outage|full|stop\n"
      "  queue                      list queued (not yet sent) events"));
}

static void handleCommand(char* line) {
  char* cmd = strtok(line, " \t");
  if (!cmd) return;
  char* a1 = strtok(nullptr, " \t");
  char* a2 = strtok(nullptr, " \t");

  if (!strcmp(cmd, "help") || !strcmp(cmd, "?")) printHelp();
  else if (!strcmp(cmd, "status") || !strcmp(cmd, "s")) printStatus();
  else if (!strcmp(cmd, "inject") && a1) {
    InjectKind k = InjectKind::None;
    if (!strcmp(a1, "ov")) k = InjectKind::OverVolt;
    else if (!strcmp(a1, "uv")) k = InjectKind::UnderVolt;
    else if (!strcmp(a1, "imb")) k = InjectKind::Imbalance;
    else if (!strcmp(a1, "open")) k = InjectKind::OpenWire;
    if (k == InjectKind::None) { Serial.println("unknown fault type"); return; }
    g_app.onInject(k, a2 ? (uint8_t)atoi(a2) : 1);
  } else if (!strcmp(cmd, "clear")) g_app.onClearInjection();
  else if (!strcmp(cmd, "reset")) g_app.onOperatorReset("serial");
  else if (!strcmp(cmd, "outage")) {
    const uint32_t sec = a1 ? (uint32_t)atol(a1) : 60;
    g_pendingOutageMs = sec ? sec * 1000UL : UINT32_MAX;  // UINT32_MAX = indefinite
  } else if (!strcmp(cmd, "restore")) g_pendingRestore = true;
  else if (!strcmp(cmd, "demo") && a1) {
    if (!strcmp(a1, "fault")) g_app.onScenario(ScenarioId::Fault);
    else if (!strcmp(a1, "outage")) g_app.onScenario(ScenarioId::Outage);
    else if (!strcmp(a1, "full")) g_app.onScenario(ScenarioId::Full);
    else g_app.onScenario(ScenarioId::None);
  } else if (!strcmp(cmd, "queue")) {
    const auto& q = g_tm->queue();
    Serial.printf("%u queued event(s):\n", (unsigned)q.size());
    for (size_t i = 0; i < q.size(); ++i) printEvent(q.at(i), "QUEUED");
  } else {
    Serial.printf("unknown command '%s' (try 'help')\n", cmd);
  }
}

static void pollSerial() {
  static char buf[64];
  static size_t len = 0;
  while (Serial.available()) {
    const char c = (char)Serial.read();
    if (c == '\r') continue;
    if (c == '\n') {
      buf[len] = '\0';
      if (len) handleCommand(buf);
      len = 0;
    } else if (len < sizeof(buf) - 1) {
      buf[len++] = c;
    }
  }
}

static void pollResetButton(uint32_t now) {
  static uint32_t downSince = 0;
  static bool fired = false;
  if (digitalRead(RESET_BUTTON_PIN) == LOW) {
    if (!downSince) downSince = now ? now : 1;
    if (!fired && now - downSince >= RESET_HOLD_MS) {
      fired = true;
      g_app.onOperatorReset("button");
    }
  } else {
    downSince = 0;
    fired = false;
  }
}

// LED: solid = live, slow blink = replaying backlog, fast blink = offline,
// double flash = fault latched.
static void updateLed(uint32_t now, DataMode mode, uint16_t latched) {
  bool on;
  if (latched) on = (now % 1000) < 100 || ((now % 1000) > 200 && (now % 1000) < 300);
  else if (mode == DataMode::Live) on = true;
  else if (mode == DataMode::Replaying) on = (now / 500) % 2;
  else on = (now / 120) % 2;
  digitalWrite(STATUS_LED_PIN, on ? HIGH : LOW);
}

// ================================================================ setup
void setup() {
  Serial.begin(SERIAL_BAUD);
  delay(200);
  Serial.println(F("\n=== BMS event-driven telemetry node ==="));

  pinMode(STATUS_LED_PIN, OUTPUT);
  pinMode(RESET_BUTTON_PIN, INPUT_PULLUP);

  FaultConfig fc;
  fc.ovSetMv = OV_SET_MV;      fc.ovClearMv = OV_CLEAR_MV;
  fc.uvSetMv = UV_SET_MV;      fc.uvClearMv = UV_CLEAR_MV;
  fc.imbSetMv = IMB_SET_MV;    fc.imbClearMv = IMB_CLEAR_MV;
  fc.sensorMinMv = SENSOR_MIN_MV; fc.sensorMaxMv = SENSOR_MAX_MV;
  fc.debounceSamples = FAULT_DEBOUNCE;
  fc.latchRelay = FAULT_LATCH;
  protection::begin(g_cells, fc);  // relay held OPEN until self-check passes

  DetectorConfig dc;
  dc.cellDeadbandMv = CELL_DEADBAND_MV;
  dc.extremesHystMv = EXTREMES_HYST_MV;
  dc.minIntervalMs = MIN_EVENT_INTERVAL_MS;
  dc.heartbeatMs = HEARTBEAT_MS;
  g_detector = new EventDetector(dc);

  NetConfig nc;
  nc.wifiTimeoutMs = WIFI_TIMEOUT_MS;
  nc.cloudTimeoutMs = CLOUD_TIMEOUT_MS;
  nc.backoffMinMs = BACKOFF_MIN_MS;
  nc.backoffMaxMs = BACKOFF_MAX_MS;
  nc.rssiPeriodMs = RSSI_PERIOD_MS;
  g_link.begin(&g_app);
  g_net = new WifiStateMachine(g_link, g_rssi, nc);
  g_tm = new TelemetryManager<QUEUE_CAPACITY>(g_link, REPLAY_INTERVAL_MS);

  g_eventQ = xQueueCreate(32, sizeof(TelemetryEvent));
  xTaskCreatePinnedToCore(detectorTask, "detector", 4096, nullptr, 2, nullptr, 1);

  g_net->start(millis());
  Serial.printf("cells=%u source=%s queue=%u slots (%u bytes)  type 'help' for commands\n",
                CELL_COUNT, g_cells.name(), QUEUE_CAPACITY,
                (unsigned)(QUEUE_CAPACITY * sizeof(TelemetryEvent)));
}

// ================================================================= loop
void loop() {
  const uint32_t now = millis();

  // 1. Deferred network requests (from dashboard / console / demo).
  if (g_pendingOutageMs) {
    const uint32_t d = g_pendingOutageMs;
    g_pendingOutageMs = 0;
    g_net->forceOffline(now, d == UINT32_MAX ? 0 : d);
    Serial.printf(">> NETWORK OUTAGE %s\n", d == UINT32_MAX ? "until 'restore'" : "started");
    if (d != UINT32_MAX) Serial.printf("   duration %lu s\n", (unsigned long)(d / 1000));
  }
  if (g_pendingRestore) {
    g_pendingRestore = false;
    g_net->endForcedOffline(now);
  }

  // 2. Connection state machine (never waits).
  const NetState before = g_net->state();
  g_net->tick(now);
  const bool online = g_net->online();
  if (g_net->state() != before)
    Serial.printf("[%8lu] NET %s -> %s\n", (unsigned long)now, netStateName(before),
                  netStateName(g_net->state()));
  // Every time we (re)connect, the LIVE widgets immediately show the CURRENT
  // state. Anything that happened while offline goes to the replay pins.
  static bool wasOnline = false;
  if (online && !wasOnline) g_link.publishSnapshot(eventFromState(EventType::Heartbeat, 0));
  wasOnline = online;

  // 3. Share link quality with the detector.
  portENTER_CRITICAL(&g_linkMux);
  g_sharedRssi = g_rssi.rssi();
  g_sharedQuality = g_rssi.quality();
  g_sharedThrottle = g_rssi.suggestedThrottleMs();
  portEXIT_CRITICAL(&g_linkMux);

  // 4. Events from the detector -> live or offline queue (order preserved).
  TelemetryEvent e;
  while (xQueueReceive(g_eventQ, &e, 0) == pdTRUE) {
    const bool live = g_tm->submit(e, online, now);
    e.seq = g_tm->lastSeq();
    printEvent(e, live ? "LIVE" : "QUEUED");
  }

  // 5. Link came back -> record the outage as an event (joins the back of
  //    the queue, so it is delivered after everything that happened offline).
  uint32_t outageMs = 0;
  if (g_net->consumeRestored(outageMs)) {
    Serial.printf("[%8lu] link restored after %lu ms, %u queued event(s) to replay\n",
                  (unsigned long)now, (unsigned long)outageMs, (unsigned)g_tm->depth());
    TelemetryEvent r = eventFromState(EventType::LinkRestored, (int32_t)outageMs);
    g_tm->submit(r, online, now);
  }

  // 6. Replay backlog (one event per REPLAY_INTERVAL_MS).
  const size_t depthBefore = g_tm->depth();
  g_tm->service(online, now);
  if (g_tm->depth() < depthBefore)
    Serial.printf("[%8lu] REPLAY sent, %u left (age %lu ms)\n", (unsigned long)now,
                  (unsigned)g_tm->depth(), (unsigned long)g_tm->lastReplayAgeMs());
  if (g_tm->consumeDrained()) {
    Serial.printf("[%8lu] backlog delivered, back to LIVE\n", (unsigned long)now);
    g_link.logLine("Backlog delivered - dashboard is LIVE again");
    g_link.publishSnapshot(eventFromState(EventType::Heartbeat, 0));
  }

  // 7. Dashboard health values once per second (cache sends only changes).
  static uint32_t lastStatus = 0;
  if (online && now - lastStatus >= STATUS_PERIOD_MS) {
    lastStatus = now;
    DashboardStatus s;
    s.mode = g_tm->mode(online);
    s.queueDepth = g_tm->depth();
    s.queueCapacity = g_tm->capacity();
    s.dropped = g_tm->dropped();
    s.oldestAgeMs = g_tm->oldestAgeMs(now);
    s.rssiValid = g_rssi.hasData();
    s.rssi = g_rssi.rssi();
    s.linkPercent = g_rssi.percent();
    s.quality = g_rssi.quality();
    s.disconnects = g_net->disconnects();
    s.lastOutageMs = g_net->lastOutageMs();
    s.uptimeS = now / 1000;
    g_link.publishStatus(s);
  }
  g_link.pump(now);

  // 8. Local I/O and demo script.
  g_demo.tick(now);
  pollSerial();
  pollResetButton(now);
  updateLed(now, g_tm->mode(online), protection::snapshot().latched);

  // Periodic status print while a demo or outage is in progress.
  static uint32_t lastPrint = 0;
  if ((g_demo.running() || !online) && now - lastPrint >= 10000) {
    lastPrint = now;
    printStatus();
  }

  delay(1);  // yield to idle task (feeds the task watchdog)
}
