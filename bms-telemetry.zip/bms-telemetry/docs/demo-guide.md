# Demonstration guide: fault injection and network outage

This takes about 5 minutes. It needs only the ESP32 (simulated cells) and a
phone or laptop with the Blynk dashboard open. Keep the serial monitor
(`pio device monitor`) on screen as well. It prints every event tagged `LIVE`
or `QUEUED`.

You can drive the demo three ways:

| How | Use |
|-----|-----|
| Dashboard **Demo scenario** menu (V44) → *Full demo* | Hands-free, scripted, about 2.5 min |
| Dashboard controls (Inject / Reset / Simulate outage) | Step by step, you explain as you go |
| Serial console (`demo full`, `inject ov 2`, `outage 60`, …) | Same thing from a terminal |

Before the demo, you can show the expected output on a PC with no hardware:
`make -C tools sim`. It writes `tools/sim/out/full_demo.log`.

---

## Part 0: baseline (30 s)

1. Power the board. Serial shows `NET IDLE -> WIFI_CONNECTING -> CLOUD_CONNECTING -> ONLINE`.
2. On the dashboard: the device is **online**, **Data mode = LIVE**, relay LED
   **green**, Fault **OK**, queue **0/64**, link e.g. `GOOD -60 dBm`.
3. Point out that the cells are moving slightly but **nothing is being sent**.
   Run `status` in the serial console: the `blynk messages sent` rate stays
   low. A value is only transmitted when it changes by more than 20 mV, when
   the weakest or strongest cell changes, on a fault or relay change, or as a
   60 s heartbeat.

## Part 1: fault injection while online (60 s)

| Step | Action | What to show |
|------|--------|--------------|
| 1 | Target cell = 3, Inject = **Imbalance** (or `inject imb 3`) | Within about 0.3 s the relay LED turns **red**, Fault = `IMB (cell 3)`, weakest cell = 3. The terminal shows `LIVE #n … FAULT_SET IMB cell 3, relay OPEN`. If events are set up, a `bms_fault` notification arrives. |
| 2 | Inject = **None** (`clear`) | Fault clears (`FAULT_CLEAR`), but the **relay stays open**: the fault is latched. Fault text: `OK - relay open (reset needed)`. |
| 3 | Press **Operator reset** (`reset`) | `OPERATOR_RESET` then `RELAY CLOSED`. LED goes green. |
| 4 | *(optional)* Inject **Over-voltage** on cell 2, then press reset *while it is still active* | Reset is **refused** ("fault still active"). The protection can't be overridden remotely while a fault is present. |
| 5 | *(optional)* Inject **Open wire** | Shows `SENSOR` and not `UV`. A broken sense wire is reported as a sensor fault. |

Talking point: protection runs in its own 10 Hz task with a 3-sample
debounce, so it trips in about 300 ms. It doesn't depend on Wi-Fi.

## Part 2: network outage with a fault during the outage (2 min)

| Step | Action | What to show |
|------|--------|--------------|
| 1 | Press **Simulate outage** (`outage 60`) | The ESP32 really drops Wi-Fi. Serial: `NET ONLINE -> FORCED_OFFLINE`. Within the offline-ignore period Blynk shows the **device offline**. The status LED blinks fast. |
| 2 | While offline: `inject ov 2` on serial, or hold **BOOT** later for reset | The relay still trips. Serial shows `QUEUED #n FAULT_SET … (queue 3/64)`. The dashboard stays frozen at its last state and shows offline. |
| 3 | `clear`, then hold the **BOOT button** for 1 s (local operator reset) | `QUEUED … OPERATOR_RESET`, `QUEUED … RELAY CLOSED`. `status` shows the queue depth and the oldest event's age. |
| 4 | Wait. The link reconnects by itself after 60 s (or type `restore`) | Serial: `IDLE -> WIFI_CONNECTING -> CLOUD_CONNECTING -> ONLINE`, then `link restored after 63 s, 7 queued event(s)`. |
| 5 | Watch the dashboard | **Data mode = REPLAYING QUEUE** (amber). The live widgets show the *current* state straight away (relay closed, OK). The terminal fills with `REPLAY #12 14:03:53 (-54s) FAULT_SET OV+IMB cell 2 … [6 left]` lines, in the order they happened. The replay chart (V27–V30) back-fills the outage at the real times. Queue depth counts down to 0. |
| 6 | Backlog done | Terminal: `Backlog delivered - dashboard is LIVE again`. Data mode returns to **LIVE**. Outages = 1, Last outage ≈ 63 s, Dropped = 0. |

Talking points:

* **Ordering.** While a backlog exists, new events join the *back* of the
  queue, so the dashboard receives events strictly by sequence number. The
  `LINK_RESTORED` event itself comes after everything that happened offline.
* **Non-blocking reconnect.** `loop()` keeps running during the outage. The
  status LED, button, serial console and fault detection all stay
  responsive. Retries back off 1 s → 2 s → 4 s … 30 s with jitter.
* **Bounded memory.** The queue has 64 fixed slots (36 B each ≈ 2.3 KB, no heap). If it
  fills during a very long outage, the oldest *non-critical* samples are
  dropped first. Faults and relay changes are kept. The number lost is
  reported as a `QUEUE_OVERFLOW` event, and **Dropped** on the dashboard
  shows it. `make -C tools sim` (scenario 2) demonstrates this with an
  8-slot queue.

## Part 3: RSSI / link quality (optional, 1 min)

Walk away from the access point, or shield the antenna with your hand or a
metal box:

* RSSI (V18) and Link quality (V19) fall. Link text changes `GOOD → FAIR → POOR`.
* Each change of *class* is one `LINK_QUALITY` event. Classes have ±3 dB
  hysteresis, so they don't flicker.
* At POOR/BAD the firmware spaces out non-critical telemetry (+3 s / +8 s).
  Faults are always sent immediately.

## Troubleshooting during the demo

| Symptom | Cause |
|---------|-------|
| Stuck in `CLOUD_CONNECTING` | Wrong auth token or template ID, or the device isn't created from the template |
| Data mode never shows REPLAYING | The outage was too short for any event to happen. Inject a fault during it. |
| Notifications don't arrive | Events `bms_fault` / `link_restored` not created, or notifications disabled |
| Charts show no replay points | Datastreams V27–V30 missing, or "Save raw data" off |
| Relay never closes after boot | Start-up self-check failed. Check `status` for a reading outside 3.0–4.25 V or a spread > 150 mV (real ADC mode). |
