# Blynk dashboard setup

You set this up once in **Blynk Console** (https://blynk.cloud). After that the
web dashboard and the mobile app both work.

## 1. Create the template

1. **Developer Zone → My Templates → New Template**. Name: `BMS Telemetry`,
   hardware **ESP32**, connection **WiFi**.
2. Open **Firmware Configuration**. Copy `BLYNK_TEMPLATE_ID` and
   `BLYNK_TEMPLATE_NAME` into `include/secrets.h`.
3. Create the datastreams below: **Datastreams → New Datastream → Virtual Pin**.
4. Create the events in section 4. They're optional.
5. **Devices → New Device → From template**. Copy the **auth token** into
   `include/secrets.h`.

> **Datastream limits.** The FULL profile needs **33 datastreams** with 4
> cells: 4 cell pins, 19 status pins, 5 replay/log pins and 5 controls. How many datastreams a template allows
> depends on your Blynk plan, and the limits have changed over time. If Blynk
> won't let you add more, switch to the **COMPACT profile** (10 datastreams):
> set `#define DASHBOARD_PROFILE DASHBOARD_COMPACT` in `include/config.h`.

## 2. Datastreams: FULL profile (default)

Set **"Save raw data"** on every chart datastream. Without it, the history
charts are coarse.

### Live values (written only with current data)

| Pin | Name | Type | Units | Min | Max | Decimals | Suggested widget |
|----|------|------|-------|-----|-----|----------|------------------|
| V0–V3 | Cell 1…4 | Double | V | 2.5 | 4.5 | #.### | Gauge ×4 + one SuperChart |
| V4–V7 | Cell 5…8 | Double | V | 2.5 | 4.5 | #.### | only if `CELL_COUNT` > 4 |
| V8 | Weakest cell V | Double | V | 2.5 | 4.5 | #.### | Value display (red) + chart |
| V9 | Weakest cell # | Integer | – | 1 | 8 | – | Value display "Cell /pin/" |
| V10 | Strongest cell V | Double | V | 2.5 | 4.5 | #.### | Value display (green) + chart |
| V11 | Strongest cell # | Integer | – | 1 | 8 | – | Value display |
| V12 | Cell delta | Integer | mV | 0 | 1000 | – | Gauge (warn at 100, alarm at 150) |
| V13 | Pack voltage | Double | V | 0 | 40 | #.## | Value display |
| V14 | Relay | Integer | – | 0 | 1 | – | LED (1 = green "CLOSED") |
| V15 | Fault code | Integer | – | 0 | 15 | – | LED / Value (0 = OK) |
| V16 | Fault text | String | – | – | – | – | Label |
| V17 | Data mode | Integer | – | 0 | 1 | – | Label with color: 0 "LIVE" green, 1 "REPLAYING QUEUE" amber |
| V18 | RSSI | Integer | dBm | -100 | -30 | – | Gauge + SuperChart |
| V19 | Link quality | Integer | % | 0 | 100 | – | Level / gauge |
| V20 | Link text | String | – | – | – | – | Label (e.g. "GOOD -61 dBm") |
| V21 | Queue depth | Integer | events | 0 | 64 | – | Gauge + SuperChart (spikes = outages) |
| V22 | Events dropped | Integer | – | 0 | 10000 | – | Value (should stay 0) |
| V23 | Outages | Integer | – | 0 | 10000 | – | Value |
| V24 | Last outage | Integer | s | 0 | 86400 | – | Value |
| V25 | Uptime | Integer | min | 0 | 1000000 | – | Value |
| V26 | Last live seq | Integer | – | 0 | 2147483647 | – | Value (small) |

### Replayed values (only from the offline queue, timestamped when they happened)

| Pin | Name | Type | Units | Min | Max | Widget |
|----|------|------|-------|-----|-----|--------|
| V27 | Replay weakest V | Double | V | 2.5 | 4.5 | SuperChart "Recovered during outage" |
| V28 | Replay strongest V | Double | V | 2.5 | 4.5 | same chart |
| V29 | Replay fault code | Integer | – | 0 | 15 | same chart (step) |
| V30 | Replay relay | Integer | – | 0 | 1 | same chart (step) |
| V31 | Event log | String | – | – | – | **Terminal** widget (lines start with `LIVE` or `REPLAY`) |

### Controls (app → device)

| Pin | Name | Type | Min | Max | Widget |
|----|------|------|-----|-----|--------|
| V40 | Inject fault | Integer | 0 | 4 | Menu: `None`, `Over-voltage`, `Under-voltage`, `Imbalance`, `Open wire` |
| V41 | Target cell | Integer | 1 | 4 | Slider (or Step) |
| V42 | Operator reset | Integer | 0 | 1 | Button, **push** mode |
| V43 | Simulate outage | Integer | 0 | 1 | Button, **push** mode (drops Wi-Fi for 60 s) |
| V44 | Demo scenario | Integer | 0 | 3 | Menu: `Stop`, `Fault demo`, `Outage demo`, `Full demo` |

Fault code bits: 1 = OV, 2 = UV, 4 = imbalance, 8 = sensor (open wire).

## 3. Suggested web dashboard layout

```
+---------------------------- STATUS ------------------------------------+
| [Device online/offline]  DATA MODE: LIVE | Relay ● | Fault: OK          |
| Link: GOOD -61 dBm  [====== 78% ]   Queue 0/64   Dropped 0   Outages 1  |
+---------------------------- CELLS -------------------------------------+
| (C1 3.712) (C2 3.705) (C3 3.694) (C4 3.709)     gauges                  |
| Weakest: Cell 3  3.694 V        Strongest: Cell 1  3.712 V   Δ 18 mV    |
| SuperChart: V0..V3 live cell voltages                                   |
+---------------------------- NETWORK -----------------------------------+
| SuperChart: RSSI (V18) + Queue depth (V21) - outages show as queue humps|
+---------------------------- RECOVERED DATA ----------------------------+
| SuperChart: V27..V30 - values that happened offline, at their real time |
| Terminal (V31):                                                         |
|   LIVE   #5  14:02:13 FAULT_SET IMB cell 3, relay OPEN                  |
|   REPLAY #12 14:03:53 (-54s) FAULT_SET OV+IMB cell 2, relay OPEN [6 left]|
+---------------------------- CONTROLS ----------------------------------+
| Inject [menu]  Cell [slider]  [Operator reset]  [Simulate outage]  Demo |
+-------------------------------------------------------------------------+
```

How an operator tells live data from queued data:

* **Device online indicator** (Blynk's own): while it's offline, nothing on
  the page is current.
* **Data mode (V17)**: `REPLAYING QUEUE` means the device is back online but
  is still uploading backlog. The live widgets already show the current state.
* **Separate pins.** Replayed data never touches the live widgets (V0–V26).
  It goes only to V27–V30 and the terminal.
* **Original timestamps.** Replayed points land on the chart at the moment
  they happened, not at upload time. The terminal line shows its age
  (`-54s`).
* **Queue depth (V21)** counts down to 0 while the backlog uploads.

## 4. Events (optional, for notifications)

**Template → Events → Add**. Turn on notifications if you want push/e-mail.

| Event code | Type | Used for |
|------------|------|----------|
| `bms_fault` | Critical | Every new fault. For faults that happened offline, the description starts with `[queued, Ns ago]`. |
| `link_restored` | Info | Link back after an outage |

Also turn on Blynk's built-in **"Device offline"** notification
(Template → Info → Offline ignore period, e.g. 30 s). That alerts you to an
outage while it's happening.

Set `ENABLE_BLYNK_EVENTS 0` in `config.h` if you don't create the events.

## 5. COMPACT profile (10 datastreams)

| Pin | Name | Type | Widget |
|----|------|------|--------|
| V0 | Weakest cell V | Double 2.5–4.5 | Gauge + chart |
| V1 | Strongest cell V | Double 2.5–4.5 | Gauge + chart |
| V2 | Cells | String | Label: `C1 3.712 \| C2 3.705 \| … \| W:C3 S:C1 d=18mV` |
| V3 | Relay | Integer 0–1 | LED |
| V4 | Fault code | Integer 0–15 | LED / value |
| V5 | Status | String | Label: `LIVE \| Q 0/64 \| GOOD -61 dBm \| out 1 \| OK` |
| V6 | Queue depth | Integer 0–64 | Chart |
| V7 | Event log | String | Terminal |
| V8 | Command | Integer 0–11 | Menu (below) |
| V9 | RSSI | Integer -100…-30 | Chart |

Command menu values: 1 OV cell 2 · 2 UV cell 1 · 3 imbalance cell 3 ·
4 open wire on last cell · 5 clear injection · 6 operator reset ·
7 60 s outage · 8 fault demo · 9 outage demo · 10 full demo · 11 stop demo.
After each command the menu resets itself to 0.
