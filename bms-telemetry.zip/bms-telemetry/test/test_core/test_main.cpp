// Host unit tests for lib/telemetry_core.   pio test -e native
//                                       or  make -C tools test
#include <string.h>
#include <unity.h>

#include <vector>

#include "DemoSupport.h"
#include "EventDetector.h"
#include "EventQueue.h"
#include "FaultManager.h"
#include "RssiMonitor.h"
#include "TelemetryManager.h"
#include "WifiStateMachine.h"

using namespace tel;

void setUp() {}
void tearDown() {}

// ----------------------------------------------------------------- helpers
static TelemetryEvent ev(EventType t, uint32_t seq) {
  TelemetryEvent e;
  e.type = t;
  e.seq = seq;
  e.tMs = seq * 10;
  return e;
}

static CellSnapshot cells4(uint16_t a, uint16_t b, uint16_t c, uint16_t d) {
  CellSnapshot s;
  s.count = 4;
  s.mv[0] = a; s.mv[1] = b; s.mv[2] = c; s.mv[3] = d;
  return s;
}

static DetectorInput input(const CellSnapshot& s, uint16_t faults = 0, bool relay = true) {
  DetectorInput in;
  in.cells = s;
  in.faults = faults;
  in.relayClosed = relay;
  in.link = LinkQuality::Good;
  return in;
}

// ============================================================== EventQueue
void test_queue_fifo_order() {
  EventQueue<4> q;
  for (uint32_t i = 1; i <= 4; ++i) TEST_ASSERT_TRUE(q.push(ev(EventType::CellChange, i)));
  TEST_ASSERT_TRUE(q.full());
  for (uint32_t i = 1; i <= 4; ++i) {
    TEST_ASSERT_EQUAL_UINT32(i, q.front()->seq);
    q.pop();
  }
  TEST_ASSERT_TRUE(q.empty());
  TEST_ASSERT_NULL(q.front());
}

void test_queue_wraparound_keeps_order() {
  EventQueue<3> q;
  uint32_t next = 1, expect = 1;
  for (int round = 0; round < 10; ++round) {
    q.push(ev(EventType::CellChange, next++));
    q.push(ev(EventType::CellChange, next++));
    TEST_ASSERT_EQUAL_UINT32(expect++, q.front()->seq); q.pop();
    TEST_ASSERT_EQUAL_UINT32(expect++, q.front()->seq); q.pop();
  }
  TEST_ASSERT_EQUAL_UINT32(0, q.droppedTotal());
}

void test_queue_overflow_evicts_oldest_normal_keeps_faults() {
  EventQueue<4> q;
  q.push(ev(EventType::FaultSet, 1));
  q.push(ev(EventType::CellChange, 2));   // oldest normal -> evicted
  q.push(ev(EventType::RelayChange, 3));
  q.push(ev(EventType::CellChange, 4));
  TEST_ASSERT_FALSE(q.push(ev(EventType::Heartbeat, 5)));
  TEST_ASSERT_EQUAL_UINT32(1, q.droppedTotal());
  const uint32_t expect[] = {1, 3, 4, 5};
  for (uint32_t s : expect) { TEST_ASSERT_EQUAL_UINT32(s, q.front()->seq); q.pop(); }
}

void test_queue_all_critical_refuses_normal_and_rotates_critical() {
  EventQueue<3> q;
  q.push(ev(EventType::FaultSet, 1));
  q.push(ev(EventType::FaultClear, 2));
  q.push(ev(EventType::RelayChange, 3));
  TEST_ASSERT_FALSE(q.push(ev(EventType::CellChange, 4)));  // refused
  TEST_ASSERT_EQUAL_UINT32(1, q.front()->seq);
  TEST_ASSERT_FALSE(q.push(ev(EventType::FaultSet, 5)));    // evicts #1
  TEST_ASSERT_EQUAL_UINT32(2, q.droppedUnreported());
  const uint32_t expect[] = {2, 3, 5};
  for (uint32_t s : expect) { TEST_ASSERT_EQUAL_UINT32(s, q.front()->seq); q.pop(); }
  q.markDropsReported();
  TEST_ASSERT_EQUAL_UINT32(0, q.droppedUnreported());
  TEST_ASSERT_EQUAL_UINT32(2, q.droppedTotal());
}

// ============================================================ FaultManager
void test_fault_debounce_and_hysteresis() {
  FaultManager fm;
  const CellSnapshot ok = cells4(3700, 3700, 3700, 3700);
  for (int i = 0; i < 5; ++i) fm.update(ok);
  TEST_ASSERT_TRUE(fm.relayClosed());

  const CellSnapshot ov = cells4(3700, 4300, 3700, 3700);
  fm.update(ov); fm.update(ov);
  TEST_ASSERT_EQUAL_UINT16(0, fm.active());        // 2 samples: not yet
  fm.update(ov);
  TEST_ASSERT_TRUE(fm.active() & FAULT_OVERVOLT);  // 3rd sample trips
  TEST_ASSERT_EQUAL_UINT8(2, fm.faultCell());
  TEST_ASSERT_FALSE(fm.relayClosed());

  // 4.20 V is below the trip point but above the clear point: stays set.
  const CellSnapshot mid = cells4(4100, 4200, 4100, 4100);
  for (int i = 0; i < 5; ++i) fm.update(mid);
  TEST_ASSERT_TRUE(fm.active() & FAULT_OVERVOLT);
  const CellSnapshot back = cells4(4100, 4100, 4100, 4100);
  for (int i = 0; i < 3; ++i) fm.update(back);
  TEST_ASSERT_EQUAL_UINT16(0, fm.active());
}

void test_fault_latch_requires_operator_reset() {
  FaultManager fm;
  const CellSnapshot ok = cells4(3700, 3700, 3700, 3700);
  for (int i = 0; i < 5; ++i) fm.update(ok);
  const CellSnapshot uv = cells4(2900, 3700, 3700, 3700);
  for (int i = 0; i < 3; ++i) fm.update(uv);
  TEST_ASSERT_TRUE(fm.active() & FAULT_UNDERVOLT);
  TEST_ASSERT_FALSE(fm.requestReset());            // refused while active
  for (int i = 0; i < 3; ++i) fm.update(ok);
  TEST_ASSERT_EQUAL_UINT16(0, fm.active());
  TEST_ASSERT_FALSE(fm.relayClosed());             // still latched open
  TEST_ASSERT_TRUE(fm.latched() & FAULT_UNDERVOLT);
  TEST_ASSERT_TRUE(fm.requestReset());
  TEST_ASSERT_TRUE(fm.relayClosed());
  TEST_ASSERT_EQUAL_UINT16(0, fm.latched());
}

void test_open_wire_is_sensor_fault_not_undervolt() {
  FaultManager fm;
  const CellSnapshot ok = cells4(3700, 3700, 3700, 3700);
  for (int i = 0; i < 5; ++i) fm.update(ok);
  const CellSnapshot open = cells4(3700, 3700, 3700, 120);
  for (int i = 0; i < 3; ++i) fm.update(open);
  TEST_ASSERT_TRUE(fm.active() & FAULT_SENSOR);
  TEST_ASSERT_FALSE(fm.active() & FAULT_UNDERVOLT);
  TEST_ASSERT_EQUAL_UINT8(4, fm.faultCell());
  TEST_ASSERT_FALSE(fm.relayClosed());
}

void test_relay_open_until_startup_self_check() {
  FaultManager fm;
  const CellSnapshot ok = cells4(3700, 3700, 3700, 3700);
  for (int i = 0; i < 4; ++i) { fm.update(ok); TEST_ASSERT_FALSE(fm.relayClosed()); }
  fm.update(ok);
  TEST_ASSERT_TRUE(fm.startupOk());
  TEST_ASSERT_TRUE(fm.relayClosed());
}

// =========================================================== EventDetector
void test_detector_boot_then_silent_when_stable() {
  EventDetector d;
  TelemetryEvent out[8];
  CellSnapshot s = cells4(3700, 3705, 3695, 3702);
  TEST_ASSERT_EQUAL(1, d.evaluate(input(s), 0, out, 8));
  TEST_ASSERT_EQUAL(EventType::Boot, out[0].type);
  // +/-5 mV of noise for 50 s: nothing is worth sending.
  for (uint32_t t = 100; t < 50000; t += 100) {
    CellSnapshot n = s;
    n.mv[t / 100 % 4] += (t / 100 % 2) ? 5 : -5;
    TEST_ASSERT_EQUAL(0, d.evaluate(input(n), t, out, 8));
  }
}

void test_detector_significant_change_and_rate_limit() {
  DetectorConfig cfg;
  cfg.minIntervalMs = 2000;
  EventDetector d(cfg);
  TelemetryEvent out[8];
  d.evaluate(input(cells4(3700, 3690, 3680, 3710)), 0, out, 8);
  // C2 +25 mV at t=500: inside the rate-limit window -> wait. (C2 becomes the
  // strongest by only 5 mV, below the extremes hysteresis.)
  const CellSnapshot moved = cells4(3700, 3715, 3680, 3710);
  TEST_ASSERT_EQUAL(0, d.evaluate(input(moved), 500, out, 8));
  TEST_ASSERT_EQUAL(1, d.evaluate(input(moved), 2000, out, 8));
  TEST_ASSERT_EQUAL(EventType::CellChange, out[0].type);
  TEST_ASSERT_EQUAL_INT32(2, out[0].arg);  // cell 2
  // Deadband is measured from the last REPORTED value, not the last sample.
  TEST_ASSERT_EQUAL(0, d.evaluate(input(cells4(3700, 3725, 3680, 3710)), 4500, out, 8));
}

void test_detector_fault_and_relay_are_immediate() {
  EventDetector d;
  TelemetryEvent out[8];
  const CellSnapshot s = cells4(3700, 3700, 3700, 3700);
  d.evaluate(input(s), 0, out, 8);
  const size_t n = d.evaluate(input(s, FAULT_OVERVOLT, false), 100, out, 8);  // within rate limit
  TEST_ASSERT_EQUAL(2, n);
  TEST_ASSERT_EQUAL(EventType::FaultSet, out[0].type);
  TEST_ASSERT_EQUAL_INT32(FAULT_OVERVOLT, out[0].arg);
  TEST_ASSERT_EQUAL(EventType::RelayChange, out[1].type);
  TEST_ASSERT_EQUAL_INT32(0, out[1].arg);
  TEST_ASSERT_EQUAL(1, d.evaluate(input(s, 0, false), 200, out, 8));
  TEST_ASSERT_EQUAL(EventType::FaultClear, out[0].type);
}

void test_detector_weakest_cell_change() {
  EventDetector d;
  TelemetryEvent out[8];
  d.evaluate(input(cells4(3700, 3690, 3710, 3705)), 0, out, 8);  // weakest = C2
  // C3 drops below C2 by 15 mV (> hysteresis, < deadband for C2).
  const size_t n = d.evaluate(input(cells4(3700, 3690, 3675, 3705)), 3000, out, 8);
  TEST_ASSERT_EQUAL(1, n);
  TEST_ASSERT_EQUAL(EventType::ExtremesChange, out[0].type);
  TEST_ASSERT_EQUAL_INT32((3 << 8) | 4, out[0].arg);  // weakest C3, strongest C4
}

void test_detector_heartbeat() {
  DetectorConfig cfg;
  cfg.heartbeatMs = 10000;
  EventDetector d(cfg);
  TelemetryEvent out[8];
  const CellSnapshot s = cells4(3700, 3700, 3700, 3700);
  d.evaluate(input(s), 0, out, 8);
  TEST_ASSERT_EQUAL(0, d.evaluate(input(s), 9900, out, 8));
  TEST_ASSERT_EQUAL(1, d.evaluate(input(s), 10000, out, 8));
  TEST_ASSERT_EQUAL(EventType::Heartbeat, out[0].type);
}

// ============================================================= RssiMonitor
void test_rssi_classes_and_hysteresis() {
  RssiMonitor m(1.0f, 3.0f);  // alpha 1 = no smoothing, to test the classes
  m.addSample(0);             // ignored (not associated)
  TEST_ASSERT_FALSE(m.hasData());
  m.addSample(-60);
  TEST_ASSERT_EQUAL(LinkQuality::Good, m.quality());
  m.addSample(-68);           // just past the -67 boundary: stays GOOD
  TEST_ASSERT_EQUAL(LinkQuality::Good, m.quality());
  m.addSample(-71);           // clearly past: FAIR
  TEST_ASSERT_EQUAL(LinkQuality::Fair, m.quality());
  m.addSample(-66);           // just back over: stays FAIR
  TEST_ASSERT_EQUAL(LinkQuality::Fair, m.quality());
  m.addSample(-90);
  TEST_ASSERT_EQUAL(LinkQuality::Bad, m.quality());
  TEST_ASSERT_TRUE(m.suggestedThrottleMs() > 0);
  TEST_ASSERT_EQUAL_INT8(-90, m.minSeen());
}

void test_rssi_smoothing() {
  RssiMonitor m(0.25f);
  m.addSample(-60);
  m.addSample(-80);           // one bad reading moves the average by 5 dB only
  TEST_ASSERT_EQUAL_INT8(-65, m.rssi());
}

// ======================================================== WifiStateMachine
struct FakeNet : INetDriver {
  bool apUp = true, cloudUp = true;   // what the "world" allows
  bool assoc = false, session = false;
  int wifiBegins = 0, cloudBegins = 0, rssiDbm = -60;
  uint32_t* clock = nullptr;
  uint32_t assocAt = 0, loginAt = 0;
  bool assocPending = false, loginPending = false;
  void wifiBegin() override { ++wifiBegins; assocPending = true; assocAt = *clock + 800; }
  bool wifiConnected() override {
    if (!apUp) { assoc = false; assocPending = false; }
    if (assocPending && apUp && *clock >= assocAt) { assoc = true; assocPending = false; }
    return assoc;
  }
  void wifiDisconnect() override { assoc = false; assocPending = false; session = false; }
  void cloudBegin() override { ++cloudBegins; loginPending = true; loginAt = *clock + 500; }
  bool cloudConnected() override {
    if (!cloudUp || !assoc) session = false;
    return session;
  }
  void cloudService() override {
    if (loginPending && cloudUp && assoc && *clock >= loginAt) { session = true; loginPending = false; }
  }
  void cloudDisconnect() override { session = false; loginPending = false; }
  int rssi() override { return assoc ? rssiDbm : 0; }
};

static void runFor(WifiStateMachine& sm, uint32_t& t, uint32_t ms) {
  for (uint32_t end = t + ms; t < end; t += 10) sm.tick(t);
}

void test_wifi_sm_connects_and_samples_rssi() {
  uint32_t t = 0;
  FakeNet net; net.clock = &t;
  RssiMonitor rssi;
  WifiStateMachine sm(net, rssi);
  sm.start(t);
  runFor(sm, t, 3000);
  TEST_ASSERT_EQUAL(NetState::Online, sm.state());
  TEST_ASSERT_TRUE(rssi.hasData());
  uint32_t outage;
  TEST_ASSERT_FALSE(sm.consumeRestored(outage));  // first connection is not a "restore"
}

void test_wifi_sm_backoff_grows_and_recovers() {
  uint32_t t = 0;
  FakeNet net; net.clock = &t;
  RssiMonitor rssi;
  NetConfig cfg; cfg.wifiTimeoutMs = 2000;
  WifiStateMachine sm(net, rssi, cfg);
  sm.start(t);
  runFor(sm, t, 3000);
  net.apUp = false;                              // access point disappears
  runFor(sm, t, 20);
  TEST_ASSERT_EQUAL(NetState::Backoff, sm.state());
  TEST_ASSERT_EQUAL_UINT32(1, sm.disconnects());
  runFor(sm, t, 30000);
  TEST_ASSERT_TRUE(sm.currentBackoffMs() >= 4000);  // grew 1 -> 2 -> 4 -> 8 s ...
  TEST_ASSERT_TRUE(sm.currentBackoffMs() <= cfg.backoffMaxMs);
  net.apUp = true;
  runFor(sm, t, 40000);
  TEST_ASSERT_EQUAL(NetState::Online, sm.state());
  uint32_t outage = 0;
  TEST_ASSERT_TRUE(sm.consumeRestored(outage));
  TEST_ASSERT_TRUE(outage > 30000);
  TEST_ASSERT_EQUAL_UINT32(0, sm.currentBackoffMs());
}

void test_wifi_sm_cloud_only_drop_keeps_wifi() {
  uint32_t t = 0;
  FakeNet net; net.clock = &t;
  RssiMonitor rssi;
  WifiStateMachine sm(net, rssi);
  sm.start(t);
  runFor(sm, t, 3000);
  const int wifiBegins = net.wifiBegins;
  net.cloudUp = false;
  runFor(sm, t, 20);
  TEST_ASSERT_EQUAL(NetState::CloudConnecting, sm.state());
  net.cloudUp = true;
  runFor(sm, t, 2000);
  TEST_ASSERT_EQUAL(NetState::Online, sm.state());
  TEST_ASSERT_EQUAL(wifiBegins, net.wifiBegins);  // no Wi-Fi re-association needed
}

void test_wifi_sm_forced_outage() {
  uint32_t t = 0;
  FakeNet net; net.clock = &t;
  RssiMonitor rssi;
  WifiStateMachine sm(net, rssi);
  sm.start(t);
  runFor(sm, t, 3000);
  sm.forceOffline(t, 10000);
  runFor(sm, t, 9000);
  TEST_ASSERT_EQUAL(NetState::ForcedOffline, sm.state());
  TEST_ASSERT_FALSE(net.assoc);
  runFor(sm, t, 4000);
  TEST_ASSERT_EQUAL(NetState::Online, sm.state());
  uint32_t outage = 0;
  TEST_ASSERT_TRUE(sm.consumeRestored(outage));
  TEST_ASSERT_TRUE(outage >= 10000 && outage < 12000);
}

// ======================================================= TelemetryManager
struct FakePub : IPublisher {
  bool up = true;
  int failNext = 0;
  std::vector<uint32_t> live, replay, all;
  bool canPublish() override { return up; }
  bool publishLive(const TelemetryEvent& e) override {
    live.push_back(e.seq); all.push_back(e.seq); return true;
  }
  bool publishReplay(const TelemetryEvent& e, uint32_t, size_t) override {
    if (failNext > 0) { --failNext; return false; }
    replay.push_back(e.seq); all.push_back(e.seq); return true;
  }
};

void test_manager_live_queue_replay_in_order() {
  FakePub pub;
  TelemetryManager<16> tm(pub, 100);
  uint32_t t = 0;
  TEST_ASSERT_TRUE(tm.submit(ev(EventType::CellChange, 0), true, t));
  // Outage: three events queue up.
  pub.up = false;
  for (int i = 0; i < 3; ++i) TEST_ASSERT_FALSE(tm.submit(ev(EventType::FaultSet, 0), false, t += 50));
  TEST_ASSERT_EQUAL(DataMode::Offline, tm.mode(false));
  TEST_ASSERT_EQUAL(3, tm.depth());
  // Back online: one replay per interval; a new event arriving mid-replay
  // must NOT jump ahead of the backlog.
  pub.up = true;
  TEST_ASSERT_EQUAL(DataMode::Replaying, tm.mode(true));
  tm.service(true, t += 100);
  TEST_ASSERT_FALSE(tm.submit(ev(EventType::RelayChange, 0), true, t));
  for (int i = 0; i < 10; ++i) tm.service(true, t += 100);
  TEST_ASSERT_EQUAL(0, tm.depth());
  TEST_ASSERT_TRUE(tm.consumeDrained());
  TEST_ASSERT_EQUAL(DataMode::Live, tm.mode(true));
  TEST_ASSERT_EQUAL(5u, pub.all.size());
  for (size_t i = 0; i < pub.all.size(); ++i) TEST_ASSERT_EQUAL_UINT32(i + 1, pub.all[i]);
  TEST_ASSERT_EQUAL(1u, pub.live.size());
  TEST_ASSERT_EQUAL(4u, pub.replay.size());
}

void test_manager_failed_replay_is_retried_not_lost() {
  FakePub pub;
  TelemetryManager<8> tm(pub, 0);
  pub.up = false;
  tm.submit(ev(EventType::FaultSet, 0), false, 0);
  tm.submit(ev(EventType::FaultClear, 0), false, 1);
  pub.up = true;
  pub.failNext = 2;
  for (int i = 0; i < 6; ++i) tm.service(true, 10 + i);
  TEST_ASSERT_EQUAL(2u, pub.replay.size());
  TEST_ASSERT_EQUAL_UINT32(1, pub.replay[0]);
  TEST_ASSERT_EQUAL_UINT32(2, pub.replay[1]);
}

void test_manager_reports_overflow_after_drain() {
  FakePub pub;
  TelemetryManager<4> tm(pub, 0);
  pub.up = false;
  for (int i = 0; i < 7; ++i) tm.submit(ev(EventType::CellChange, 0), false, i);
  TEST_ASSERT_EQUAL(4, tm.depth());
  TEST_ASSERT_EQUAL_UINT32(3, tm.dropped());
  pub.up = true;
  for (int i = 0; i < 10; ++i) tm.service(true, 100 + i);
  // 4 survivors replayed, then a live QUEUE_OVERFLOW event reporting 3 lost.
  TEST_ASSERT_EQUAL(4u, pub.replay.size());
  TEST_ASSERT_EQUAL(1u, pub.live.size());
  TEST_ASSERT_EQUAL_UINT32(4, pub.replay[0]);   // oldest 3 were evicted
  TEST_ASSERT_EQUAL_UINT32(8, pub.live[0]);
}

// ============================================================ DemoSupport
void test_injection_trips_expected_faults() {
  struct Case { InjectKind k; uint16_t bit; } cases[] = {
      {InjectKind::OverVolt, FAULT_OVERVOLT}, {InjectKind::UnderVolt, FAULT_UNDERVOLT},
      {InjectKind::Imbalance, FAULT_IMBALANCE}, {InjectKind::OpenWire, FAULT_SENSOR}};
  for (auto& c : cases) {
    SimulatedPack pack(4);
    FaultManager fm;
    Injection inj; inj.kind = c.k; inj.cell = 2;
    for (uint32_t t = 0; t < 2000; t += 100) {
      CellSnapshot s;
      pack.sample(t, s);
      if (t >= 1000) applyInjection(s, inj);
      fm.update(s);
      if (t < 1000) TEST_ASSERT_EQUAL_UINT16(0, fm.active());
    }
    TEST_ASSERT_TRUE_MESSAGE(fm.active() & c.bit, injectName(c.k));
    TEST_ASSERT_FALSE(fm.relayClosed());
  }
}

int main(int, char**) {
  UNITY_BEGIN();
  RUN_TEST(test_queue_fifo_order);
  RUN_TEST(test_queue_wraparound_keeps_order);
  RUN_TEST(test_queue_overflow_evicts_oldest_normal_keeps_faults);
  RUN_TEST(test_queue_all_critical_refuses_normal_and_rotates_critical);
  RUN_TEST(test_fault_debounce_and_hysteresis);
  RUN_TEST(test_fault_latch_requires_operator_reset);
  RUN_TEST(test_open_wire_is_sensor_fault_not_undervolt);
  RUN_TEST(test_relay_open_until_startup_self_check);
  RUN_TEST(test_detector_boot_then_silent_when_stable);
  RUN_TEST(test_detector_significant_change_and_rate_limit);
  RUN_TEST(test_detector_fault_and_relay_are_immediate);
  RUN_TEST(test_detector_weakest_cell_change);
  RUN_TEST(test_detector_heartbeat);
  RUN_TEST(test_rssi_classes_and_hysteresis);
  RUN_TEST(test_rssi_smoothing);
  RUN_TEST(test_wifi_sm_connects_and_samples_rssi);
  RUN_TEST(test_wifi_sm_backoff_grows_and_recovers);
  RUN_TEST(test_wifi_sm_cloud_only_drop_keeps_wifi);
  RUN_TEST(test_wifi_sm_forced_outage);
  RUN_TEST(test_manager_live_queue_replay_in_order);
  RUN_TEST(test_manager_failed_replay_is_retried_not_lost);
  RUN_TEST(test_manager_reports_overflow_after_drain);
  RUN_TEST(test_injection_trips_expected_faults);
  return UNITY_END();
}
