// TelemetryTypes.h — shared data types for the event-driven BMS telemetry core.
//
// Everything in lib/telemetry_core is plain C++11 with no Arduino dependency,
// so the same code runs on the ESP32 and in the host-side unit tests / demo
// simulator (see test/ and tools/).
#pragma once

#include <stddef.h>
#include <stdint.h>

namespace tel {

constexpr uint8_t kMaxCells = 8;

// ---------------------------------------------------------------- faults ---
enum FaultBits : uint16_t {
  FAULT_NONE      = 0,
  FAULT_OVERVOLT  = 1u << 0,  // any cell above OV threshold
  FAULT_UNDERVOLT = 1u << 1,  // any cell below UV threshold
  FAULT_IMBALANCE = 1u << 2,  // strongest - weakest above limit
  FAULT_SENSOR    = 1u << 3,  // open wire / reading outside plausible range
};

// Writes e.g. "OK", "OV", "OV+IMB" into buf. Returns buf.
const char* faultsToString(uint16_t faults, char* buf, size_t len);

// ----------------------------------------------------------- cell data ---
struct CellSnapshot {
  uint32_t tMs = 0;               // uptime (ms) at which the sample was taken
  uint8_t  count = 0;             // cells in use (<= kMaxCells)
  uint16_t mv[kMaxCells] = {0};   // per-cell voltage in millivolts
};

struct CellStats {
  uint8_t  count = 0;
  uint8_t  minIdx = 0;            // 0-based index of weakest cell
  uint8_t  maxIdx = 0;            // 0-based index of strongest cell
  uint16_t minMv = 0;
  uint16_t maxMv = 0;
  uint16_t avgMv = 0;
  uint16_t deltaMv = 0;           // maxMv - minMv
  uint32_t packMv = 0;            // sum of all cells
};

CellStats computeStats(const CellSnapshot& s);

// -------------------------------------------------------------- events ---
enum class EventType : uint8_t {
  Boot = 0,        // first report after power-up
  CellChange,      // a cell moved by more than the deadband
  ExtremesChange,  // a different cell became weakest / strongest
  FaultSet,        // one or more fault bits became active (arg = new bits)
  FaultClear,      // one or more fault bits cleared (arg = cleared bits)
  RelayChange,     // contactor/relay opened or closed
  LinkRestored,    // connectivity back after an outage (arg = outage ms)
  LinkQuality,     // RSSI quality class changed (arg = LinkQuality value)
  Heartbeat,       // nothing changed for a long time; proves liveness
  QueueOverflow,   // offline queue had to discard events (arg = count)
  OperatorReset,   // operator cleared the fault latch
};

enum class Priority : uint8_t { Normal = 0, Critical = 1 };

struct TelemetryEvent {
  uint32_t  seq = 0;              // monotonically increasing; gaps = drops
  uint32_t  tMs = 0;              // uptime when the event happened
  EventType type = EventType::Heartbeat;
  uint8_t   cellCount = 0;
  uint16_t  mv[kMaxCells] = {0};  // cell voltages at event time
  uint16_t  faults = 0;           // active fault bits at event time
  uint8_t   faultCell = 0;        // 1-based cell that caused the fault, 0 = n/a
  bool      relayClosed = false;
  int8_t    rssi = 0;             // dBm at event time (0 = unknown)
  int32_t   arg = 0;              // type-specific payload (see EventType)
};

Priority    priorityOf(EventType t);
const char* eventName(EventType t);

// Stats for the voltages carried inside an event.
CellStats statsOf(const TelemetryEvent& e);

// ----------------------------------------------------------- link info ---
enum class LinkQuality : uint8_t { Unknown = 0, Bad, Poor, Fair, Good, Excellent };
const char* linkQualityName(LinkQuality q);

// Which data the dashboard is currently receiving.
enum class DataMode : uint8_t { Live = 0, Replaying = 1, Offline = 2 };
const char* dataModeName(DataMode m);

}  // namespace tel
