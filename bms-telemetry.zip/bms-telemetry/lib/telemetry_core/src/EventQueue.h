// EventQueue.h — fixed-size FIFO for telemetry events that could not be sent.
//
// * No heap: storage is a static array sized at compile time.
// * Strict FIFO: events leave in exactly the order they were accepted.
// * Overflow policy (queue full):
//     1. evict the OLDEST Normal-priority event (cell change / heartbeat /
//        link quality), keeping every fault and relay record;
//     2. if every slot already holds a Critical event, a new Normal event is
//        refused, and a new Critical event evicts the oldest Critical one.
//   Every discarded event is counted so the loss is itself reported later.
#pragma once

#include "TelemetryTypes.h"

namespace tel {

template <size_t N>
class EventQueue {
  static_assert(N >= 2, "queue needs at least two slots");

 public:
  bool   empty() const { return count_ == 0; }
  bool   full() const { return count_ == N; }
  size_t size() const { return count_; }
  static constexpr size_t capacity() { return N; }

  // Total events ever discarded, and those not yet reported to the cloud.
  uint32_t droppedTotal() const { return droppedTotal_; }
  uint32_t droppedUnreported() const { return droppedUnreported_; }
  void     markDropsReported() { droppedUnreported_ = 0; }

  // Returns true if the event was stored without losing anything.
  bool push(const TelemetryEvent& e) {
    if (count_ < N) {
      buf_[physical(count_)] = e;
      ++count_;
      return true;
    }
    // Full: try to make room by evicting the oldest Normal event.
    for (size_t i = 0; i < count_; ++i) {
      if (priorityOf(at(i).type) == Priority::Normal) {
        eraseAt(i);
        noteDrop();
        buf_[physical(count_)] = e;
        ++count_;
        return false;
      }
    }
    // Queue is all Critical.
    if (priorityOf(e.type) == Priority::Normal) {
      noteDrop();          // refuse the new, less important event
      return false;
    }
    pop();                 // evict oldest Critical to keep the newest one
    noteDrop();
    buf_[physical(count_)] = e;
    ++count_;
    return false;
  }

  const TelemetryEvent* front() const { return count_ ? &buf_[head_] : nullptr; }

  void pop() {
    if (!count_) return;
    head_ = (head_ + 1) % N;
    --count_;
  }

  // i = 0 is the oldest event.
  const TelemetryEvent& at(size_t i) const { return buf_[physical(i)]; }

  void clear() { head_ = 0; count_ = 0; }

 private:
  size_t physical(size_t logical) const { return (head_ + logical) % N; }

  // Remove the element at logical index i, shifting newer ones down so
  // the remaining order is unchanged. O(N), N is small.
  void eraseAt(size_t i) {
    for (size_t k = i; k + 1 < count_; ++k) buf_[physical(k)] = buf_[physical(k + 1)];
    --count_;
  }

  void noteDrop() {
    ++droppedTotal_;
    ++droppedUnreported_;
  }

  TelemetryEvent buf_[N];
  size_t   head_ = 0;
  size_t   count_ = 0;
  uint32_t droppedTotal_ = 0;
  uint32_t droppedUnreported_ = 0;
};

}  // namespace tel
