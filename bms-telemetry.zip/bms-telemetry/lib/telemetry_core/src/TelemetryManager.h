// TelemetryManager.h — routes events either straight to the cloud (LIVE) or
// into the offline queue, and replays the queue in order when the link is back.
//
// Ordering guarantee: an event is sent live ONLY if the queue is empty.
// While a backlog exists, new events join the back of the queue, so the cloud
// always receives events in the order they happened (seq is strictly
// increasing at the receiver, gaps only where the queue had to drop).
//
// Replayed events are sent through a different publisher call so the
// dashboard can show them separately from live values (and stamp them with
// their original time).
#pragma once

#include "EventQueue.h"
#include "TelemetryTypes.h"

namespace tel {

class IPublisher {
 public:
  virtual ~IPublisher() = default;
  // Link is up AND there is send budget right now.
  virtual bool canPublish() = 0;
  virtual bool publishLive(const TelemetryEvent& e) = 0;
  // ageMs = how old the event is; remaining = events still queued after it.
  virtual bool publishReplay(const TelemetryEvent& e, uint32_t ageMs, size_t remaining) = 0;
};

template <size_t QN>
class TelemetryManager {
 public:
  explicit TelemetryManager(IPublisher& pub, uint32_t replayIntervalMs = 400)
      : pub_(pub), replayIntervalMs_(replayIntervalMs) {}

  // Returns true if the event went out live, false if it was queued.
  bool submit(TelemetryEvent e, bool online, uint32_t nowMs) {
    e.seq = ++seq_;
    last_ = e;
    if (online && q_.empty() && pub_.canPublish() && pub_.publishLive(e)) {
      ++sentLive_;
      return true;
    }
    q_.push(e);
    ++queuedTotal_;
    (void)nowMs;
    return false;
  }

  // Call every loop iteration. Sends at most one queued event per
  // replayInterval so the cloud's rate limit is respected.
  void service(bool online, uint32_t nowMs) {
    if (!online || q_.empty()) return;
    if (nowMs - lastReplayMs_ < replayIntervalMs_) return;
    if (!pub_.canPublish()) return;

    const TelemetryEvent* f = q_.front();
    const uint32_t age = nowMs - f->tMs;
    if (!pub_.publishReplay(*f, age, q_.size() - 1)) return;  // retry later, same event

    q_.pop();
    ++sentReplay_;
    lastReplayMs_ = nowMs;
    lastReplayAgeMs_ = age;

    if (q_.empty()) {
      drained_ = true;
      if (q_.droppedUnreported()) {
        TelemetryEvent ov = last_;
        ov.type = EventType::QueueOverflow;
        ov.tMs = nowMs;
        ov.arg = (int32_t)q_.droppedUnreported();
        q_.markDropsReported();
        submit(ov, online, nowMs);
      }
    }
  }

  DataMode mode(bool online) const {
    if (!online) return DataMode::Offline;
    return q_.empty() ? DataMode::Live : DataMode::Replaying;
  }

  // True once after the backlog has been fully sent.
  bool consumeDrained() {
    const bool d = drained_;
    drained_ = false;
    return d;
  }

  size_t   depth() const { return q_.size(); }
  size_t   capacity() const { return q_.capacity(); }
  uint32_t dropped() const { return q_.droppedTotal(); }
  uint32_t sentLive() const { return sentLive_; }
  uint32_t sentReplay() const { return sentReplay_; }
  uint32_t queuedTotal() const { return queuedTotal_; }
  uint32_t lastSeq() const { return seq_; }
  uint32_t lastReplayAgeMs() const { return lastReplayAgeMs_; }
  uint32_t oldestAgeMs(uint32_t nowMs) const {
    return q_.empty() ? 0 : nowMs - q_.front()->tMs;
  }
  const EventQueue<QN>& queue() const { return q_; }

 private:
  IPublisher&    pub_;
  EventQueue<QN> q_;
  uint32_t replayIntervalMs_;
  uint32_t seq_ = 0;
  uint32_t lastReplayMs_ = 0;
  uint32_t lastReplayAgeMs_ = 0;
  uint32_t sentLive_ = 0;
  uint32_t sentReplay_ = 0;
  uint32_t queuedTotal_ = 0;
  bool     drained_ = false;
  TelemetryEvent last_;
};

}  // namespace tel
