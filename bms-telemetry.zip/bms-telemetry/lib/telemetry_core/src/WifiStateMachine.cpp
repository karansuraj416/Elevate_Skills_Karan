#include "WifiStateMachine.h"

namespace tel {

const char* netStateName(NetState s) {
  switch (s) {
    case NetState::Idle:            return "IDLE";
    case NetState::WifiConnecting:  return "WIFI_CONNECTING";
    case NetState::CloudConnecting: return "CLOUD_CONNECTING";
    case NetState::Online:          return "ONLINE";
    case NetState::Backoff:         return "BACKOFF";
    case NetState::ForcedOffline:   return "FORCED_OFFLINE";
  }
  return "?";
}

void WifiStateMachine::start(uint32_t nowMs) {
  offline_ = true;
  offlineSinceMs_ = nowMs;
  backoffMs_ = 0;
  enter(NetState::Idle, nowMs);
}

void WifiStateMachine::enter(NetState s, uint32_t nowMs) {
  state_ = s;
  enteredMs_ = nowMs;
}

uint32_t WifiStateMachine::jitter(uint32_t range) {
  if (range == 0) return 0;
  rng_ = rng_ * 1664525u + 1013904223u;  // LCG; deterministic for tests
  return (rng_ >> 8) % range;
}

void WifiStateMachine::enterBackoff(uint32_t nowMs) {
  if (backoffMs_ == 0) backoffMs_ = cfg_.backoffMinMs;
  else backoffMs_ = (backoffMs_ * 2 > cfg_.backoffMaxMs) ? cfg_.backoffMaxMs : backoffMs_ * 2;
  backoffDelayMs_ = backoffMs_ + jitter(backoffMs_ / 5 + 1);
  enter(NetState::Backoff, nowMs);
}

void WifiStateMachine::linkLost(uint32_t nowMs) {
  if (!offline_) {
    offline_ = true;
    offlineSinceMs_ = nowMs;
    ++disconnects_;
  }
}

void WifiStateMachine::tick(uint32_t nowMs) {
  const uint32_t inState = nowMs - enteredMs_;

  switch (state_) {
    case NetState::Idle:
      ++attempts_;
      drv_.wifiBegin();
      enter(NetState::WifiConnecting, nowMs);
      break;

    case NetState::WifiConnecting:
      if (drv_.wifiConnected()) {
        drv_.cloudBegin();
        enter(NetState::CloudConnecting, nowMs);
      } else if (inState >= cfg_.wifiTimeoutMs) {
        drv_.wifiDisconnect();
        enterBackoff(nowMs);
      }
      break;

    case NetState::CloudConnecting:
      if (!drv_.wifiConnected()) {
        drv_.cloudDisconnect();
        drv_.wifiDisconnect();
        enterBackoff(nowMs);
        break;
      }
      drv_.cloudService();
      if (drv_.cloudConnected()) {
        enter(NetState::Online, nowMs);
        backoffMs_ = 0;
        if (offline_) {
          offline_ = false;
          if (everOnline_) {
            lastOutageMs_ = nowMs - offlineSinceMs_;
            restoredPending_ = true;
          }
        }
        everOnline_ = true;
      } else if (inState >= cfg_.cloudTimeoutMs) {
        drv_.cloudDisconnect();
        enterBackoff(nowMs);
      }
      break;

    case NetState::Online:
      if (!drv_.wifiConnected()) {
        linkLost(nowMs);
        drv_.cloudDisconnect();
        drv_.wifiDisconnect();
        enterBackoff(nowMs);
        break;
      }
      drv_.cloudService();
      if (!drv_.cloudConnected()) {
        // Wi-Fi is fine, only the cloud session dropped: log in again.
        linkLost(nowMs);
        drv_.cloudBegin();
        enter(NetState::CloudConnecting, nowMs);
      }
      break;

    case NetState::Backoff:
      if (inState >= backoffDelayMs_) {
        ++attempts_;
        if (drv_.wifiConnected()) {
          drv_.cloudBegin();
          enter(NetState::CloudConnecting, nowMs);
        } else {
          drv_.wifiBegin();
          enter(NetState::WifiConnecting, nowMs);
        }
      }
      break;

    case NetState::ForcedOffline:
      if (forcedDurationMs_ && inState >= forcedDurationMs_) {
        backoffMs_ = 0;
        enter(NetState::Idle, nowMs);
      }
      break;
  }

  // RSSI is sampled whenever we are associated, at a fixed slow rate.
  if ((state_ == NetState::Online || state_ == NetState::CloudConnecting) &&
      nowMs - lastRssiMs_ >= cfg_.rssiPeriodMs) {
    lastRssiMs_ = nowMs;
    rssi_.addSample(drv_.rssi());
  }
}

void WifiStateMachine::forceOffline(uint32_t nowMs, uint32_t durationMs) {
  drv_.cloudDisconnect();
  drv_.wifiDisconnect();
  linkLost(nowMs);
  forcedDurationMs_ = durationMs;
  enter(NetState::ForcedOffline, nowMs);
}

void WifiStateMachine::endForcedOffline(uint32_t nowMs) {
  if (state_ == NetState::ForcedOffline) {
    backoffMs_ = 0;
    enter(NetState::Idle, nowMs);
  }
}

uint32_t WifiStateMachine::offlineForMs(uint32_t nowMs) const {
  return offline_ ? nowMs - offlineSinceMs_ : 0;
}

uint32_t WifiStateMachine::forcedRemainingMs(uint32_t nowMs) const {
  if (state_ != NetState::ForcedOffline || forcedDurationMs_ == 0) return 0;
  const uint32_t in = nowMs - enteredMs_;
  return in >= forcedDurationMs_ ? 0 : forcedDurationMs_ - in;
}

bool WifiStateMachine::consumeRestored(uint32_t& outageMs) {
  if (!restoredPending_) return false;
  restoredPending_ = false;
  outageMs = lastOutageMs_;
  return true;
}

}  // namespace tel
