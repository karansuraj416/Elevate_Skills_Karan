#include "TelemetryTypes.h"

#include <stdio.h>
#include <string.h>

namespace tel {

const char* faultsToString(uint16_t faults, char* buf, size_t len) {
  if (!buf || len == 0) return buf;
  buf[0] = '\0';
  if (faults == FAULT_NONE) {
    snprintf(buf, len, "OK");
    return buf;
  }
  struct { uint16_t bit; const char* name; } names[] = {
      {FAULT_OVERVOLT, "OV"}, {FAULT_UNDERVOLT, "UV"},
      {FAULT_IMBALANCE, "IMB"}, {FAULT_SENSOR, "SENSOR"}};
  size_t used = 0;
  for (auto& n : names) {
    if (!(faults & n.bit)) continue;
    int w = snprintf(buf + used, len - used, "%s%s", used ? "+" : "", n.name);
    if (w < 0 || (size_t)w >= len - used) break;
    used += (size_t)w;
  }
  return buf;
}

CellStats computeStats(const CellSnapshot& s) {
  CellStats st;
  st.count = s.count > kMaxCells ? kMaxCells : s.count;
  if (st.count == 0) return st;
  uint32_t sum = 0;
  st.minMv = s.mv[0];
  st.maxMv = s.mv[0];
  for (uint8_t i = 0; i < st.count; ++i) {
    const uint16_t v = s.mv[i];
    sum += v;
    if (v < st.minMv) { st.minMv = v; st.minIdx = i; }
    if (v > st.maxMv) { st.maxMv = v; st.maxIdx = i; }
  }
  st.packMv = sum;
  st.avgMv = (uint16_t)(sum / st.count);
  st.deltaMv = (uint16_t)(st.maxMv - st.minMv);
  return st;
}

CellStats statsOf(const TelemetryEvent& e) {
  CellSnapshot s;
  s.tMs = e.tMs;
  s.count = e.cellCount;
  memcpy(s.mv, e.mv, sizeof(s.mv));
  return computeStats(s);
}

Priority priorityOf(EventType t) {
  switch (t) {
    case EventType::FaultSet:
    case EventType::FaultClear:
    case EventType::RelayChange:
    case EventType::LinkRestored:
    case EventType::QueueOverflow:
    case EventType::OperatorReset:
    case EventType::Boot:
      return Priority::Critical;
    default:
      return Priority::Normal;
  }
}

const char* eventName(EventType t) {
  switch (t) {
    case EventType::Boot:           return "BOOT";
    case EventType::CellChange:     return "CELL_CHANGE";
    case EventType::ExtremesChange: return "EXTREMES";
    case EventType::FaultSet:       return "FAULT_SET";
    case EventType::FaultClear:     return "FAULT_CLEAR";
    case EventType::RelayChange:    return "RELAY";
    case EventType::LinkRestored:   return "LINK_RESTORED";
    case EventType::LinkQuality:    return "LINK_QUALITY";
    case EventType::Heartbeat:      return "HEARTBEAT";
    case EventType::QueueOverflow:  return "QUEUE_OVERFLOW";
    case EventType::OperatorReset:  return "OPERATOR_RESET";
  }
  return "?";
}

const char* linkQualityName(LinkQuality q) {
  switch (q) {
    case LinkQuality::Unknown:   return "UNKNOWN";
    case LinkQuality::Bad:       return "BAD";
    case LinkQuality::Poor:      return "POOR";
    case LinkQuality::Fair:      return "FAIR";
    case LinkQuality::Good:      return "GOOD";
    case LinkQuality::Excellent: return "EXCELLENT";
  }
  return "?";
}

const char* dataModeName(DataMode m) {
  switch (m) {
    case DataMode::Live:      return "LIVE";
    case DataMode::Replaying: return "REPLAY";
    case DataMode::Offline:   return "OFFLINE";
  }
  return "?";
}

}  // namespace tel
