// FaultManager.h — debounced cell fault detection and relay (contactor) logic.
//
// Each fault has a SET threshold and a separate CLEAR threshold (hysteresis)
// and must be seen for `debounceSamples` consecutive samples before it changes
// state, so ADC noise cannot chatter the relay.
//
// Relay rule: the relay is CLOSED (pack connected) only when
//   - the start-up self check has passed (N clean samples after boot), and
//   - no fault is active, and
//   - (if latching is enabled) the operator has acknowledged past faults.
// Protection never depends on the network: this runs in its own task.
#pragma once

#include "TelemetryTypes.h"

namespace tel {

struct FaultConfig {
  uint16_t ovSetMv      = 4250;  // over-voltage trips above this
  uint16_t ovClearMv    = 4150;  // ...and clears below this
  uint16_t uvSetMv      = 3000;  // under-voltage trips below this
  uint16_t uvClearMv    = 3100;  // ...and clears above this
  uint16_t imbSetMv     = 150;   // imbalance trips above this spread
  uint16_t imbClearMv   = 100;   // ...and clears below this
  uint16_t sensorMinMv  = 500;   // anything outside [min,max] = sensor fault
  uint16_t sensorMaxMv  = 4800;
  uint8_t  debounceSamples = 3;  // consecutive samples to set or clear
  uint8_t  startupCleanSamples = 5;
  bool     latchRelay   = true;  // require operator reset after a trip
};

class FaultManager {
 public:
  explicit FaultManager(const FaultConfig& cfg = FaultConfig()) : cfg_(cfg) {}

  void update(const CellSnapshot& s);

  uint16_t active() const { return active_; }
  uint16_t latched() const { return latched_; }
  bool     relayClosed() const { return relayClosed_; }
  uint8_t  faultCell() const { return faultCell_; }  // 1-based, 0 = none
  bool     startupOk() const { return startupOk_; }

  // Operator acknowledges the trip. Succeeds only when no fault is active.
  bool requestReset();

  const FaultConfig& config() const { return cfg_; }

 private:
  struct Debounce {
    uint8_t setCount = 0;
    uint8_t clearCount = 0;
  };
  void step(uint16_t bit, bool setCond, bool clearCond, Debounce& d);

  FaultConfig cfg_;
  Debounce ov_, uv_, imb_, sensor_;
  uint16_t active_ = 0;
  uint16_t latched_ = 0;
  uint8_t  faultCell_ = 0;
  uint8_t  cleanCount_ = 0;
  bool     startupOk_ = false;
  bool     relayClosed_ = false;
};

}  // namespace tel
