#include "EventDetector.h"

#include <string.h>

namespace tel {

TelemetryEvent EventDetector::make(EventType t, const DetectorInput& in, uint32_t nowMs,
                                   int32_t arg) const {
  TelemetryEvent e;
  e.tMs = nowMs;
  e.type = t;
  e.cellCount = in.cells.count > kMaxCells ? kMaxCells : in.cells.count;
  memcpy(e.mv, in.cells.mv, sizeof(e.mv));
  e.faults = in.faults;
  e.faultCell = in.faultCell;
  e.relayClosed = in.relayClosed;
  e.rssi = in.rssi;
  e.arg = arg;
  return e;
}

void EventDetector::remember(const DetectorInput& in, uint32_t nowMs) {
  const CellStats st = computeStats(in.cells);
  memcpy(lastMv_, in.cells.mv, sizeof(lastMv_));
  lastMinIdx_ = st.minIdx;
  lastMaxIdx_ = st.maxIdx;
  lastFaults_ = in.faults;
  lastRelay_ = in.relayClosed;
  lastEventMs_ = nowMs;
}

size_t EventDetector::evaluate(const DetectorInput& in, uint32_t nowMs, TelemetryEvent* out,
                               size_t maxOut) {
  if (!out || maxOut == 0) return 0;
  size_t n = 0;
  auto emit = [&](EventType t, int32_t arg) {
    if (n < maxOut) out[n++] = make(t, in, nowMs, arg);
  };

  if (!started_) {
    started_ = true;
    emit(EventType::Boot, 0);
    remember(in, nowMs);
    lastLink_ = in.link;
    lastNormalMs_ = nowMs;
    return n;
  }

  const CellStats st = computeStats(in.cells);
  const uint8_t cells = st.count;

  // ---- critical: always immediate ------------------------------------
  const uint16_t newly = (uint16_t)(in.faults & ~lastFaults_);
  const uint16_t cleared = (uint16_t)(lastFaults_ & ~in.faults);
  if (newly) emit(EventType::FaultSet, newly);
  if (cleared) emit(EventType::FaultClear, cleared);
  if (in.relayClosed != lastRelay_) emit(EventType::RelayChange, in.relayClosed ? 1 : 0);

  // ---- normal: rate limited -------------------------------------------
  bool normalEmitted = false;
  if (nowMs - lastNormalMs_ >= cfg_.minIntervalMs + throttleMs_) {
    bool extremes = false;
    if (cells > 0 && lastMinIdx_ < cells && lastMaxIdx_ < cells) {
      const bool newWeakest = st.minIdx != lastMinIdx_ &&
          (int32_t)in.cells.mv[lastMinIdx_] - (int32_t)st.minMv >= cfg_.extremesHystMv;
      const bool newStrongest = st.maxIdx != lastMaxIdx_ &&
          (int32_t)st.maxMv - (int32_t)in.cells.mv[lastMaxIdx_] >= cfg_.extremesHystMv;
      extremes = newWeakest || newStrongest;
    }

    int bigIdx = -1;
    int32_t bigDelta = 0;
    for (uint8_t i = 0; i < cells; ++i) {
      int32_t d = (int32_t)in.cells.mv[i] - (int32_t)lastMv_[i];
      if (d < 0) d = -d;
      if (d >= cfg_.cellDeadbandMv && d > bigDelta) { bigDelta = d; bigIdx = i; }
    }

    if (extremes) {
      emit(EventType::ExtremesChange, ((st.minIdx + 1) << 8) | (st.maxIdx + 1));
      normalEmitted = true;
    } else if (bigIdx >= 0 && n == 0) {
      // A critical event in the same cycle already carries the new voltages.
      emit(EventType::CellChange, bigIdx + 1);
      normalEmitted = true;
    }

    if (in.link != lastLink_) {
      emit(EventType::LinkQuality, (int32_t)in.link);
      lastLink_ = in.link;
      normalEmitted = true;
    }
  }

  // ---- heartbeat ---------------------------------------------------------
  if (n == 0 && nowMs - lastEventMs_ >= cfg_.heartbeatMs) {
    emit(EventType::Heartbeat, 0);
    normalEmitted = true;
  }

  if (n > 0) remember(in, nowMs);
  if (normalEmitted) lastNormalMs_ = nowMs;
  return n;
}

}  // namespace tel
