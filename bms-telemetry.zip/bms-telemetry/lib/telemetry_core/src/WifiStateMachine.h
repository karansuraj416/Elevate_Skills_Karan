// WifiStateMachine.h — non-blocking Wi-Fi + cloud (Blynk) connection manager.
//
//            +--------+   begin    +----------------+  got IP   +-----------------+
//   start -> |  IDLE  | ---------> | WIFI_CONNECTING| --------> | CLOUD_CONNECTING|
//            +--------+            +----------------+           +-----------------+
//                ^                   | timeout                    | timeout |  | logged in
//                |                   v                            v         |  v
//                |               +---------+  delay elapsed   +---------+   | +--------+
//                |               | BACKOFF | <--------------- |         |   | | ONLINE |
//                |               +---------+ ---------------> (WIFI_CONNECTING)| +--------+
//                |                    ^                                       |   |  |
//                |                    +---- Wi-Fi lost -----------------------+---+  |
//                |                                         cloud lost, Wi-Fi ok -----+--> CLOUD_CONNECTING
//         FORCED_OFFLINE (demo outage) --- timer ends ---> IDLE
//
// tick() never waits: every state checks a condition or a timer and returns.
// Retry delay grows exponentially (1 s, 2 s, 4 s ... 30 s) with jitter so a
// fleet of devices does not hammer the AP at the same instant.
#pragma once

#include "RssiMonitor.h"
#include "TelemetryTypes.h"

namespace tel {

// Hardware/library abstraction so the state machine can be unit tested.
class INetDriver {
 public:
  virtual ~INetDriver() = default;
  virtual void wifiBegin() = 0;        // start association (must not block)
  virtual bool wifiConnected() = 0;    // associated AND has an IP
  virtual void wifiDisconnect() = 0;
  virtual void cloudBegin() = 0;       // start the cloud login (must not block)
  virtual bool cloudConnected() = 0;
  virtual void cloudService() = 0;     // pump the protocol (Blynk.run)
  virtual void cloudDisconnect() = 0;
  virtual int  rssi() = 0;             // dBm
};

enum class NetState : uint8_t {
  Idle = 0,
  WifiConnecting,
  CloudConnecting,
  Online,
  Backoff,
  ForcedOffline,
};
const char* netStateName(NetState s);

struct NetConfig {
  uint32_t wifiTimeoutMs  = 15000;
  uint32_t cloudTimeoutMs = 12000;
  uint32_t backoffMinMs   = 1000;
  uint32_t backoffMaxMs   = 30000;
  uint32_t rssiPeriodMs   = 1000;
};

class WifiStateMachine {
 public:
  WifiStateMachine(INetDriver& drv, RssiMonitor& rssi, const NetConfig& cfg = NetConfig())
      : drv_(drv), rssi_(rssi), cfg_(cfg) {}

  void start(uint32_t nowMs);
  void tick(uint32_t nowMs);

  // Demo / maintenance: drop the link on purpose. durationMs = 0 -> until
  // endForcedOffline() is called.
  void forceOffline(uint32_t nowMs, uint32_t durationMs);
  void endForcedOffline(uint32_t nowMs);

  NetState state() const { return state_; }
  bool     online() const { return state_ == NetState::Online; }
  uint32_t timeInStateMs(uint32_t nowMs) const { return nowMs - enteredMs_; }

  uint32_t disconnects() const { return disconnects_; }
  uint32_t attempts() const { return attempts_; }
  uint32_t lastOutageMs() const { return lastOutageMs_; }
  uint32_t currentBackoffMs() const { return backoffMs_; }
  uint32_t offlineForMs(uint32_t nowMs) const;   // 0 when online
  uint32_t forcedRemainingMs(uint32_t nowMs) const;

  // True once each time the link comes back after having been online.
  bool consumeRestored(uint32_t& outageMs);

 private:
  void enter(NetState s, uint32_t nowMs);
  void enterBackoff(uint32_t nowMs);
  void linkLost(uint32_t nowMs);
  uint32_t jitter(uint32_t range);

  INetDriver&  drv_;
  RssiMonitor& rssi_;
  NetConfig    cfg_;

  NetState state_ = NetState::Idle;
  uint32_t enteredMs_ = 0;
  uint32_t backoffMs_ = 0;
  uint32_t backoffDelayMs_ = 0;
  uint32_t forcedDurationMs_ = 0;
  uint32_t lastRssiMs_ = 0;

  bool     everOnline_ = false;
  bool     offline_ = true;
  uint32_t offlineSinceMs_ = 0;
  bool     restoredPending_ = false;
  uint32_t lastOutageMs_ = 0;
  uint32_t disconnects_ = 0;
  uint32_t attempts_ = 0;
  uint32_t rng_ = 0x2545F491u;
};

}  // namespace tel
