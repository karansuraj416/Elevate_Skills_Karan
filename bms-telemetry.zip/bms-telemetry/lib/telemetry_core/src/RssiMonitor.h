// RssiMonitor.h — smooths Wi-Fi RSSI and grades the link.
//
// RSSI from the radio jumps by several dB between reads, so it is filtered
// with an exponential moving average and graded into classes with a dead
// zone (hysteresis) at each boundary, so the class does not flicker.
//
//   Excellent >= -55 dBm | Good >= -67 | Fair >= -75 | Poor >= -85 | Bad
#pragma once

#include "TelemetryTypes.h"

namespace tel {

class RssiMonitor {
 public:
  explicit RssiMonitor(float alpha = 0.25f, float hysteresisDb = 3.0f)
      : alpha_(alpha), hyst_(hysteresisDb) {}

  void addSample(int rssiDbm);
  void reset();  // forget history (e.g. after reconnecting to another AP)

  bool        hasData() const { return samples_ > 0; }
  int8_t      rssi() const;            // filtered, rounded dBm (0 if none)
  LinkQuality quality() const { return quality_; }
  uint8_t     percent() const;         // 0..100, linear between -100 and -50 dBm
  int8_t      minSeen() const { return minSeen_; }
  uint32_t    samples() const { return samples_; }

  // Recommended extra spacing for non-critical telemetry at this quality.
  uint32_t suggestedThrottleMs() const;

 private:
  static LinkQuality classify(float dbm);
  float    alpha_;
  float    hyst_;
  float    ema_ = 0.0f;
  uint32_t samples_ = 0;
  int8_t   minSeen_ = 0;
  LinkQuality quality_ = LinkQuality::Unknown;
};

}  // namespace tel
