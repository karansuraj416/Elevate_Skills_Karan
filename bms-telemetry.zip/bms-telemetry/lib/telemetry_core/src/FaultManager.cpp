#include "FaultManager.h"

namespace tel {

void FaultManager::step(uint16_t bit, bool setCond, bool clearCond, Debounce& d) {
  const bool isActive = (active_ & bit) != 0;
  if (!isActive) {
    d.clearCount = 0;
    d.setCount = setCond ? (uint8_t)(d.setCount + 1) : 0;
    if (d.setCount >= cfg_.debounceSamples) {
      active_ |= bit;
      d.setCount = 0;
    }
  } else {
    d.setCount = 0;
    d.clearCount = clearCond ? (uint8_t)(d.clearCount + 1) : 0;
    if (d.clearCount >= cfg_.debounceSamples) {
      active_ &= (uint16_t)~bit;
      d.clearCount = 0;
    }
  }
}

void FaultManager::update(const CellSnapshot& s) {
  const uint8_t n = s.count > kMaxCells ? kMaxCells : s.count;

  // Classify readings. Implausible readings are a sensor fault and are kept
  // out of the OV/UV/imbalance checks (an open wire must not look like UV).
  bool anyBad = false;
  uint8_t firstBad = 0;
  uint8_t valid = 0;
  uint16_t vMin = 0xFFFF, vMax = 0;
  uint8_t iMin = 0, iMax = 0;
  for (uint8_t i = 0; i < n; ++i) {
    const uint16_t v = s.mv[i];
    if (v < cfg_.sensorMinMv || v > cfg_.sensorMaxMv) {
      if (!anyBad) firstBad = (uint8_t)(i + 1);
      anyBad = true;
      continue;
    }
    ++valid;
    if (v < vMin) { vMin = v; iMin = i; }
    if (v > vMax) { vMax = v; iMax = i; }
  }
  if (n == 0) { anyBad = true; firstBad = 0; }

  const bool have = valid > 0;
  const uint16_t spread = have ? (uint16_t)(vMax - vMin) : 0;

  step(FAULT_SENSOR,    anyBad,                          !anyBad,                        sensor_);
  step(FAULT_OVERVOLT,  have && vMax > cfg_.ovSetMv,     !have || vMax < cfg_.ovClearMv, ov_);
  step(FAULT_UNDERVOLT, have && vMin < cfg_.uvSetMv,     !have || vMin > cfg_.uvClearMv, uv_);
  step(FAULT_IMBALANCE, valid >= 2 && spread > cfg_.imbSetMv,
                        valid < 2 || spread < cfg_.imbClearMv, imb_);

  // Most specific culprit for display.
  if (active_ & FAULT_SENSOR)         faultCell_ = firstBad;
  else if (active_ & FAULT_OVERVOLT)  faultCell_ = (uint8_t)(iMax + 1);
  else if (active_ & FAULT_UNDERVOLT) faultCell_ = (uint8_t)(iMin + 1);
  else if (active_ & FAULT_IMBALANCE) faultCell_ = (uint8_t)(iMin + 1);
  else                                faultCell_ = 0;

  latched_ |= active_;

  // Start-up self check: relay stays open until readings are clean.
  if (!startupOk_) {
    const bool clean = active_ == 0 && !anyBad && valid == n && n > 0 &&
                       vMax <= cfg_.ovSetMv && vMin >= cfg_.uvSetMv &&
                       spread <= cfg_.imbSetMv;
    cleanCount_ = clean ? (uint8_t)(cleanCount_ + 1) : 0;
    if (cleanCount_ >= cfg_.startupCleanSamples) startupOk_ = true;
  }

  relayClosed_ = startupOk_ && active_ == 0 && (!cfg_.latchRelay || latched_ == 0);
}

bool FaultManager::requestReset() {
  if (active_ != 0) return false;
  latched_ = 0;
  relayClosed_ = startupOk_;
  return true;
}

}  // namespace tel
