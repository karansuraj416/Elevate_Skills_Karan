#include "DemoSupport.h"

#include <math.h>

namespace tel {

// ------------------------------------------------------- simulated pack ---
static const uint16_t kBaseMv[kMaxCells] = {3712, 3705, 3694, 3709, 3701, 3716, 3698, 3707};

SimulatedPack::SimulatedPack(uint8_t cells, uint32_t seed)
    : cells_(cells > kMaxCells ? kMaxCells : cells), rng_(seed ? seed : 1) {}

int16_t SimulatedPack::noise() {
  rng_ = rng_ * 1103515245u + 12345u;
  return (int16_t)((rng_ >> 16) % 7) - 3;  // -3..+3 mV
}

void SimulatedPack::sample(uint32_t nowMs, CellSnapshot& out) {
  const double t = (double)nowMs;
  const double load = 35.0 * sin(2.0 * 3.14159265358979 * t / 360000.0);
  // Cell 3 self-discharges faster: -1.5 mV/min, capped at -80 mV.
  double weakDrift = -1.5 * (t / 60000.0);
  if (weakDrift < -80.0) weakDrift = -80.0;

  out.tMs = nowMs;
  out.count = cells_;
  for (uint8_t i = 0; i < kMaxCells; ++i) {
    if (i >= cells_) { out.mv[i] = 0; continue; }
    double v = kBaseMv[i] + load + noise();
    if (i == 2) v += weakDrift;
    out.mv[i] = (uint16_t)(v + 0.5);
  }
}

// ------------------------------------------------------ fault injection ---
const char* injectName(InjectKind k) {
  switch (k) {
    case InjectKind::None:      return "NONE";
    case InjectKind::OverVolt:  return "OVER_VOLTAGE";
    case InjectKind::UnderVolt: return "UNDER_VOLTAGE";
    case InjectKind::Imbalance: return "IMBALANCE";
    case InjectKind::OpenWire:  return "OPEN_WIRE";
  }
  return "?";
}

void applyInjection(CellSnapshot& s, const Injection& inj) {
  if (inj.kind == InjectKind::None || inj.cell == 0 || inj.cell > s.count) return;
  uint16_t& v = s.mv[inj.cell - 1];
  switch (inj.kind) {
    case InjectKind::OverVolt:  v = 4380; break;                      // > 4.25 V
    case InjectKind::UnderVolt: v = 2850; break;                      // < 3.00 V
    case InjectKind::Imbalance: v = (uint16_t)(v > 260 ? v - 230 : 0); break;  // spread > 150 mV
    case InjectKind::OpenWire:  v = 120; break;                       // implausible reading
    case InjectKind::None: break;
  }
}

// ------------------------------------------------------------ scenarios ---
#define S(ms) ((uint32_t)(ms) * 1000u)

static const ScenarioStep kFault[] = {
    {S(0),  StepAction::Log, InjectKind::None, 0, 0, "FAULT DEMO: start (link online)"},
    {S(5),  StepAction::Inject, InjectKind::Imbalance, 3, 0, "Inject IMBALANCE on cell 3"},
    {S(20), StepAction::ClearInjection, InjectKind::None, 0, 0, "Remove fault (relay stays latched open)"},
    {S(28), StepAction::Inject, InjectKind::OverVolt, 2, 0, "Inject OVER-VOLTAGE on cell 2"},
    {S(40), StepAction::ClearInjection, InjectKind::None, 0, 0, "Remove fault"},
    {S(48), StepAction::OperatorReset, InjectKind::None, 0, 0, "Operator reset -> relay closes"},
    {S(55), StepAction::End, InjectKind::None, 0, 0, "FAULT DEMO: complete"},
};

static const ScenarioStep kOutage[] = {
    {S(0),  StepAction::Log, InjectKind::None, 0, 0, "OUTAGE DEMO: start"},
    {S(3),  StepAction::NetOutage, InjectKind::None, 0, 60000, "Network outage for 60 s"},
    {S(13), StepAction::Inject, InjectKind::UnderVolt, 1, 0, "While offline: UNDER-VOLTAGE on cell 1"},
    {S(30), StepAction::ClearInjection, InjectKind::None, 0, 0, "While offline: fault removed"},
    {S(38), StepAction::OperatorReset, InjectKind::None, 0, 0, "While offline: operator reset (local button)"},
    {S(100),StepAction::End, InjectKind::None, 0, 0, "OUTAGE DEMO: complete"},
};

static const ScenarioStep kFull[] = {
    {S(0),   StepAction::Log, InjectKind::None, 0, 0, "FULL DEMO: start (link online)"},
    {S(5),   StepAction::Inject, InjectKind::Imbalance, 3, 0, "Live: inject IMBALANCE on cell 3"},
    {S(20),  StepAction::ClearInjection, InjectKind::None, 0, 0, "Live: fault removed (relay latched open)"},
    {S(26),  StepAction::OperatorReset, InjectKind::None, 0, 0, "Live: operator reset -> relay closes"},
    {S(35),  StepAction::NetOutage, InjectKind::None, 0, 60000, "Network outage for 60 s"},
    {S(45),  StepAction::Inject, InjectKind::OverVolt, 2, 0, "Offline: inject OVER-VOLTAGE on cell 2"},
    {S(60),  StepAction::ClearInjection, InjectKind::None, 0, 0, "Offline: fault removed"},
    {S(66),  StepAction::OperatorReset, InjectKind::None, 0, 0, "Offline: operator reset (local button)"},
    {S(140), StepAction::End, InjectKind::None, 0, 0, "FULL DEMO: complete"},
};
#undef S

const char* scenarioName(ScenarioId id) {
  switch (id) {
    case ScenarioId::None:   return "NONE";
    case ScenarioId::Fault:  return "FAULT";
    case ScenarioId::Outage: return "OUTAGE";
    case ScenarioId::Full:   return "FULL";
  }
  return "?";
}

const ScenarioStep* ScenarioRunner::steps(ScenarioId id) {
  switch (id) {
    case ScenarioId::Fault:  return kFault;
    case ScenarioId::Outage: return kOutage;
    case ScenarioId::Full:   return kFull;
    default:                 return nullptr;
  }
}

void ScenarioRunner::start(ScenarioId id, uint32_t nowMs) {
  steps_ = steps(id);
  id_ = steps_ ? id : ScenarioId::None;
  startMs_ = nowMs;
  next_ = 0;
}

void ScenarioRunner::stop() {
  steps_ = nullptr;
  id_ = ScenarioId::None;
}

void ScenarioRunner::tick(uint32_t nowMs) {
  while (steps_) {
    const ScenarioStep& st = steps_[next_];
    if (nowMs - startMs_ < st.atMs) return;
    if (st.note) act_.scenarioLog(st.note);
    switch (st.action) {
      case StepAction::Log: break;
      case StepAction::Inject: act_.scenarioInject(st.kind, st.cell); break;
      case StepAction::ClearInjection: act_.scenarioClearInjection(); break;
      case StepAction::OperatorReset: act_.scenarioOperatorReset(); break;
      case StepAction::NetOutage: act_.scenarioNetOutage(st.value); break;
      case StepAction::NetRestore: act_.scenarioNetRestore(); break;
      case StepAction::End: stop(); return;
    }
    ++next_;
  }
}

}  // namespace tel
