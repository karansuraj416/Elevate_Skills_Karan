#include "RssiMonitor.h"

namespace tel {

LinkQuality RssiMonitor::classify(float dbm) {
  if (dbm >= -55.0f) return LinkQuality::Excellent;
  if (dbm >= -67.0f) return LinkQuality::Good;
  if (dbm >= -75.0f) return LinkQuality::Fair;
  if (dbm >= -85.0f) return LinkQuality::Poor;
  return LinkQuality::Bad;
}

void RssiMonitor::addSample(int rssiDbm) {
  // The ESP32 reports 0 (or garbage) when not associated; ignore it.
  if (rssiDbm >= 0 || rssiDbm < -120) return;
  const float x = (float)rssiDbm;
  if (samples_ == 0) {
    ema_ = x;
    minSeen_ = (int8_t)rssiDbm;
  } else {
    ema_ += alpha_ * (x - ema_);
    if (rssiDbm < minSeen_) minSeen_ = (int8_t)rssiDbm;
  }
  ++samples_;

  if (quality_ == LinkQuality::Unknown) {
    quality_ = classify(ema_);
    return;
  }
  // Move only once the average is clearly across a boundary.
  const LinkQuality up = classify(ema_ - hyst_);
  const LinkQuality down = classify(ema_ + hyst_);
  if (up > quality_) quality_ = up;
  else if (down < quality_) quality_ = down;
}

void RssiMonitor::reset() {
  samples_ = 0;
  ema_ = 0.0f;
  quality_ = LinkQuality::Unknown;
}

int8_t RssiMonitor::rssi() const {
  if (!samples_) return 0;
  return (int8_t)(ema_ < 0 ? ema_ - 0.5f : ema_ + 0.5f);
}

uint8_t RssiMonitor::percent() const {
  if (!samples_) return 0;
  float p = 2.0f * (ema_ + 100.0f);
  if (p < 0) p = 0;
  if (p > 100) p = 100;
  return (uint8_t)(p + 0.5f);
}

uint32_t RssiMonitor::suggestedThrottleMs() const {
  switch (quality_) {
    case LinkQuality::Poor: return 3000;
    case LinkQuality::Bad:  return 8000;
    default:                return 0;
  }
}

}  // namespace tel
