// DemoSupport.h — simulated battery pack, fault injection and scripted
// demonstration scenarios. Shared by the firmware (SIM mode and the
// dashboard "Run demo" button) and the host-side simulator.
#pragma once

#include "TelemetryTypes.h"

namespace tel {

// ------------------------------------------------------- simulated pack ---
// Deterministic model of a series Li-ion pack: per-cell offsets, a slow
// load cycle (+/- 35 mV over 6 min), small noise and one cell that slowly
// loses charge faster than the others (so weakest-cell tracking is visible).
class SimulatedPack {
 public:
  explicit SimulatedPack(uint8_t cells = 4, uint32_t seed = 12345);
  void sample(uint32_t nowMs, CellSnapshot& out);

 private:
  uint8_t  cells_;
  uint32_t rng_;
  int16_t  noise();
};

// ------------------------------------------------------ fault injection ---
enum class InjectKind : uint8_t { None = 0, OverVolt, UnderVolt, Imbalance, OpenWire };
const char* injectName(InjectKind k);

struct Injection {
  InjectKind kind = InjectKind::None;
  uint8_t    cell = 1;  // 1-based target cell
};

// Applied on top of real or simulated readings, before fault evaluation,
// so the protection path is exercised exactly as with a real fault.
void applyInjection(CellSnapshot& s, const Injection& inj);

// ------------------------------------------------------------ scenarios ---
enum class StepAction : uint8_t {
  Log = 0, Inject, ClearInjection, OperatorReset, NetOutage, NetRestore, End
};

struct ScenarioStep {
  uint32_t    atMs;     // offset from scenario start
  StepAction  action;
  InjectKind  kind;     // for Inject
  uint8_t     cell;     // for Inject
  uint32_t    value;    // NetOutage duration ms
  const char* note;     // shown on serial + dashboard log
};

class IScenarioActions {
 public:
  virtual ~IScenarioActions() = default;
  virtual void scenarioLog(const char* text) = 0;
  virtual void scenarioInject(InjectKind k, uint8_t cell) = 0;
  virtual void scenarioClearInjection() = 0;
  virtual void scenarioOperatorReset() = 0;
  virtual void scenarioNetOutage(uint32_t durationMs) = 0;
  virtual void scenarioNetRestore() = 0;
};

enum class ScenarioId : uint8_t { None = 0, Fault, Outage, Full };
const char* scenarioName(ScenarioId id);

class ScenarioRunner {
 public:
  explicit ScenarioRunner(IScenarioActions& act) : act_(act) {}
  void start(ScenarioId id, uint32_t nowMs);
  void stop();
  void tick(uint32_t nowMs);
  bool running() const { return steps_ != nullptr; }
  ScenarioId current() const { return id_; }

  static const ScenarioStep* steps(ScenarioId id);

 private:
  IScenarioActions&   act_;
  const ScenarioStep* steps_ = nullptr;
  ScenarioId          id_ = ScenarioId::None;
  uint32_t            startMs_ = 0;
  uint16_t            next_ = 0;
};

}  // namespace tel
