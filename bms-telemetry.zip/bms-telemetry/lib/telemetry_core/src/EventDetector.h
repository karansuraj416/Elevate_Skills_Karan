// EventDetector.h — decides WHEN telemetry is worth sending.
//
// Nothing is sent on a fixed schedule. An event is produced only when:
//   * a fault bit sets or clears                      (immediate, critical)
//   * the relay changes state                         (immediate, critical)
//   * any cell moves >= deadband from the LAST REPORTED value
//   * a different cell becomes weakest/strongest (with hysteresis)
//   * the Wi-Fi quality class changes
//   * nothing at all was sent for `heartbeatMs` (proof of life)
// Non-critical events are rate limited by `minIntervalMs`; when the radio
// link is poor the application can add extra spacing with setThrottle().
#pragma once

#include "TelemetryTypes.h"

namespace tel {

struct DetectorConfig {
  uint16_t cellDeadbandMv = 20;    // per-cell change that counts as "significant"
  uint16_t extremesHystMv = 10;    // new weakest must be this much below old one
  uint32_t minIntervalMs  = 2000;  // spacing between non-critical events
  uint32_t heartbeatMs    = 60000; // max silence before a heartbeat
};

struct DetectorInput {
  CellSnapshot cells;
  uint16_t     faults = 0;
  uint8_t      faultCell = 0;
  bool         relayClosed = false;
  int8_t       rssi = 0;
  LinkQuality  link = LinkQuality::Unknown;
};

class EventDetector {
 public:
  static constexpr size_t kMaxEventsPerEval = 6;

  explicit EventDetector(const DetectorConfig& cfg = DetectorConfig()) : cfg_(cfg) {}

  // Compare the current state with what was last reported. Writes up to
  // kMaxEventsPerEval events to `out` (critical ones first) and returns how
  // many. Sequence numbers are assigned later by the TelemetryManager.
  size_t evaluate(const DetectorInput& in, uint32_t nowMs, TelemetryEvent* out, size_t maxOut);

  // Extra spacing for non-critical events (e.g. when RSSI is poor).
  void setThrottle(uint32_t extraMs) { throttleMs_ = extraMs; }
  uint32_t throttle() const { return throttleMs_; }

  // Anything emitted outside the detector (operator reset, link restored)
  // also counts as "something was reported" for heartbeat purposes.
  void noteExternalEvent(uint32_t nowMs) { lastEventMs_ = nowMs; }

  const DetectorConfig& config() const { return cfg_; }

 private:
  TelemetryEvent make(EventType t, const DetectorInput& in, uint32_t nowMs, int32_t arg) const;
  void remember(const DetectorInput& in, uint32_t nowMs);

  DetectorConfig cfg_;
  bool     started_ = false;
  uint16_t lastMv_[kMaxCells] = {0};
  uint8_t  lastMinIdx_ = 0, lastMaxIdx_ = 0;
  uint16_t lastFaults_ = 0;
  bool     lastRelay_ = false;
  LinkQuality lastLink_ = LinkQuality::Unknown;
  uint32_t lastEventMs_ = 0;      // any event
  uint32_t lastNormalMs_ = 0;     // last non-critical event
  uint32_t throttleMs_ = 0;
};

}  // namespace tel
