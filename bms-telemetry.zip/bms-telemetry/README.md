# Event-Driven BMS Telemetry with Offline Queue and Live Blynk Dashboard

ESP32 firmware for a battery-pack monitor. It does five things:

* Sends telemetry **only when something meaningful happens**: a fault, a relay
  change, a significant voltage change, a new weakest or strongest cell, a
  link-quality change, or a heartbeat.
* Keeps every event in a **fixed-size offline queue** while Wi-Fi or Blynk is
  down, and replays the queue **in the original order** once the link is back.
* Reconnects with a **non-blocking Wi-Fi / cloud state machine** using
  exponential back-off.
* Monitors **RSSI** (smoothed and graded with hysteresis) and backs off
  non-critical traffic when the link is poor.
* Drives a **Blynk dashboard** with cell voltages, weakest and strongest cell,
  relay, faults, Wi-Fi health and queue depth. **Live data and replayed data
  are kept visibly separate.**

Built-in **fault injection** and **network-outage simulation**, plus scripted
demo scenarios, let you show all of it with nothing more than a bare ESP32.

```
bms-telemetry/
├── platformio.ini
├── include/
│   ├── config.h              all tunables (thresholds, timings, pins, queue size)
│   ├── pins.h                Blynk virtual-pin map (FULL / COMPACT profiles)
│   └── secrets.example.h     copy to secrets.h: Wi-Fi + Blynk credentials
├── lib/telemetry_core/src/   portable C++ (no Arduino) - unit-tested on PC
│   ├── TelemetryTypes.*      events, cell stats, fault bits
│   ├── EventDetector.*       decides WHEN to send
│   ├── EventQueue.h          fixed-size FIFO, priority-aware overflow
│   ├── TelemetryManager.h    live vs queue routing, ordered replay
│   ├── FaultManager.*        debounced OV/UV/imbalance/sensor faults, relay latch
│   ├── WifiStateMachine.*    non-blocking Wi-Fi + Blynk connection manager
│   ├── RssiMonitor.*         EMA-filtered RSSI, quality classes
│   └── DemoSupport.*         simulated pack, fault injection, demo scripts
├── src/
│   ├── main.cpp              tasks, loop, serial console, button, LED
│   ├── Protection.*          10 Hz safety task (cells → faults → relay)
│   ├── CellSource.*          simulated cells or ADC tap measurement
│   └── BlynkLink.*           Wi-Fi/Blynk driver + dashboard publisher
├── test/test_core/           23 Unity unit tests (pio test -e native)
├── tools/
│   ├── Makefile              host build: tests, simulator, firmware type-check
│   ├── sim/demo_sim.cpp      runs both demo scenarios in virtual time + checks
│   └── stubs/                API stubs used only by `make stubcheck`
└── docs/
    ├── blynk-dashboard.md    datastreams, widgets, events, layout
    └── demo-guide.md         step-by-step demonstration script
```

---

## 1. Architecture

```
            ┌───────────────────────────── ESP32 (core 1) ─────────────────────────────┐
            │                                                                          │
 cells ───► │ PROTECTION task  (prio 3, 10 Hz)                                         │
 (ADC or    │   read cells → apply fault injection → FaultManager → RELAY pin          │──► relay
  sim)      │        │ shared state (spinlock)                                         │
            │        ▼                                                                 │
            │ DETECTOR task    (prio 2, 10 Hz)                                         │
            │   EventDetector: fault/relay edges (immediate), Δ ≥ 20 mV,               │
            │   new weakest/strongest, link class change, 60 s heartbeat               │
            │        │ FreeRTOS queue (events keep their original timestamp)           │
            │        ▼                                                                 │
            │ loop()           (prio 1)                                                │
            │   WifiStateMachine.tick()  ── never waits ──► Wi-Fi / Blynk              │
            │   TelemetryManager.submit(): online && queue empty → LIVE                │
            │                               otherwise          → EventQueue<64>        │
            │   TelemetryManager.service(): replay 1 event / 400 ms, oldest first      │──► Blynk
            │   status pins, dashboard pump, console, button, LED, demo runner         │
            └──────────────────────────────────────────────────────────────────────────┘
```

**Why three layers?** The only part that can be slowed down by the radio is
`loop()`. For example, the TCP connect inside a Blynk login can take a few
seconds. Protection runs above it and never waits on the network. Events are
detected and time-stamped above it too, and wait in the hand-off queue. So
a slow network can never delay a trip or reorder events.

### 1.1 What counts as an event

| Event | Trigger | Priority | Rate limit |
|-------|---------|----------|------------|
| `FAULT_SET` / `FAULT_CLEAR` | Fault bit changes (after 3-sample debounce) | Critical | none |
| `RELAY` | Relay opens or closes | Critical | none |
| `OPERATOR_RESET` | Dashboard, serial or BOOT button reset accepted | Critical | none |
| `LINK_RESTORED` | Back online after an outage (arg = outage ms) | Critical | none |
| `QUEUE_OVERFLOW` | Backlog drained but some events were dropped | Critical | none |
| `BOOT` | First evaluation after power-up | Critical | none |
| `EXTREMES` | A different cell became weakest/strongest by ≥ 10 mV | Normal | 2 s |
| `CELL_CHANGE` | Any cell moved ≥ 20 mV from the **last reported** value | Normal | 2 s |
| `LINK_QUALITY` | RSSI class changed (EXCELLENT/GOOD/FAIR/POOR/BAD) | Normal | 2 s |
| `HEARTBEAT` | Nothing sent for 60 s | Normal | – |

The deadband is measured from the **last reported** value, not the last
sample, so slow drift still gets reported once it adds up to 20 mV.
When RSSI is POOR or BAD, the 2 s spacing grows by 3 s or 8 s.

Every event carries a full snapshot: all cell voltages, fault bits, fault
cell, relay, RSSI and an uptime timestamp. Any single event is therefore
enough to redraw the dashboard.

### 1.2 Offline queue

* `EventQueue<QUEUE_CAPACITY>` is a ring buffer of 36-byte events. It is
  statically allocated (64 slots ≈ 2.3 KB) and uses no heap.
* **Ordering rule:** an event goes out live *only if the queue is empty*.
  Otherwise it joins the back. The dashboard therefore receives sequence
  numbers in strictly increasing order, even for events that happen while
  the backlog is replaying.
* **Overflow policy:** when the queue is full, the oldest *normal* event is
  dropped first. If the queue holds only critical events, a new normal
  event is refused, and a new critical one replaces the oldest critical one.
  Every drop is counted. After the backlog drains, a `QUEUE_OVERFLOW` event
  reports how many were lost, and the dashboard shows it on V22.
* **Replay pacing:** one event per 400 ms (`REPLAY_INTERVAL_MS`). This stays
  well inside Blynk's flood limit. If a replay write fails, the *same* event
  is retried. It isn't lost.

### 1.3 Non-blocking Wi-Fi state machine

```
 IDLE ──begin──► WIFI_CONNECTING ──got IP──► CLOUD_CONNECTING ──login ok──► ONLINE
                      │ timeout 15 s              │ timeout 12 s / Wi-Fi lost     │
                      ▼                           ▼                               │ Wi-Fi lost
                   BACKOFF ◄──────────────────────┴───────────────────────────────┤
                      │ 1 s, 2 s, 4 s … 30 s (+ up to 20 % jitter)                 │ cloud lost,
                      └──► WIFI_CONNECTING (or CLOUD_CONNECTING if Wi-Fi is up)     │ Wi-Fi OK
                                                         CLOUD_CONNECTING ◄─────────┘
 FORCED_OFFLINE (demo/maintenance) ── timer ends ──► IDLE
```

* `tick()` only checks conditions and timers. `WiFi.begin()` and
  `Blynk.connect(0)` return immediately, and `WiFi.setAutoReconnect(false)`
  means only this state machine retries.
* If only the Blynk session drops, it logs in again **without** re-joining
  the access point.
* It counts outages and measures outage duration, which is reported in the
  `LINK_RESTORED` event.
* RSSI is sampled once per second while associated.

**Honest limit:** the Blynk library's first `run()` of a login does a socket
`connect()` that can take up to the WiFiClient timeout (about 3 s). That
blocking is confined to `loop()`. Protection and event detection run in
their own higher-priority tasks, so they're unaffected.

### 1.4 RSSI monitor

An exponential moving average (α = 0.25) of `WiFi.RSSI()`, graded into
classes:

| Class | Filtered RSSI |
|-------|---------------|
| EXCELLENT | ≥ −55 dBm |
| GOOD | ≥ −67 dBm |
| FAIR | ≥ −75 dBm |
| POOR | ≥ −85 dBm (non-critical traffic +3 s) |
| BAD | < −85 dBm (non-critical traffic +8 s) |

There's a ±3 dB dead zone at each boundary. The dashboard gets RSSI, a
0–100 % figure and a text label, re-sent only after a ≥ 3 dB change or a
class change.

### 1.5 Protection

| Fault | Trips | Clears | Default |
|-------|-------|--------|---------|
| Over-voltage | any cell > `OV_SET_MV` | all < `OV_CLEAR_MV` | 4250 / 4150 mV |
| Under-voltage | any cell < `UV_SET_MV` | all > `UV_CLEAR_MV` | 3000 / 3100 mV |
| Imbalance | max − min > `IMB_SET_MV` | < `IMB_CLEAR_MV` | 150 / 100 mV |
| Sensor | reading outside 500–4800 mV (open wire) | back in range | – |

* All faults are debounced over 3 consecutive samples, so a trip takes about
  300 ms at 10 Hz.
* An implausible reading is a **sensor** fault and is excluded from the
  OV/UV checks, so a broken sense wire isn't reported as under-voltage.
* The relay stays **open at boot** until 5 clean samples pass the
  self-check.
* With `FAULT_LATCH 1`, the relay stays open after a fault clears until an
  operator reset. A reset is **refused while a fault is still active**.

---

## 2. Hardware

| Part | Notes |
|------|-------|
| ESP32 DevKit (ESP32-WROOM-32) | `board = esp32dev` |
| Relay / contactor driver module | `RELAY_PIN` (GPIO 26), active-high by default |
| *(optional)* resistor dividers on cell taps | Only for `USE_SIMULATED_CELLS 0` |

The **BOOT button** (GPIO 0) is the local operator reset: hold it for 1 s.
The **on-board LED** (GPIO 2) shows status: solid = live, slow blink =
replaying backlog, fast blink = offline, double flash = fault latched.

### Real cell measurement (optional)

With `USE_SIMULATED_CELLS 0`, the firmware reads cumulative tap voltages on
ADC1 pins 36, 39, 34 and 35 (ADC2 can't be used while Wi-Fi is on), using
`analogReadMilliVolts()` with factory calibration and 16× oversampling. Each
cell voltage is the difference between adjacent taps.

```
 pack+ (tap 4) ──[68k]──┬──[10k]── GND      → GPIO35  (ratio 7.8)
       tap 3   ──[56k]──┬──[10k]── GND      → GPIO34  (ratio 6.6)
       tap 2   ──[33k]──┬──[10k]── GND      → GPIO39  (ratio 4.3)
       tap 1   ──[10k]──┬──[10k]── GND      → GPIO36  (ratio 2.0)
 pack− ───────────────── ESP32 GND
```

Calibrate each tap with a multimeter (`TAP_CALIBRATION` in `config.h`).
This method suits a bench demo. Divider errors accumulate up the stack and
the dividers slowly drain the cells. **For a real pack, use a BMS front-end
IC** (e.g. BQ76920/BQ76940, LTC6811): replace `AdcCellSource` and keep
everything else. Keep the pack isolated from USB ground while measuring.

---

## 3. Build and flash

1. Install **PlatformIO** (the VS Code extension, or `pip install platformio`).
2. `cp include/secrets.example.h include/secrets.h` and fill in your Wi-Fi
   credentials and the Blynk template ID, name and auth token.
3. Create the Blynk template and datastreams: **[docs/blynk-dashboard.md](docs/blynk-dashboard.md)**.
4. Build and flash:
   ```
   pio run -e esp32dev -t upload
   pio device monitor
   ```

### Serial console (115200 baud)

```
status | s                 full status: cells, faults, net state, RSSI, queue, msg rate
inject ov|uv|imb|open <n>  inject a fault on cell n
clear                      remove injected fault
reset                      operator reset
outage <sec>               really drop Wi-Fi for <sec> s (0 = until 'restore')
restore                    end forced outage
demo fault|outage|full|stop
queue                      list queued events
```

Example output during an outage:

```
[   53312] QUEUED #12   FAULT_SET       W:C3 3.722V S:C2 4.380V d=658mV relay=OPEN   faults=OV+IMB arg=5
[  106710] NET CLOUD_CONNECTING -> ONLINE
[  106710] link restored after 63700 ms, 7 queued event(s) to replay
[  107110] REPLAY sent, 6 left (age 53800 ms)
```

---

## 4. Testing without hardware

The protocol logic lives in `lib/telemetry_core`, which has no Arduino
dependency, so it's tested on a PC:

```
pio test -e native          # 23 unit tests (Unity)
# or, without PlatformIO:
make -C tools test          # same tests, built with g++ + AddressSanitizer/UBSan
make -C tools sim           # both demo scenarios in virtual time, with checks
make -C tools stubcheck     # type-checks src/*.cpp against Arduino/Blynk API stubs
```

The unit tests cover:

* queue FIFO, wrap-around and both overflow rules
* fault debounce, hysteresis, latch, refused reset, open wire and start-up
  self-check
* detector deadband, rate limit, immediate faults, extremes and heartbeat
* RSSI classes, hysteresis and smoothing
* the state machine: connect, growing back-off, cloud-only drop, forced
  outage and outage duration
* the manager: ordered replay with events arriving mid-replay, retry on
  failed send, and overflow reporting
* that each injected fault kind trips the correct fault

`tools/sim/demo_sim.cpp` runs the **same core code** through the full demo
(a fault while online, then a 60 s outage with a fault and reset while
offline) and through a deliberately tiny 8-slot queue. It checks that:

* the dashboard received every event in strictly increasing order, with
  0 lost in scenario 1
* the online fault went out live in the same loop pass, and the offline
  fault arrived as a replay about 54 s after it happened
* the relay opened 290 ms after each injection, whether online or offline
* the link recovered by itself and the queue drained
* in the overflow run, only a low-priority event was dropped, the faults and
  reset survived, and a `QUEUE_OVERFLOW` event was delivered
* the live widgets were never written by replayed data

It also reports **24 telemetry events in 200 s**, compared with 200 samples
for 1 Hz periodic reporting (88 % fewer).
Timelines are written to `tools/sim/out/*.csv` for plotting.

---

## 5. Configuration reference (`include/config.h`)

| Setting | Default | Meaning |
|---------|---------|---------|
| `CELL_COUNT` | 4 | Series cells (1–8) |
| `USE_SIMULATED_CELLS` | 1 | 1 = simulated pack, 0 = ADC taps |
| `CELL_DEADBAND_MV` | 20 | Significant change per cell |
| `EXTREMES_HYST_MV` | 10 | Weakest/strongest swap hysteresis |
| `MIN_EVENT_INTERVAL_MS` | 2000 | Spacing of non-critical events |
| `HEARTBEAT_MS` | 60000 | Max silence |
| `QUEUE_CAPACITY` | 64 | Offline queue slots |
| `REPLAY_INTERVAL_MS` | 400 | Replay pacing |
| `FAULT_DEBOUNCE` | 3 | Samples to set or clear a fault |
| `FAULT_LATCH` | 1 | Require operator reset after a trip |
| `WIFI_TIMEOUT_MS` / `CLOUD_TIMEOUT_MS` | 15000 / 12000 | Per-attempt timeouts |
| `BACKOFF_MIN_MS` / `BACKOFF_MAX_MS` | 1000 / 30000 | Retry back-off range |
| `DASHBOARD_PROFILE` | FULL | FULL (33 datastreams) or COMPACT (10) |
| `ENABLE_BLYNK_EVENTS` | 1 | `bms_fault` / `link_restored` notifications |
| `TZ_INFO` | `IST-5:30` | Time zone for log timestamps |

## 6. Known limitations

* **The offline queue lives in RAM.** A reboot during an outage loses the
  backlog. Persisting it to NVS or LittleFS is a straightforward extension,
  but flash wear needs care.
* **Replay timestamps need SNTP.** The clock syncs in the background after
  the first Wi-Fi connection. Events replayed before that sync completes
  (normally just the boot events at the very first login) are written
  without a timestamp, and their log line shows uptime (`t+…s`) instead of
  the time of day.
* **Blynk login can block `loop()` for up to about 3 s** (see 1.3). Safety
  and event timing are not affected.
* **The divider-based ADC measurement is a demo method.** Use a BMS AFE IC
  for real packs.
