// secrets.example.h — copy to include/secrets.h and fill in.
// include/secrets.h is git-ignored so credentials never get committed.
#pragma once

// From Blynk Console -> Templates -> your template -> Firmware configuration
#define BLYNK_TEMPLATE_ID   "TMPLxxxxxxxx"
#define BLYNK_TEMPLATE_NAME "BMS Telemetry"
// From Blynk Console -> Devices -> your device -> Device info
#define BLYNK_AUTH_TOKEN    "xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx"

#define WIFI_SSID           "your-ssid"
#define WIFI_PASS           "your-password"
