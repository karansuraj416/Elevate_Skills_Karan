// config.h — every tunable for the BMS telemetry node in one place.
#pragma once

// ============================================================ hardware ===
#define CELL_COUNT            4      // series cells monitored (1..8)

// 1 = built-in simulated pack (no battery needed, ideal for the demo)
// 0 = read real cell taps through resistor dividers on ADC1
#ifndef USE_SIMULATED_CELLS
#define USE_SIMULATED_CELLS   1
#endif

// ADC1 pins only (ADC2 cannot be used while Wi-Fi is on).
// Tap k = cumulative voltage of cells 1..k measured against pack negative.
#define TAP_PINS              {36, 39, 34, 35}
// Divider ratio (Rtop + Rbottom) / Rbottom for each tap, e.g.
//   tap1 10k/10k = 2.0   (4.2 V  -> 2.10 V at ADC)
//   tap2 33k/10k = 4.3   (8.4 V  -> 1.95 V)
//   tap3 56k/10k = 6.6   (12.6 V -> 1.91 V)
//   tap4 68k/10k = 7.8   (16.8 V -> 2.15 V)
#define TAP_DIVIDER_RATIOS    {2.0f, 4.3f, 6.6f, 7.8f}
// Per-tap trim measured with a multimeter (true / reported). 1.0 = untrimmed.
#define TAP_CALIBRATION       {1.000f, 1.000f, 1.000f, 1.000f}
#define ADC_OVERSAMPLE        16

#define RELAY_PIN             26     // drives the contactor / relay module
#define RELAY_ACTIVE_HIGH     1      // 1: HIGH = relay closed (pack connected)
#define STATUS_LED_PIN        2      // on-board LED
#define RESET_BUTTON_PIN      0      // BOOT button: hold 1 s = operator reset
#define RESET_HOLD_MS         1000

// ========================================================== protection ===
#define OV_SET_MV             4250
#define OV_CLEAR_MV           4150
#define UV_SET_MV             3000
#define UV_CLEAR_MV           3100
#define IMB_SET_MV            150
#define IMB_CLEAR_MV          100
#define SENSOR_MIN_MV         500
#define SENSOR_MAX_MV         4800
#define FAULT_DEBOUNCE        3      // samples (at 10 Hz = 300 ms)
#define FAULT_LATCH           1      // 1: relay stays open until operator reset
#define PROTECTION_PERIOD_MS  100    // 10 Hz sampling in its own RTOS task

// =========================================================== telemetry ===
#define CELL_DEADBAND_MV      20     // change that counts as significant
#define EXTREMES_HYST_MV      10     // weakest/strongest swap hysteresis
#define MIN_EVENT_INTERVAL_MS 2000   // spacing of non-critical events
#define HEARTBEAT_MS          60000  // max silence (proof of life)
#define DETECT_PERIOD_MS      100    // how often the detector looks
#define QUEUE_CAPACITY        64     // offline queue slots (36 B each)
#define REPLAY_INTERVAL_MS    400    // one queued event per 400 ms on replay
#define STATUS_PERIOD_MS      1000   // dashboard health refresh
#define RSSI_PUBLISH_STEP_DB  3      // only re-send RSSI after this change

// ============================================================= network ===
#define WIFI_TIMEOUT_MS       15000
#define CLOUD_TIMEOUT_MS      12000
#define BACKOFF_MIN_MS        1000
#define BACKOFF_MAX_MS        30000
#define RSSI_PERIOD_MS        1000
#define NTP_SERVER_1          "pool.ntp.org"
#define NTP_SERVER_2          "time.google.com"
#define TZ_INFO               "IST-5:30"   // POSIX TZ for log timestamps
#define ENABLE_BLYNK_EVENTS   1      // push fault / link events (define them in the template)
#define OUTAGE_DEMO_MS        60000  // dashboard "simulate outage" length

// =========================================================== dashboard ===
// FULL: one datastream per value (33 datastreams with 4 cells, see docs).
// COMPACT: 10 datastreams with packed text values, for plans with a low
//          datastream limit.
#define DASHBOARD_FULL        1
#define DASHBOARD_COMPACT     2
#ifndef DASHBOARD_PROFILE
#define DASHBOARD_PROFILE     DASHBOARD_FULL
#endif

#define WRITES_PER_PUMP       2      // virtual-pin writes per loop pass
#define PUMP_PERIOD_MS        150

#define SERIAL_BAUD           115200
