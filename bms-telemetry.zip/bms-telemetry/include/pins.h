// pins.h — Blynk virtual pin map. Must match the datastreams in your Blynk
// template (docs/blynk-dashboard.md lists name, type, range and widget).
#pragma once

#include "config.h"

#if DASHBOARD_PROFILE == DASHBOARD_FULL
// ---------------------------------------------------------------- LIVE ---
#define VP_CELL_BASE      0   // V0..V7  Cell n voltage (V, 3 dp)
#define VP_WEAK_V         8   // weakest cell voltage (V)
#define VP_WEAK_IDX       9   // weakest cell number (1..N)
#define VP_STRONG_V       10  // strongest cell voltage (V)
#define VP_STRONG_IDX     11  // strongest cell number
#define VP_DELTA_MV       12  // strongest - weakest (mV)
#define VP_PACK_V         13  // pack voltage (V)
#define VP_RELAY          14  // 1 = closed / pack connected
#define VP_FAULT_CODE     15  // fault bitmask (0 = OK)
#define VP_FAULT_TEXT     16  // "OK", "OV cell 2 (latched)" ...
#define VP_DATA_MODE      17  // 0 LIVE, 1 REPLAYING QUEUE
#define VP_RSSI           18  // filtered RSSI (dBm)
#define VP_LINK_PCT       19  // link quality 0..100 %
#define VP_LINK_TEXT      20  // "GOOD -61 dBm"
#define VP_QUEUE_DEPTH    21  // offline queue depth (events)
#define VP_QUEUE_DROPPED  22  // events lost to overflow
#define VP_DISCONNECTS    23  // number of outages since boot
#define VP_LAST_OUTAGE_S  24  // duration of the last outage (s)
#define VP_UPTIME_MIN     25  // device uptime (minutes)
#define VP_LIVE_SEQ       26  // sequence number of last LIVE event
// ------------------------------------------------------------- REPLAYED --
// Written with the event's ORIGINAL timestamp, so their charts back-fill
// the outage period. Live widgets above are never touched by replay.
#define VP_RP_WEAK_V      27
#define VP_RP_STRONG_V    28
#define VP_RP_FAULT_CODE  29
#define VP_RP_RELAY       30
#define VP_LOG            31  // event log text (live + replayed lines)
// ------------------------------------------------------------- CONTROLS --
#define VP_CTL_INJECT     40  // menu: 0 none,1 OV,2 UV,3 IMB,4 open wire
#define VP_CTL_CELL       41  // slider: target cell 1..CELL_COUNT
#define VP_CTL_RESET      42  // button: operator reset
#define VP_CTL_OUTAGE     43  // button: simulate 60 s network outage
#define VP_CTL_SCENARIO   44  // menu: 0 stop,1 fault,2 outage,3 full

#elif DASHBOARD_PROFILE == DASHBOARD_COMPACT
// Ten datastreams. Text pins pack several values.
#define VP_WEAK_V         0   // weakest cell voltage (V)       - gauge/chart
#define VP_STRONG_V       1   // strongest cell voltage (V)     - gauge/chart
#define VP_CELLS_TEXT     2   // "C1 3.712 | C2 3.705 | ... | W:C3 S:C1 d=18mV"
#define VP_RELAY          3   // 1 = closed                    - LED
#define VP_FAULT_CODE     4   // bitmask                       - LED / label
#define VP_STATUS_TEXT    5   // "LIVE | Q 0/64 | GOOD -61 dBm | out 0"
#define VP_QUEUE_DEPTH    6   // offline queue depth           - chart
#define VP_LOG            7   // event log (LIVE / REPLAY lines)
#define VP_CTL_COMMAND    8   // menu (see docs) -> inject, reset, outage, demos
#define VP_RSSI           9   // RSSI dBm                      - chart
#else
#error "Unknown DASHBOARD_PROFILE"
#endif
