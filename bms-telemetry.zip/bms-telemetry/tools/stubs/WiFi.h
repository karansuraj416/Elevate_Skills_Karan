#pragma once
#include "Arduino.h"
typedef enum { WIFI_OFF, WIFI_STA } wifi_mode_t;
typedef enum { WL_IDLE_STATUS = 0, WL_CONNECTED = 3, WL_DISCONNECTED = 6 } wl_status_t;
struct WiFiClass {
  bool mode(wifi_mode_t) { return true; }
  bool setAutoReconnect(bool) { return true; }
  void persistent(bool) {}
  bool setSleep(bool) { return true; }
  bool disconnect(bool wifioff = false, bool eraseap = false) { (void)wifioff; (void)eraseap; return true; }
  wl_status_t begin(const char*, const char* = nullptr) { return WL_DISCONNECTED; }
  wl_status_t status() { return WL_DISCONNECTED; }
  int8_t RSSI() { return 0; }
};
extern WiFiClass WiFi;
