#pragma once
#define BLYNK_TEMPLATE_ID   "TMPLstub"
#define BLYNK_TEMPLATE_NAME "BMS Telemetry"
#define BLYNK_AUTH_TOKEN    "stub"
#define WIFI_SSID           "stub"
#define WIFI_PASS           "stub"
