// Stub mirroring the Blynk 1.3/1.4 API used by BlynkLink.cpp.
#pragma once
#include "Arduino.h"
#ifndef BLYNK_TEMPLATE_ID
#error "BLYNK_TEMPLATE_ID must be defined before including BlynkSimpleEsp32.h"
#endif
struct BlynkParam {
  int asInt() const { return 0; }
  void add(int) {} void add(unsigned int) {} void add(long) {} void add(unsigned long) {}
  void add(long long) {} void add(unsigned long long) {} void add(float) {} void add(double) {}
  void add(const char*) {} void add(const __FlashStringHelper*) {}
  template <typename T> void add_multi(T last) { add(last); }
  template <typename T, typename... Args> void add_multi(T head, Args... tail) { add(head); add_multi(tail...); }
};
struct BlynkReq { int pin; };
struct BlynkWifi {
  void config(const char*, const char* = "blynk.cloud", uint16_t = 80) {}
  bool connect(uint32_t timeout = 18000) { (void)timeout; return false; }
  void disconnect() {}
  bool connected() const { return false; }
  bool run(bool = false) { return true; }
  template <typename... Args> void virtualWrite(int, Args... v) { BlynkParam p; p.add_multi(v...); }
  void beginGroup() {}
  void beginGroup(uint64_t) {}
  void endGroup() {}
  template <typename N> void logEvent(const N&) {}
  template <typename N, typename D> void logEvent(const N&, const D&) {}
};
extern BlynkWifi Blynk;
#define BLYNK_WRITE_2(pin) void BlynkWidgetWrite##pin(BlynkReq& request, const BlynkParam& param)
#define BLYNK_WRITE(pin) BLYNK_WRITE_2(pin)
#define BLYNK_CONNECTED() void BlynkOnConnected()
