// Compile-check stubs: just enough of the Arduino-ESP32 API (signatures as
// in arduino-esp32 2.0.x) to type-check src/*.cpp on a PC. NOT functional.
#pragma once
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include <stdarg.h>
#define HIGH 1
#define LOW 0
#define INPUT 0x01
#define OUTPUT 0x03
#define INPUT_PULLUP 0x05
typedef bool boolean;
class __FlashStringHelper;
#define F(s) (reinterpret_cast<const __FlashStringHelper*>(s))
struct HardwareSerial {
  void begin(unsigned long) {}
  int available() { return 0; }
  int read() { return -1; }
  size_t printf(const char* fmt, ...) __attribute__((format(printf, 2, 3))) { return 0; }
  size_t println(const char*) { return 0; }
  size_t println(const __FlashStringHelper*) { return 0; }
  size_t print(const char*) { return 0; }
};
extern HardwareSerial Serial;
unsigned long millis();
unsigned long micros();
void delay(uint32_t);
void pinMode(uint8_t, uint8_t);
void digitalWrite(uint8_t, uint8_t);
int digitalRead(uint8_t);
void analogReadResolution(uint8_t);
typedef enum { ADC_0db, ADC_2_5db, ADC_6db, ADC_11db } adc_attenuation_t;
void analogSetPinAttenuation(uint8_t, adc_attenuation_t);
uint32_t analogReadMilliVolts(uint8_t);
char* dtostrf(double, signed char, unsigned char, char*);
template <class T, class L, class H> T constrain(T x, L lo, H hi) { return x < lo ? lo : (x > hi ? hi : x); }
struct EspClass { uint32_t getFreeHeap() { return 0; } };
extern EspClass ESP;
void configTzTime(const char* tz, const char* s1, const char* s2 = nullptr, const char* s3 = nullptr);
// ---- FreeRTOS ----
typedef uint32_t TickType_t;
typedef struct { int x; } portMUX_TYPE;
#define portMUX_INITIALIZER_UNLOCKED {0}
void portENTER_CRITICAL(portMUX_TYPE*);
void portEXIT_CRITICAL(portMUX_TYPE*);
#define pdMS_TO_TICKS(ms) ((TickType_t)(ms))
#define pdTRUE 1
typedef int BaseType_t;
typedef void* QueueHandle_t;
typedef void* TaskHandle_t;
typedef void (*TaskFunction_t)(void*);
TickType_t xTaskGetTickCount();
void vTaskDelayUntil(TickType_t*, TickType_t);
BaseType_t xTaskCreatePinnedToCore(TaskFunction_t, const char*, uint32_t, void*, unsigned, TaskHandle_t*, BaseType_t);
QueueHandle_t xQueueCreate(unsigned, unsigned);
BaseType_t xQueueSend(QueueHandle_t, const void*, TickType_t);
BaseType_t xQueueReceive(QueueHandle_t, void*, TickType_t);
