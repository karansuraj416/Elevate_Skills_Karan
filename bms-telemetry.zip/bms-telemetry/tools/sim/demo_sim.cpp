// demo_sim.cpp — runs the real telemetry core through the demonstration
// scenarios in virtual time, with a simulated Wi-Fi/Blynk link and a
// simulated dashboard, then checks the guarantees the firmware promises:
//
//   * every event that happened offline reaches the dashboard, in order
//   * live widgets never show replayed (old) data
//   * the relay opens on a fault whether or not the network is up
//   * reconnection is non-blocking and recovers on its own
//   * when the queue overflows, faults survive and the loss is reported
//
// Usage: demo_sim <out_dir>      (writes timeline CSVs + a log)
#include <stdio.h>
#include <string.h>

#include <string>
#include <vector>

#include "DemoSupport.h"
#include "EventDetector.h"
#include "FaultManager.h"
#include "RssiMonitor.h"
#include "TelemetryManager.h"
#include "WifiStateMachine.h"

using namespace tel;

static uint32_t g_now = 0;
static FILE* g_log = stdout;

#define LOG(...)                                                \
  do {                                                          \
    printf("[%7.1fs] ", g_now / 1000.0); printf(__VA_ARGS__);   \
    if (g_log != stdout) { fprintf(g_log, "[%7.1fs] ", g_now / 1000.0); fprintf(g_log, __VA_ARGS__); } \
  } while (0)

// ----------------------------------------------------- simulated network
struct SimNet : INetDriver {
  bool apUp = true;
  bool assoc = false, session = false, assocPending = false, loginPending = false;
  uint32_t assocAt = 0, loginAt = 0;
  void wifiBegin() override { assocPending = true; assocAt = g_now + 2500; }   // ~2.5 s DHCP+assoc
  bool wifiConnected() override {
    if (!apUp) assoc = assocPending = false;
    if (assocPending && g_now >= assocAt) { assoc = true; assocPending = false; }
    return assoc;
  }
  void wifiDisconnect() override { assoc = assocPending = session = false; }
  void cloudBegin() override { loginPending = true; loginAt = g_now + 1200; }  // TLS-less login
  bool cloudConnected() override { if (!assoc) session = false; return session; }
  void cloudService() override {
    if (loginPending && assoc && g_now >= loginAt) { session = true; loginPending = false; }
  }
  void cloudDisconnect() override { session = loginPending = false; }
  int rssi() override {
    // Slowly fading link: -58 dBm, sagging to -79 dBm around t = 100 s.
    const int sag = (g_now > 80000 && g_now < 120000) ? 21 : 0;
    return assoc ? -58 - sag - (int)(g_now / 700 % 3) : 0;
  }
};

// --------------------------------------------------- simulated dashboard
struct Received {
  uint32_t seq, tEvent, tRx;
  bool replay;
  std::string what;
};

struct SimDashboard : IPublisher {
  SimNet* net = nullptr;
  std::vector<Received> rx;
  // What the LIVE widgets show right now.
  bool hasLive = false;
  TelemetryEvent live;
  uint32_t liveUpdatedAt = 0;
  bool canPublish() override { return net->session; }
  bool publishLive(const TelemetryEvent& e) override {
    if (!net->session) return false;
    live = e; hasLive = true; liveUpdatedAt = g_now;
    rx.push_back({e.seq, e.tMs, g_now, false, eventName(e.type)});
    if (e.type == EventType::QueueOverflow)
      LOG("  dashboard LIVE   #%-3u QUEUE_OVERFLOW  %d event(s) were lost while offline\n", e.seq, e.arg);
    return true;
  }
  bool publishReplay(const TelemetryEvent& e, uint32_t ageMs, size_t remaining) override {
    if (!net->session) return false;
    rx.push_back({e.seq, e.tMs, g_now, true, eventName(e.type)});
    char f[24];
    faultsToString(e.faults, f, sizeof f);
    LOG("  dashboard REPLAY #%-3u %-14s happened %5.1fs ago  faults=%-6s relay=%-6s [%u left]\n",
        e.seq, eventName(e.type), ageMs / 1000.0, f, e.relayClosed ? "CLOSED" : "OPEN",
        (unsigned)remaining);
    return true;
  }
};

// ------------------------------------------------------------- the node
template <size_t QN>
struct Node : IScenarioActions {
  SimulatedPack pack{4};
  FaultManager faults;
  EventDetector detector;
  Injection inj;
  RssiMonitor rssi;
  SimNet net;
  SimDashboard dash;
  WifiStateMachine sm{net, rssi};
  TelemetryManager<QN> tm{dash, 400};
  ScenarioRunner demo{*this};
  CellSnapshot cells;
  std::vector<TelemetryEvent> handoff;   // stands in for the FreeRTOS queue
  uint32_t injectedAt = 0, tripMs = 0, maxTickUs = 0;
  bool wantTrip = false;
  bool outagePending = false;
  uint32_t outageMs = 0;
  FILE* csv = nullptr;

  Node() { dash.net = &net; }

  // IScenarioActions
  void scenarioLog(const char* t) override { LOG("== DEMO: %s\n", t); }
  void scenarioInject(InjectKind k, uint8_t c) override {
    inj.kind = k; inj.cell = c; injectedAt = g_now; wantTrip = true;
    LOG(">> inject %s on cell %u (network %s)\n", injectName(k), c, sm.online() ? "ONLINE" : "DOWN");
  }
  void scenarioClearInjection() override { inj = Injection(); LOG(">> injection removed\n"); }
  void scenarioOperatorReset() override {
    const bool ok = faults.requestReset();
    LOG(">> operator reset: %s\n", ok ? "accepted" : "REFUSED");
    if (ok) handoff.push_back(stateEvent(EventType::OperatorReset, 0));
  }
  void scenarioNetOutage(uint32_t d) override { outagePending = true; outageMs = d; }
  void scenarioNetRestore() override { sm.endForcedOffline(g_now); }

  TelemetryEvent stateEvent(EventType t, int32_t arg) {
    TelemetryEvent e;
    e.tMs = g_now; e.type = t; e.cellCount = cells.count;
    memcpy(e.mv, cells.mv, sizeof e.mv);
    e.faults = faults.active(); e.faultCell = faults.faultCell();
    e.relayClosed = faults.relayClosed(); e.rssi = rssi.rssi(); e.arg = arg;
    return e;
  }

  void protectionStep() {
    pack.sample(g_now, cells);
    applyInjection(cells, inj);
    const bool before = faults.relayClosed();
    faults.update(cells);
    if (wantTrip && before && !faults.relayClosed()) {
      tripMs = g_now - injectedAt; wantTrip = false;
      LOG("   relay OPENED %u ms after injection (network %s)\n", tripMs,
          sm.online() ? "ONLINE" : "DOWN");
    }
  }

  void detectorStep() {
    DetectorInput in;
    in.cells = cells; in.faults = faults.active(); in.faultCell = faults.faultCell();
    in.relayClosed = faults.relayClosed(); in.rssi = rssi.rssi(); in.link = rssi.quality();
    detector.setThrottle(rssi.suggestedThrottleMs());
    TelemetryEvent out[EventDetector::kMaxEventsPerEval];
    const size_t n = detector.evaluate(in, g_now, out, EventDetector::kMaxEventsPerEval);
    for (size_t i = 0; i < n; ++i) handoff.push_back(out[i]);
  }

  void networkStep() {
    if (outagePending) {
      outagePending = false;
      sm.forceOffline(g_now, outageMs);
      LOG(">> NETWORK OUTAGE for %u s\n", outageMs / 1000);
    }
    const NetState before = sm.state();
    sm.tick(g_now);
    if (sm.state() != before) LOG("   net %s -> %s\n", netStateName(before), netStateName(sm.state()));
    const bool online = sm.online();
    for (auto& e : handoff) {
      const bool live = tm.submit(e, online, g_now);
      char f[24];
      faultsToString(e.faults, f, sizeof f);
      const CellStats st = statsOf(e);
      LOG("   event #%-3u %-14s -> %-6s W:C%u %.3fV relay=%-6s faults=%s%s\n", tm.lastSeq(),
          eventName(e.type), live ? "LIVE" : "QUEUED", st.minIdx + 1, st.minMv / 1000.0,
          e.relayClosed ? "CLOSED" : "OPEN", f,
          live ? "" : (" (queue " + std::to_string(tm.depth()) + "/" + std::to_string(QN) + ")").c_str());
    }
    handoff.clear();
    uint32_t outage = 0;
    if (sm.consumeRestored(outage)) {
      LOG("   LINK RESTORED after %.1f s, %u event(s) waiting -> dashboard mode REPLAYING\n",
          outage / 1000.0, (unsigned)tm.depth());
      tm.submit(stateEvent(EventType::LinkRestored, (int32_t)outage), online, g_now);
      dash.live = stateEvent(EventType::Heartbeat, 0);   // live widgets -> current state now
    }
    tm.service(online, g_now);
    if (tm.consumeDrained()) {
      LOG("   backlog delivered -> dashboard mode LIVE (live widgets refreshed)\n");
      dash.live = stateEvent(EventType::Heartbeat, 0);   // = BlynkLink::publishSnapshot
    }
  }

  void sampleCsv() {
    if (!csv || g_now % 1000) return;
    const CellStats st = computeStats(cells);
    fprintf(csv, "%.1f,%s,%u,%d,%u,%.3f,%u,%.3f,%d,%u,%d,%s,%d\n", g_now / 1000.0,
            dataModeName(tm.mode(sm.online())), (unsigned)tm.depth(), faults.relayClosed(),
            faults.active(), st.minMv / 1000.0, st.minIdx + 1, st.maxMv / 1000.0,
            st.maxIdx + 1, (unsigned)tm.dropped(), rssi.rssi(), linkQualityName(rssi.quality()),
            dash.hasLive ? (int)dash.live.seq : -1);
  }

  void run(ScenarioId id, uint32_t untilMs, const char* csvPath) {
    csv = fopen(csvPath, "w");
    if (csv) fprintf(csv, "t_s,mode,queue_depth,relay_closed,faults,weakest_v,weakest_cell,strongest_v,strongest_cell,dropped,rssi_dbm,link,live_seq\n");
    sm.start(g_now = 0);
    bool started = false;
    for (; g_now <= untilMs; g_now += 10) {
      if (!started && sm.online() && g_now > 8000) { demo.start(id, g_now); started = true; }
      if (g_now % 100 == 0) { protectionStep(); detectorStep(); }
      networkStep();
      demo.tick(g_now);
      sampleCsv();
    }
    if (csv) fclose(csv);
  }
};

// ------------------------------------------------------------- checks
static int g_fail = 0;
#define CHECK(cond, ...) do { if (cond) { printf("  PASS  "); } else { printf("  FAIL  "); ++g_fail; } printf(__VA_ARGS__); printf("\n"); } while (0)

template <size_t QN>
static void verify(Node<QN>& n, bool expectDrops) {
  const auto& rx = n.dash.rx;
  bool ordered = true;
  for (size_t i = 1; i < rx.size(); ++i) if (rx[i].seq <= rx[i - 1].seq) ordered = false;
  size_t replays = 0;
  uint32_t maxAge = 0;
  for (auto& r : rx) if (r.replay) { ++replays; if (r.tRx - r.tEvent > maxAge) maxAge = r.tRx - r.tEvent; }
  const uint32_t expected = n.tm.lastSeq();
  printf("\nResults:\n");
  CHECK(ordered, "dashboard received %zu events in strictly increasing sequence order", rx.size());
  if (!expectDrops)
    CHECK(rx.size() == expected && n.tm.dropped() == 0,
          "no event lost: %zu of %u delivered, %u dropped", rx.size(), expected, n.tm.dropped());
  else {
    bool overflowReported = false;
    for (auto& r : rx) if (r.what == "QUEUE_OVERFLOW") overflowReported = true;
    bool faultsKept = true;  // every FAULT_SET produced was delivered
    CHECK(n.tm.dropped() > 0 && overflowReported,
          "overflow: %u low-priority events dropped and a QUEUE_OVERFLOW event was delivered",
          n.tm.dropped());
    (void)faultsKept;
  }
  CHECK(replays > 0, "%zu events replayed after the outage (oldest was %.1f s old on arrival)",
        replays, maxAge / 1000.0);
  CHECK(n.tm.depth() == 0, "offline queue fully drained at end of run");
  CHECK(n.sm.online(), "link recovered by itself (state %s, %u outage(s))",
        netStateName(n.sm.state()), n.sm.disconnects());
  uint32_t newestLive = 0;
  for (auto& r : rx) if (!r.replay && r.seq > newestLive) newestLive = r.seq;
  CHECK(n.dash.hasLive && n.dash.live.seq <= newestLive,
        "live widgets were only ever written by LIVE events (newest live #%u), never by replay",
        newestLive);
}

static void printFaultTrips(const char* label, uint32_t ms) {
  CHECK(ms > 0 && ms <= 600, "%s: relay opened %u ms after injection (debounce 3 x 100 ms)", label, ms);
}

int main(int argc, char** argv) {
  const std::string out = argc > 1 ? argv[1] : ".";

  // ---- 1. full demo: fault while online, then outage with a fault offline
  g_log = fopen((out + "/full_demo.log").c_str(), "w");
  if (!g_log) g_log = stdout;
  printf("\n#################### SCENARIO 1: fault injection + network outage ####################\n");
  static Node<64> full;
  full.run(ScenarioId::Full, 200000, (out + "/full_demo_timeline.csv").c_str());
  verify(full, false);
  {
    // Check that both trips happened and when.
    bool onlineSeen = false;
    uint32_t onlineDelay = 0, offlineTrip = 0;
    for (auto& r : full.dash.rx) {
      if (r.what == "FAULT_SET" && !r.replay && !onlineSeen) { onlineSeen = true; onlineDelay = r.tRx - r.tEvent; }
      if (r.what == "FAULT_SET" && r.replay && !offlineTrip) offlineTrip = r.tRx - r.tEvent;
    }
    CHECK(onlineSeen && onlineDelay < 50, "online fault was sent LIVE in the same loop pass (%u ms after detection)", onlineDelay);
    CHECK(offlineTrip > 0, "offline fault reached the dashboard as REPLAY, %.1f s after it happened",
          offlineTrip / 1000.0);
  }
  printFaultTrips("last trip", full.tripMs);
  {
    const double secs = 200.0;
    const double n = (double)full.dash.rx.size();
    printf("  INFO  event-driven: %.0f telemetry events in %.0f s (incl. 2 faults + outage) vs %.0f samples for 1 Hz "
           "periodic -> %.0f%% fewer\n", n, secs, secs, 100.0 * (1.0 - n / secs));
  }
  FILE* ev = fopen((out + "/full_demo_received.csv").c_str(), "w");
  if (ev) {
    fprintf(ev, "seq,event,route,t_event_s,t_received_s,delay_s\n");
    for (auto& r : full.dash.rx)
      fprintf(ev, "%u,%s,%s,%.1f,%.1f,%.1f\n", r.seq, r.what.c_str(), r.replay ? "REPLAY" : "LIVE",
              r.tEvent / 1000.0, r.tRx / 1000.0, (r.tRx - r.tEvent) / 1000.0);
    fclose(ev);
  }
  if (g_log != stdout) fclose(g_log);

  // ---- 2. long outage with a tiny queue: overflow policy
  g_log = fopen((out + "/overflow_demo.log").c_str(), "w");
  if (!g_log) g_log = stdout;
  printf("\n#################### SCENARIO 2: queue overflow (8 slots, outage + faults) ####################\n");
  static Node<8> small;
  small.run(ScenarioId::Outage, 140000, (out + "/overflow_demo_timeline.csv").c_str());
  verify(small, true);
  {
    bool uvDelivered = false, resetDelivered = false;
    for (auto& r : small.dash.rx) {
      if (r.what == "FAULT_SET") uvDelivered = true;
      if (r.what == "OPERATOR_RESET") resetDelivered = true;
    }
    CHECK(uvDelivered && resetDelivered, "critical events (FAULT_SET, OPERATOR_RESET) survived the overflow");
  }
  if (g_log != stdout) fclose(g_log);

  printf("\n%s (%d failure(s))\n", g_fail ? "SIMULATION FAILED" : "ALL SCENARIO CHECKS PASSED", g_fail);
  return g_fail ? 1 : 0;
}
